<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('faculty.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$msg = ''; $error = '';
[$sessionId, $sessionName] = session_selected($conn);
$departments = scope_departments($conn, true);   // the Principal can create accounts in any department
$myDept = user_department_id($conn);
$myId = user_id_int();
$roleLabels = ['principal' => 'Principal', 'hod' => 'HOD', 'class_incharge' => 'Class Incharge', 'subject_incharge' => 'Subject Incharge'];
$creatableRoles = role_is('principal') ? ['hod', 'class_incharge', 'subject_incharge', 'principal'] : ['class_incharge', 'subject_incharge'];

/** Can the signed-in user manage this account? (never their own, HOD only within the department and not principals/HODs) */
function fac_can_manage(mysqli $conn, int $targetId): ?array {
    $stmt = $conn->prepare('SELECT id, full_name, role, department, department_id, active FROM users WHERE id=?');
    $stmt->bind_param('i', $targetId); $stmt->execute();
    $u = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$u || (int)$u['id'] === user_id_int()) return null;
    if (role_is('principal')) return $u;
    if (role_is('hod') && in_array($u['role'], ['class_incharge', 'subject_incharge'], true)
        && ((int)$u['department_id'] === user_department_id($conn))) return $u;
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    try {
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'create') {
            $name = trim((string)($_POST['full_name'] ?? '')); $email = trim((string)($_POST['email'] ?? ''));
            $pass = (string)($_POST['password'] ?? ''); $role = (string)($_POST['role'] ?? '');
            $emp = trim((string)($_POST['employee_id'] ?? ''));
            $deptId = role_is('principal') ? (int)($_POST['department_id'] ?? 0) : $myDept;
            if ($name === '' || mb_strlen($name) > 150) throw new RuntimeException('Enter the full name.');
            if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) throw new RuntimeException('Enter a valid email address.');
            if (strlen($pass) < 10) throw new RuntimeException('Password must be at least 10 characters.');
            if (!in_array($role, $creatableRoles, true)) throw new RuntimeException('You cannot create an account with that role.');
            $deptName = '';
            foreach ($departments as $d) if ((int)$d['id'] === $deptId) $deptName = $d['name'];
            if ($deptName === '') throw new RuntimeException('Select a department.');
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $empDb = $emp === '' ? null : mb_substr($emp, 0, 80);
            $stmt = $conn->prepare('INSERT INTO users(full_name,email,password_hash,role,department,department_id,employee_id,active) VALUES (?,?,?,?,?,?,?,1)');
            $stmt->bind_param('sssssis', $name, $email, $hash, $role, $deptName, $deptId, $empDb); $stmt->execute();
            audit_write($conn, 'user.create', 'user', (int)$conn->insert_id, ['role' => $role, 'department' => $deptName]);
            $msg = $roleLabels[$role] . ' account created for ' . $name . '.';
        } elseif ($action === 'toggle') {
            $u = fac_can_manage($conn, (int)($_POST['id'] ?? 0));
            if (!$u) throw new RuntimeException('You cannot change this account.');
            $new = (int)$u['active'] === 1 ? 0 : 1; $id = (int)$u['id'];
            $stmt = $conn->prepare('UPDATE users SET active=? WHERE id=?'); $stmt->bind_param('ii', $new, $id); $stmt->execute();
            audit_write($conn, $new ? 'user.activate' : 'user.deactivate', 'user', $id);
            $msg = $u['full_name'] . ($new ? ' activated.' : ' deactivated (history is kept).');
        } elseif ($action === 'reset_password') {
            $u = fac_can_manage($conn, (int)($_POST['id'] ?? 0));
            $pass = (string)($_POST['new_password'] ?? '');
            if (!$u) throw new RuntimeException('You cannot change this account.');
            if (strlen($pass) < 10) throw new RuntimeException('New password must be at least 10 characters.');
            $hash = password_hash($pass, PASSWORD_DEFAULT); $id = (int)$u['id'];
            $stmt = $conn->prepare('UPDATE users SET password_hash=? WHERE id=?'); $stmt->bind_param('si', $hash, $id); $stmt->execute();
            audit_write($conn, 'user.reset_password', 'user', $id);
            $msg = 'Password reset for ' . $u['full_name'] . '.';
        } elseif ($action === 'assign_subject') {
            $subjectId = (int)($_POST['subject_id'] ?? 0); $uid = (int)($_POST['user_id'] ?? 0);
            if (!scope_can_use_subject($conn, $subjectId)) {
                // principal passes scope; HOD passes only for own department; subject incharges never reach this page
                throw new RuntimeException('You cannot assign this subject.');
            }
            $stmt = $conn->prepare('SELECT department_id FROM subjects WHERE id=?'); $stmt->bind_param('i', $subjectId); $stmt->execute();
            $subj = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if ($uid > 0) {
                // A faculty member who teaches in several departments keeps ONE account; any department's HOD may give them a subject.
                $stmt = $conn->prepare("SELECT id FROM users WHERE id=? AND role='subject_incharge' AND active=1");
                $stmt->bind_param('i', $uid); $stmt->execute();
                if (!$stmt->get_result()->fetch_assoc()) throw new RuntimeException('Choose an active subject-incharge account.');
                $stmt->close();
            }
            $stmt = $conn->prepare('UPDATE subjects SET subject_incharge_id=NULLIF(?,0) WHERE id=?'); $stmt->bind_param('ii', $uid, $subjectId); $stmt->execute();
            audit_write($conn, 'subject.assign', 'subject', $subjectId, ['user_id' => $uid]);
            $msg = $uid > 0 ? 'Subject incharge assigned.' : 'Subject incharge removed from the subject.';
        }
    } catch (Throwable $e) {
        $error = $e instanceof mysqli_sql_exception && (int)$e->getCode() === 1062 ? 'An account with that email already exists.'
               : ($e instanceof RuntimeException ? $e->getMessage() : 'Could not complete the request. Run the database upgrade (migrate.php) if you have not yet.');
    }
}

/* ---- staff list ---- */
$staffSql = 'SELECT id, full_name, email, role, department, employee_id, active, created_at FROM users';
if (!role_is('principal')) $staffSql .= ' WHERE department=' . "'" . $conn->real_escape_string((string)(current_user()['department'] ?? '')) . "'";
elseif (principal_dept_filter() > 0) {
    $pfName = ''; foreach ($departments as $dd) if ((int)$dd['id'] === principal_dept_filter()) $pfName = $dd['name'];
    $staffSql .= " WHERE department='" . $conn->real_escape_string($pfName) . "' OR role='principal'";
}
$staffSql .= " ORDER BY FIELD(role,'principal','hod','class_incharge','subject_incharge'), full_name";
$staff = $conn->query($staffSql)->fetch_all(MYSQLI_ASSOC);

/* ---- subject assignment ---- */
$subjSql = 'SELECT s.id, s.subject_code, s.subject_name, s.semester, s.department_id, s.subject_incharge_id, u.full_name AS incharge FROM subjects s LEFT JOIN users u ON u.id=s.subject_incharge_id WHERE s.academic_session_id=?' . scope_subject_clause('s') . ' ORDER BY s.semester, s.subject_code';
$stmt = $conn->prepare($subjSql); $stmt->bind_param('i', $sessionId); $stmt->execute();
$subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
$myDeptName = role_is('principal') ? '' : (string)(current_user()['department'] ?? '');
$siStmt = $conn->prepare("SELECT id, full_name, department FROM users WHERE role='subject_incharge' AND active=1 ORDER BY (department = ?) DESC, department, full_name");
$siStmt->bind_param('s', $myDeptName); $siStmt->execute();
$siUsers = $siStmt->get_result()->fetch_all(MYSQLI_ASSOC); $siStmt->close();
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Faculty & Access — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Faculty & Access'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow"><?= role_is('principal') ? 'COLLEGE LEVEL' : 'DEPARTMENT LEVEL' ?></div><h1>Faculty &amp; Access</h1><p><?= role_is('principal') ? 'Create staff accounts for any department and control who can access what.' : 'Create subject and class incharge accounts for your department and assign them their subjects.' ?></p></div></div>
<?php ui_notice($msg, 'ok'); ui_notice($error, 'err'); ?>

<div class="card"><div class="card-head"><div><h2>Create account</h2><span>Role decides which pages and data the person can reach</span></div></div>
<form method="post" class="panel-body" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="action" value="create">
<div class="form-row">
<div class="field"><label>Full name</label><input class="control" name="full_name" required maxlength="150"></div>
<div class="field"><label>Email (sign-in)</label><input class="control" type="email" name="email" required maxlength="190"></div>
<div class="field"><label>Temporary password (min 10)</label><input class="control" type="password" name="password" minlength="10" required autocomplete="new-password"></div>
<div class="field"><label>Role</label><select class="control" name="role"><?php foreach ($creatableRoles as $r): ?><option value="<?= h($r) ?>"><?= h($roleLabels[$r]) ?></option><?php endforeach; ?></select></div>
<?php if (role_is('principal')): ?><div class="field"><label>Department</label><select class="control" name="department_id" required><?php foreach ($departments as $d): ?><option value="<?= (int)$d['id'] ?>"><?= h($d['name']) ?></option><?php endforeach; ?></select></div><?php endif; ?>
<div class="field"><label>Employee ID (optional)</label><input class="control" name="employee_id" maxlength="80"></div>
</div><div class="form-actions"><button class="btn btn-gold" type="submit">＋ Create account</button></div></form></div>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Staff</h2><span><?= role_is('principal') ? 'All departments' : 'Your department' ?></span></div><span class="badge grey"><?= count($staff) ?> accounts</span></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Name</th><th>Role</th><th>Department</th><th>Status</th><th style="width:360px">Actions</th></tr></thead><tbody>
<?php foreach ($staff as $u): $mine = (int)$u['id'] === $myId; $canAct = !$mine && (role_is('principal') || in_array($u['role'], ['class_incharge', 'subject_incharge'], true)); ?>
<tr><td><b><?= h($u['full_name']) ?></b><?= $mine ? ' <span class="badge gold">You</span>' : '' ?><div class="stu-id"><?= h($u['email']) ?><?= $u['employee_id'] ? ' · ' . h($u['employee_id']) : '' ?></div></td>
<td><span class="badge grey"><?= h($roleLabels[$u['role']] ?? $u['role']) ?></span></td><td><?= h($u['department']) ?></td>
<td><?= (int)$u['active'] ? '<span class="badge green">Active</span>' : '<span class="badge rust">Inactive</span>' ?></td>
<td><?php if ($canAct): ?><form method="post" class="inline-form" style="display:inline-flex;gap:6px;flex-wrap:wrap"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><input class="control" style="height:30px;width:140px" type="password" name="new_password" minlength="10" placeholder="New password" autocomplete="new-password"><button class="btn btn-outline btn-sm" name="action" value="reset_password" type="submit">Reset</button><button class="btn <?= (int)$u['active'] ? 'btn-danger' : 'btn-outline' ?> btn-sm" name="action" value="toggle" type="submit"><?= (int)$u['active'] ? 'Deactivate' : 'Activate' ?></button></form><?php else: ?><span class="muted">—</span><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div></div>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Assign subject incharge</h2><span><?= h($sessionName) ?> · a subject incharge sees only the subjects assigned here. A faculty member who teaches in more than one department keeps one account: give the same person the subject of each department.</span></div></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Subject</th><th>Semester</th><th>Current incharge</th><th style="width:340px">Assign</th></tr></thead><tbody>
<?php if (!$subjects): ?><tr><td colspan="4"><div class="muted-empty">No subjects for this session yet. Add them on the Subjects page.</div></td></tr><?php endif; ?>
<?php foreach ($subjects as $s): ?><tr><td><b><?= h($s['subject_code']) ?></b> — <?= h($s['subject_name']) ?></td><td>Semester <?= (int)$s['semester'] ?></td><td><?= $s['incharge'] ? h($s['incharge']) : '<span class="badge grey">Unassigned</span>' ?></td>
<td><form method="post" class="inline-form" style="display:inline-flex;gap:6px"><?= csrf_field() ?><input type="hidden" name="action" value="assign_subject"><input type="hidden" name="subject_id" value="<?= (int)$s['id'] ?>"><select class="control" style="height:30px;width:200px" name="user_id"><option value="0">— Unassigned —</option><?php foreach ($siUsers as $u): ?><option value="<?= (int)$u['id'] ?>" <?= (int)$s['subject_incharge_id'] === (int)$u['id'] ? 'selected' : '' ?>><?= h($u['full_name'] . ' — ' . $u['department']) ?></option><?php endforeach; ?></select><button class="btn btn-outline btn-sm" type="submit">Save</button></form></td></tr>
<?php endforeach; ?></tbody></table></div></div>
</section></div></main></div></body></html>
