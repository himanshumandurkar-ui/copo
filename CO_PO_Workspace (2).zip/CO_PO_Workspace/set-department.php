<?php
/* Principal only: choose which department's data the pages show (0 = all departments). */
require_once __DIR__ . '/includes/auth.php';
require_login();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !role_is('principal')) { http_response_code(403); exit('Not allowed.'); }
csrf_require();
$dept = (int)($_POST['dept'] ?? 0);
if ($dept > 0) {
    $stmt = db()->prepare('SELECT id FROM departments WHERE id=?'); $stmt->bind_param('i', $dept); $stmt->execute();
    if (!$stmt->get_result()->fetch_assoc()) $dept = 0;
    $stmt->close();
}
$_SESSION['dept_filter'] = $dept;
// go back to the page the Principal was on (a plain page name only, never an outside address)
$back = basename((string)($_POST['back'] ?? 'dashboard.php'));
if (!preg_match('/^[a-z0-9-]+\.php$/', $back) || !user_can_access_page($back)) $back = 'dashboard.php';
header('Location: ' . $back);
exit;
