<?php
require_once __DIR__ . '/auth.php';

$user = current_user() ?? [];
$userName = $user['full_name'] ?? $user['name'] ?? 'User';
$role = $user['role'] ?? '';
$currentPage = basename($_SERVER['PHP_SELF']);

// Access level shown under the brand, matching the workflow chart's four levels.
$levelLabel = [
    'principal'        => 'College level access',
    'hod'              => 'Department level access',
    'class_incharge'   => 'Class level access',
    'subject_incharge' => 'Subject level access',
][$role] ?? '';
$deptLabel = $role === 'principal' ? 'College' : (string)($user['department'] ?? '');

$groups = [
    'MAIN' => [
        ['dashboard.php', 'Dashboard', '▦'],
    ],
    'COLLEGE' => [
        ['departments.php', 'Departments', '▥'],
        ['faculty.php', 'Faculty & Access', '♙'],
    ],
    'SETUP' => [
        ['program-outcomes.php', 'Program Outcomes (POs)', '◎'],
        ['classes.php', 'Classes & Sections', '▧'],
        ['students.php', 'Students', '♙'],
        ['subjects.php', 'Subjects', '▤'],
        ['course-outcomes.php', 'Course Outcomes (COs)', '◈'],
    ],
    'RECORD MARKS' => [
        ['marks.php', 'Sessional Marks', '✎'],
        ['internal-marks.php', 'Internal Marks', '◈'],
        ['unit-tests.php', 'Unit Tests', '◷'],
        ['assignments.php', 'Assignments & Activities', '▧'],
        ['practical-marks.php', 'Practical Marks', '⚗'],
    ],
    'ATTAINMENT' => [
        ['co-po-mapping.php', 'CO–PO Mapping', '▦'],
        ['attainment.php', 'CO/PO Attainment', '◎'],
        ['performance.php', 'Student Performance', '◉'],
        ['analytics.php', 'Analytics', '▥'],
        ['report.php', 'Reports & Export', '▤'],
        ['accreditation.php', 'Accreditation (NBA/NAAC)', '★'],
    ],
    'ADMIN' => [
        ['migrate.php', 'Database Upgrade', '⚙'],
    ],
];
?>
<aside class="sidebar">
    <div class="brand">
        <div class="brand-mark">CP</div>
        <div class="brand-text">
            <div class="t1">CO–PO Workspace</div>
            <div class="t2"><?= htmlspecialchars($deptLabel !== '' ? $deptLabel : 'Outcome monitoring') ?></div>
        </div>
    </div>
    <?php if ($levelLabel !== ''): ?>
        <div class="side-level"><?= htmlspecialchars($levelLabel) ?></div>
    <?php endif; ?>

    <?php if ($role === 'principal'):
        require_once __DIR__ . '/helpers.php';
        $deptChoices = []; $deptCurrent = 0;
        try { require_once __DIR__ . '/db.php'; $deptChoices = db()->query('SELECT id, name FROM departments ORDER BY name')->fetch_all(MYSQLI_ASSOC); $deptCurrent = principal_dept_filter(); } catch (Throwable $e) { $deptChoices = []; }
    ?>
        <form method="post" action="set-department.php" class="side-dept">
            <?= csrf_field() ?>
            <input type="hidden" name="back" value="<?= htmlspecialchars($currentPage) ?>">
            <label for="side-dept-select">Department view</label>
            <select id="side-dept-select" name="dept" onchange="this.form.submit()">
                <?php foreach ($deptChoices as $dc): ?>
                    <option value="<?= (int)$dc['id'] ?>" <?= $deptCurrent === (int)$dc['id'] ? 'selected' : '' ?>><?= htmlspecialchars($dc['name']) ?></option>
                <?php endforeach; ?>
                <option value="0" <?= $deptCurrent === 0 ? 'selected' : '' ?>>All departments</option>
            </select>
        </form>
    <?php endif; ?>

    <?php foreach ($groups as $groupName => $items): ?>
        <?php
        $visible = array_values(array_filter($items, fn($it) => user_can_access_page($it[0], $user)));
        if (!$visible) continue;
        ?>
        <div class="side-group-label"><?= htmlspecialchars($groupName) ?></div>
        <ul class="side-nav">
            <?php foreach ($visible as [$page, $label, $icon]): ?>
                <?php $active = $currentPage === $page; ?>
                <li>
                    <a href="<?= htmlspecialchars($page) ?>" class="<?= $active ? 'active' : '' ?>" <?= $active ? 'aria-current="page"' : '' ?>>
                        <span class="nav-icon"><?= htmlspecialchars($icon) ?></span>
                        <span><?= htmlspecialchars($label) ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endforeach; ?>

    <div class="foot">
        <div class="foot-user">
            <div class="av"><?= htmlspecialchars(strtoupper(substr($userName, 0, 1))) ?></div>
            <div>
                <div class="name"><?= htmlspecialchars($userName) ?></div>
                <div class="role"><?= htmlspecialchars(ucwords(str_replace('_', ' ', $role))) ?></div>
            </div>
        </div>
    </div>
</aside>
