<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('report.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/engine.php';
require_once __DIR__ . '/includes/export.php';

$conn = db();

/** Run a prepared SELECT and return all rows. */
function rep_rows(mysqli $conn, string $sql, string $types = '', array $params = []): array {
    $stmt = $conn->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

// Report types each role may run (matches the workflow chart's "Reports & Output" stage).
$allTypes = [
    'summary'    => 'Attainment summary (CO + PO)',
    'co'         => 'CO report',
    'po'         => 'PO report',
    'student'    => 'Student performance report',
    'subject'    => 'Subject report',
    'class'      => 'Class report',
    'department' => 'Department report',
];
$roleTypes = [
    'principal'        => ['department', 'summary', 'co', 'po', 'subject'],
    'hod'              => ['department', 'summary', 'co', 'po', 'subject', 'class', 'student'],
    'class_incharge'   => ['class', 'student'],
    'subject_incharge' => ['summary', 'co', 'po', 'subject', 'student'],
];
$typeKeys = $roleTypes[user_role()] ?? ['summary'];
$typeLabels = [];
foreach ($typeKeys as $k) $typeLabels[$k] = $allTypes[$k];

$sessions = $conn->query('SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
[$loginSessionId] = session_selected($conn);
$sessionId  = filter_input(INPUT_GET, 'session', FILTER_VALIDATE_INT) ?: $loginSessionId;
$semester   = filter_input(INPUT_GET, 'semester', FILTER_VALIDATE_INT) ?: 0;
if ($semester < 1 || $semester > 8) $semester = 0;
$reportType = (string)($_GET['reportType'] ?? $typeKeys[0]);
if (!isset($typeLabels[$reportType])) $reportType = $typeKeys[0];
$subjectId  = filter_input(INPUT_GET, 'subject', FILTER_VALIDATE_INT) ?: 0;
$studentSearch = trim((string)($_GET['student'] ?? ''));
$format = in_array($_GET['format'] ?? 'print', ['csv', 'xls'], true) ? (string)$_GET['format'] : 'print';
$sessionLabel = ''; foreach ($sessions as $s) if ((int)$s['id'] === $sessionId) $sessionLabel = $s['session_name'];

// subjects the user may pick
$subSql = 'SELECT id, subject_code, subject_name, semester FROM subjects WHERE academic_session_id=?';
$subTypes = 'i'; $subParams = [$sessionId];
if ($semester) { $subSql .= ' AND semester=?'; $subTypes .= 'i'; $subParams[] = $semester; }
$subjects = rep_rows($conn, $subSql . scope_subject_clause() . ' ORDER BY semester, subject_code', $subTypes, $subParams);
if ($subjectId && !array_filter($subjects, fn($s) => (int)$s['id'] === $subjectId)) $subjectId = 0;

$headers = []; $rows = []; $error = '';
if (isset($_GET['run'])) {
    try {
        $scopeSub = scope_subject_clause('sub');
        $subFilter = ''; $semFilter = ''; $bt = 'i'; $bp = [$sessionId];
        if ($subjectId) { $subFilter = ' AND sub.id=?'; $bt .= 'i'; $bp[] = $subjectId; }
        if ($semester)  { $semFilter = ' AND sub.semester=?'; $bt .= 'i'; $bp[] = $semester; }

        if (in_array($reportType, ['summary', 'co', 'po'], true)) {
            $sql = "SELECT ar.outcome_type, ar.outcome_code, sub.subject_code, sub.subject_name, sub.semester, ar.attainment_percent, ar.level_value, ar.students_attained, ar.students_total, ar.calculated_at, pot.title AS po_title
                    FROM attainment_results ar JOIN subjects sub ON sub.id=ar.subject_id
                    LEFT JOIN program_outcomes pot ON ar.outcome_type='PO' AND pot.department_id=sub.department_id AND pot.po_number=CAST(SUBSTRING(ar.outcome_code,3) AS UNSIGNED)
                    WHERE ar.academic_session_id=?" . $subFilter . $semFilter . $scopeSub;
            $t = $bt; $p = $bp;
            if ($reportType !== 'summary') { $sql .= ' AND ar.outcome_type=?'; $t .= 's'; $p[] = strtoupper($reportType); }
            $sql .= ' ORDER BY sub.semester, sub.subject_code, ar.outcome_type, CAST(SUBSTRING(ar.outcome_code,3) AS UNSIGNED)';
            $headers = ['Type', 'Subject', 'Semester', 'Outcome', 'Title', 'Attained %', 'Level (0-3)', 'Students attained', 'Calculated on'];
            foreach (rep_rows($conn, $sql, $t, $p) as $r) {
                $rows[] = [$r['outcome_type'], $r['subject_code'] . ' — ' . $r['subject_name'], $r['semester'], $r['outcome_code'], $r['po_title'] ?? '',
                    number_format((float)$r['attainment_percent'], 2) . '%', $r['level_value'] === null ? '' : number_format((float)$r['level_value'], 2),
                    $r['students_total'] === null ? '' : $r['students_attained'] . ' / ' . $r['students_total'], date('d M Y', strtotime((string)$r['calculated_at']))];
            }
        } elseif ($reportType === 'subject') {
            $sql = "SELECT sub.subject_code, sub.subject_name, sub.semester, u.full_name AS incharge,
                        (SELECT COUNT(DISTINCT m.enrollment_id) FROM marks m JOIN assessment_components ac ON ac.id=m.assessment_component_id WHERE ac.subject_id=sub.id) AS assessed,
                        (SELECT COUNT(*) FROM course_outcomes co WHERE co.subject_id=sub.id) AS cos,
                        (SELECT AVG(ar.level_value) FROM attainment_results ar WHERE ar.subject_id=sub.id AND ar.academic_session_id=sub.academic_session_id AND ar.outcome_type='CO') AS co_level,
                        (SELECT AVG(ar.level_value) FROM attainment_results ar WHERE ar.subject_id=sub.id AND ar.academic_session_id=sub.academic_session_id AND ar.outcome_type='PO') AS po_level
                    FROM subjects sub LEFT JOIN users u ON u.id=sub.subject_incharge_id
                    WHERE sub.academic_session_id=?" . $subFilter . $semFilter . $scopeSub . ' ORDER BY sub.semester, sub.subject_code';
            $headers = ['Subject', 'Semester', 'Subject incharge', 'Course outcomes', 'Students assessed', 'Avg CO level', 'Avg PO level'];
            foreach (rep_rows($conn, $sql, $bt, $bp) as $r) {
                $rows[] = [$r['subject_code'] . ' — ' . $r['subject_name'], $r['semester'], $r['incharge'] ?? 'Unassigned', $r['cos'], $r['assessed'],
                    $r['co_level'] === null ? '—' : number_format((float)$r['co_level'], 2), $r['po_level'] === null ? '—' : number_format((float)$r['po_level'], 2)];
            }
        } elseif ($reportType === 'student') {
            $scopeSt = scope_student_clause($conn, $sessionId, 'se', 'st');
            $sql = "SELECT st.enrollment_no, st.full_name, sub.subject_code, sub.subject_name, sub.semester, ac.component_name, ac.component_type,
                        SUM(m.marks_obtained) AS got, ac.max_marks * COUNT(m.id) AS maxm
                    FROM marks m JOIN student_enrollments se ON se.id=m.enrollment_id JOIN students st ON st.id=se.student_id
                    JOIN assessment_components ac ON ac.id=m.assessment_component_id JOIN subjects sub ON sub.id=ac.subject_id
                    WHERE se.academic_session_id=?" . $subFilter . $semFilter . $scopeSub . $scopeSt;
            $t = $bt; $p = $bp;
            if ($studentSearch !== '') { $sql .= ' AND (st.enrollment_no LIKE ? OR st.full_name LIKE ?)'; $t .= 'ss'; $like = '%' . $studentSearch . '%'; $p[] = $like; $p[] = $like; }
            $sql .= ' GROUP BY st.id, sub.id, ac.id ORDER BY sub.semester, sub.subject_code, st.enrollment_no, ac.component_type, ac.component_name LIMIT 5000';
            $headers = ['Enrollment no.', 'Student', 'Subject', 'Semester', 'Assessment', 'Type', 'Marks', 'Out of', '%'];
            foreach (rep_rows($conn, $sql, $t, $p) as $r) {
                $maxm = (float)$r['maxm'];
                $rows[] = [$r['enrollment_no'], $r['full_name'], $r['subject_code'] . ' — ' . $r['subject_name'], $r['semester'], $r['component_name'], $r['component_type'],
                    number_format((float)$r['got'], 2), number_format($maxm, 2), $maxm > 0 ? number_format((float)$r['got'] / $maxm * 100, 1) . '%' : '—'];
            }
        } elseif ($reportType === 'class') {
            $scopeSt = scope_student_clause($conn, $sessionId, 'se', 'st');
            $sql = "SELECT d.name AS department, se.semester, se.section, COUNT(DISTINCT se.id) AS students,
                        COALESCE(SUM(m.marks_obtained),0) AS got, COALESCE(SUM(ac.max_marks),0) AS maxm
                    FROM student_enrollments se JOIN students st ON st.id=se.student_id LEFT JOIN departments d ON d.id=st.department_id
                    LEFT JOIN marks m ON m.enrollment_id=se.id LEFT JOIN assessment_components ac ON ac.id=m.assessment_component_id
                    WHERE se.academic_session_id=? AND se.status='active'" . ($semester ? ' AND se.semester=' . (int)$semester : '') . $scopeSt . '
                    GROUP BY st.department_id, se.semester, se.section ORDER BY d.name, se.semester, se.section';
            $headers = ['Department', 'Semester', 'Section', 'Students', 'Average marks %'];
            foreach (rep_rows($conn, $sql, 'i', [$sessionId]) as $r) {
                $maxm = (float)$r['maxm'];
                $rows[] = [$r['department'] ?? '—', $r['semester'], $r['section'], $r['students'], $maxm > 0 ? number_format((float)$r['got'] / $maxm * 100, 1) . '%' : 'No marks yet'];
            }
        } elseif ($reportType === 'department') {
            $headers = ['Department', 'Subjects', 'Subjects calculated', 'Avg CO level', 'POs calculated', 'POs at/above target', 'PO levels'];
            foreach (scope_departments($conn) as $d) {
                $did = (int)$d['id']; $settings = engine_settings($conn, $did);
                $subs = engine_co_by_subject($conn, $sessionId, $did, $semester ?: null);
                $calc = 0; $sum = 0.0; $n = 0;
                foreach ($subs as $s) if ((int)$s['co_count'] > 0) { $calc++; if ($s['avg_level'] !== null) { $sum += (float)$s['avg_level']; $n++; } }
                $roll = engine_po_rollup($conn, $sessionId, $did, $semester ?: null);
                $met = 0; $parts = [];
                foreach ($roll as $po => $v) { if ($v['level'] >= $settings['po_target_level']) $met++; $parts[] = 'PO' . $po . ' ' . number_format($v['level'], 2); }
                $rows[] = [$d['name'], count($subs), $calc, $n ? number_format($sum / $n, 2) : '—', count($roll), $met, implode(', ', $parts)];
            }
        }
    } catch (Throwable $e) {
        error_log('report.php: ' . $e->getMessage());
        $error = 'Could not generate this report. If you have not yet, run the database upgrade (migrate.php) and check the selected filters.';
    }
    if (!$error && in_array($format, ['csv', 'xls'], true)) {
        audit_write($conn, 'report.export', 'report', null, ['type' => $reportType, 'format' => $format, 'session' => $sessionId, 'rows' => count($rows)]);
        export_send($format, $reportType . '_' . $sessionLabel, $headers, $rows);
    }
}
$self = 'report.php?' . http_build_query(['run' => 1, 'session' => $sessionId, 'semester' => $semester, 'reportType' => $reportType, 'subject' => $subjectId, 'student' => $studentSearch]);
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reports & Export — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Reports & Export'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow">REPORTS &amp; OUTPUT</div><h1>Reports &amp; Export</h1><p>Prepare reports from recorded marks and saved CO/PO attainment, limited to the data your role can access. Export to CSV or Excel, or print / save as PDF.</p></div></div>

<form method="get" class="card no-print"><input type="hidden" name="run" value="1">
<div class="card-head"><div><h2>Report filters</h2><span>Choose what to include</span></div></div>
<div class="panel-body"><div class="form-row tight">
<div class="field"><label>Academic session</label><select class="control" name="session"><?php foreach ($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $sessionId === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['session_name']) ?><?= (int)$s['is_active'] ? ' (Active)' : '' ?></option><?php endforeach; ?></select></div>
<div class="field"><label>Semester</label><select class="control" name="semester"><option value="0">All semesters</option><?php for ($i = 1; $i <= 8; $i++): ?><option value="<?= $i ?>" <?= $semester === $i ? 'selected' : '' ?>>Semester <?= $i ?></option><?php endfor; ?></select></div>
<div class="field"><label>Report</label><select class="control" name="reportType"><?php foreach ($typeLabels as $k => $label): ?><option value="<?= h($k) ?>" <?= $reportType === $k ? 'selected' : '' ?>><?= h($label) ?></option><?php endforeach; ?></select></div>
<div class="field"><label>Subject</label><select class="control" name="subject"><option value="0">All subjects</option><?php foreach ($subjects as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $subjectId === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['subject_code'] . ' — ' . $s['subject_name'] . ' (Sem ' . $s['semester'] . ')') ?></option><?php endforeach; ?></select></div>
<div class="field"><label>Student (roll no. / name)</label><input class="control" name="student" value="<?= h($studentSearch) ?>" placeholder="Student report only"></div>
</div>
<div class="form-actions"><button class="btn btn-primary" type="submit" name="format" value="print">Prepare report</button><button class="btn btn-outline" type="submit" name="format" value="csv">Download CSV</button><button class="btn btn-outline" type="submit" name="format" value="xls">Download Excel</button><a class="btn btn-outline" href="report.php">Clear</a></div></div></form>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2><?= isset($_GET['run']) ? h($typeLabels[$reportType]) : 'Report preview' ?></h2><span><?= isset($_GET['run']) ? h($sessionLabel . ($semester ? ' · Semester ' . $semester : '') . ' · ' . count($rows) . ' rows') : 'No report generated yet' ?></span></div>
<?php if (isset($_GET['run']) && !$error): ?><div class="export-bar no-print"><a class="btn btn-outline btn-sm" href="<?= h($self) ?>&format=csv">CSV</a><a class="btn btn-outline btn-sm" href="<?= h($self) ?>&format=xls">Excel</a><button class="btn btn-gold btn-sm" type="button" onclick="window.print()">Print / PDF</button></div><?php endif; ?></div>
<?php if ($error): ?><div class="muted-empty"><?= h($error) ?></div>
<?php elseif (!isset($_GET['run'])): ?><div class="muted-empty">Choose filters and select <b>Prepare report</b> to load records from the database.</div>
<?php elseif (!$rows): ?><div class="muted-empty">No matching records. Check that marks are entered and attainment has been calculated for the selected filters.</div>
<?php else: ?><div class="table-wrap"><table class="data"><thead><tr><?php foreach ($headers as $hd): ?><th><?= h($hd) ?></th><?php endforeach; ?></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><?php foreach ($r as $cell): ?><td><?= h($cell) ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div>
</section></div></main></div></body></html>
