<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('attainment.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/engine.php';

$conn = db();
$msg = ''; $error = ''; $run = null;

$sessions = $conn->query('SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
[$loginSessionId] = session_selected($conn);
$sessionId = filter_input(INPUT_GET, 'session_id', FILTER_VALIDATE_INT) ?: $loginSessionId;
$semester  = filter_input(INPUT_GET, 'semester', FILTER_VALIDATE_INT) ?: 1;
$subjectId = filter_input(INPUT_GET, 'subject_id', FILTER_VALIDATE_INT) ?: 0;
if ($semester < 1 || $semester > 8) $semester = 1;

/* ---- save attainment rules (HOD: own department, Principal: college default or any department) ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_settings') {
    csrf_require();
    try {
        if (!role_is('principal', 'hod')) throw new RuntimeException('Only the HOD or Principal can change attainment rules.');
        $target = (float)($_POST['target_percent'] ?? 0);
        $l3 = (float)($_POST['level3_min'] ?? 0); $l2 = (float)($_POST['level2_min'] ?? 0); $l1 = (float)($_POST['level1_min'] ?? 0);
        $coT = (float)($_POST['co_target_level'] ?? 0); $poT = (float)($_POST['po_target_level'] ?? 0);
        if ($target <= 0 || $target > 100) throw new RuntimeException('Student target must be between 1 and 100 percent.');
        foreach ([$l3, $l2, $l1] as $v) if ($v < 0 || $v > 100) throw new RuntimeException('Level thresholds must be between 0 and 100 percent.');
        if (!($l3 >= $l2 && $l2 >= $l1)) throw new RuntimeException('Thresholds must satisfy Level 3 ≥ Level 2 ≥ Level 1.');
        if ($coT < 0 || $coT > 3 || $poT < 0 || $poT > 3) throw new RuntimeException('Target levels must be between 0 and 3.');
        $uid = user_id_int();
        if (role_is('hod')) { $scopeDept = user_department_id($conn); }
        else { $scopeDept = (int)($_POST['settings_scope'] ?? 0); }   // 0 = college default
        if (role_is('hod') && $scopeDept < 1) throw new RuntimeException('Your account is not linked to a department.');
        if ($scopeDept > 0) {
            $stmt = $conn->prepare('SELECT id FROM attainment_settings WHERE department_id=? LIMIT 1');
            $stmt->bind_param('i', $scopeDept);
        } else {
            $stmt = $conn->prepare('SELECT id FROM attainment_settings WHERE department_id IS NULL LIMIT 1');
        }
        $stmt->execute(); $existing = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($existing) {
            $rid = (int)$existing['id'];
            $stmt = $conn->prepare('UPDATE attainment_settings SET target_percent=?, level3_min=?, level2_min=?, level1_min=?, co_target_level=?, po_target_level=?, updated_by=? WHERE id=?');
            $stmt->bind_param('ddddddii', $target, $l3, $l2, $l1, $coT, $poT, $uid, $rid);
        } elseif ($scopeDept > 0) {
            $stmt = $conn->prepare('INSERT INTO attainment_settings(department_id,target_percent,level3_min,level2_min,level1_min,co_target_level,po_target_level,updated_by) VALUES (?,?,?,?,?,?,?,?)');
            $stmt->bind_param('iddddddi', $scopeDept, $target, $l3, $l2, $l1, $coT, $poT, $uid);
        } else {
            $stmt = $conn->prepare('INSERT INTO attainment_settings(department_id,target_percent,level3_min,level2_min,level1_min,co_target_level,po_target_level,updated_by) VALUES (NULL,?,?,?,?,?,?,?)');
            $stmt->bind_param('ddddddi', $target, $l3, $l2, $l1, $coT, $poT, $uid);
        }
        $stmt->execute(); $stmt->close();
        audit_write($conn, 'settings.save', 'attainment_settings', null, ['department_id' => $scopeDept, 'target' => $target, 'l3' => $l3, 'l2' => $l2, 'l1' => $l1]);
        $msg = 'Attainment rules saved. Recalculate a subject to apply them to its results.';
    } catch (Throwable $e) {
        $error = $e instanceof RuntimeException ? $e->getMessage() : 'Could not save the rules. Run the database upgrade (migrate.php) first.';
    }
}

/* ---- scoped subject list for the chosen session + semester ---- */
function att_subjects(mysqli $conn, int $sessionId, int $semester): array {
    $sql = 'SELECT id, subject_code, subject_name, department_id FROM subjects WHERE academic_session_id=? AND semester=?' . scope_subject_clause() . ' ORDER BY subject_code';
    $stmt = $conn->prepare($sql); $stmt->bind_param('ii', $sessionId, $semester); $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    return $rows;
}

/* ---- run the calculation pipeline ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'calculate' && !role_is('principal', 'subject_incharge')) {
    $error = 'Attainment is calculated by the Subject Incharge of each subject. You can view the saved results below.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'calculate') {
    csrf_require();
    $sessionId = (int)($_POST['session_id'] ?? 0);
    $semester  = (int)($_POST['semester'] ?? 0);
    $subjectId = (int)($_POST['subject_id'] ?? 0);
    if ($sessionId < 1 || $semester < 1 || $semester > 8 || $subjectId < 1) {
        $error = 'Please select a valid session, semester and subject.';
    } elseif (!scope_can_use_subject($conn, $subjectId)) {
        http_response_code(403);
        $error = 'You do not have access to this subject.';
    } else {
        $run = engine_calculate_subject($conn, $subjectId, $sessionId, $semester);
        if ($run['ok']) {
            $msg = 'Attainment calculated and saved.';
            audit_write($conn, 'attainment.calculate', 'subject', $subjectId, ['session_id' => $sessionId, 'semester' => $semester]);
        } else {
            $error = $run['error'];
        }
    }
}

$subjects = att_subjects($conn, $sessionId, $semester);
$subjectRow = null;
foreach ($subjects as $s) if ((int)$s['id'] === $subjectId) $subjectRow = $s;
if (!$subjectRow) $subjectId = 0;

$deptForRules = $subjectRow && $subjectRow['department_id'] !== null ? (int)$subjectRow['department_id'] : (role_is('principal') ? null : user_department_id($conn));
$settings = engine_settings($conn, $deptForRules);

$coResults = []; $poResults = []; $poTitles = [];
if ($subjectId > 0) {
    $stmt = $conn->prepare("SELECT outcome_code, attainment_percent, level_value, students_total, students_attained, calculated_at FROM attainment_results WHERE subject_id=? AND academic_session_id=? AND semester=? AND outcome_type='CO' ORDER BY outcome_code");
    $stmt->bind_param('iii', $subjectId, $sessionId, $semester); $stmt->execute(); $coResults = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    $stmt = $conn->prepare("SELECT outcome_code, attainment_percent, level_value, calculated_at FROM attainment_results WHERE subject_id=? AND academic_session_id=? AND semester=? AND outcome_type='PO' ORDER BY CAST(SUBSTRING(outcome_code,3) AS UNSIGNED)");
    $stmt->bind_param('iii', $subjectId, $sessionId, $semester); $stmt->execute(); $poResults = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    if ($subjectRow && $subjectRow['department_id'] !== null) {
        try {
            $d = (int)$subjectRow['department_id'];
            $stmt = $conn->prepare('SELECT po_number, title FROM program_outcomes WHERE department_id=?');
            $stmt->bind_param('i', $d); $stmt->execute();
            foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $r) $poTitles[(int)$r['po_number']] = $r['title'];
            $stmt->close();
        } catch (Throwable $e) { /* program_outcomes table not created yet */ }
    }
}
$departments = role_is('principal') ? scope_departments($conn) : [];
$canEditRules = role_is('principal', 'hod');
$canCalc = role_is('principal', 'subject_incharge');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>CO/PO Attainment — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css">
<style>.attain-form{display:flex;gap:14px;align-items:flex-end;flex-wrap:wrap;padding:18px 20px}.attain-form .field{display:flex;flex-direction:column;gap:6px;min-width:170px}.attain-form label{font-size:11px;color:#69768a}.attain-form select{height:37px;min-width:180px;padding:0 10px;border:1px solid var(--line);border-radius:4px;background:#fff}.attain-table{width:100%;border-collapse:collapse}.attain-table th,.attain-table td{padding:11px 15px;border-bottom:1px solid var(--line2);text-align:left;font-size:12px}.attain-table th{background:#f7f8f6;color:#53627a;font-size:10.5px}.attain-table tr:last-child td{border-bottom:0}.bar-track{min-width:100px}</style>
<script>function changeContext(){var s=document.getElementById('session_id').value,m=document.getElementById('semester').value;window.location='attainment.php?session_id='+encodeURIComponent(s)+'&semester='+encodeURIComponent(m);}</script>
</head>
<body>
<div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('CO/PO Attainment'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow">PROCESSING & CALCULATION PIPELINE</div><h1>CO/PO Attainment</h1><p>Validate marks, compute CO attainment, apply the CO–PO mapping and derive PO attainment for a subject.</p></div></div>
<?php ui_notice($msg, 'ok'); ui_notice($error, 'err'); ?>

<div class="card">
<div class="card-head"><div><h2>Calculate attainment</h2><span>Select the academic context, then run the pipeline on the recorded marks.</span></div></div>
<form method="<?= $canCalc ? 'post' : 'get' ?>" class="attain-form"><?php if ($canCalc): ?><?= csrf_field() ?>
<input type="hidden" name="action" value="calculate"><?php endif; ?>
<div class="field"><label for="session_id">Academic session</label><select name="session_id" id="session_id" required onchange="changeContext()"><?php foreach ($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $sessionId === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['session_name']) ?><?= (int)$s['is_active'] ? ' (Active)' : '' ?></option><?php endforeach; ?></select></div>
<div class="field"><label for="semester">Semester</label><select name="semester" id="semester" required onchange="changeContext()"><?php for ($i = 1; $i <= 8; $i++): ?><option value="<?= $i ?>" <?= $semester === $i ? 'selected' : '' ?>>Semester <?= $i ?></option><?php endfor; ?></select></div>
<div class="field"><label for="subject_id">Subject</label><select name="subject_id" id="subject_id" required><option value="">Select subject</option><?php foreach ($subjects as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $subjectId === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['subject_code'] . ' — ' . $s['subject_name']) ?></option><?php endforeach; ?></select></div>
<button type="submit" class="btn btn-gold"><?= $canCalc ? 'Calculate &amp; save' : 'View results' ?></button>
</form>
<?php
$stages = $run['stages'] ?? [];
$labels = ['Marks validation', 'Total / percentage', 'CO attainment', 'CO–PO mapping', 'PO attainment', 'Analytics & reports'];
$byLabel = []; foreach ($stages as $st) $byLabel[$st[0]] = $st;
?>
<div class="pipeline">
<?php foreach ($labels as $i => $label): $st = $byLabel[$label] ?? null; ?>
  <div class="stage <?= $st ? h($st[2]) : 'idle' ?>"><b><?= ($i + 1) . '. ' . h($label) ?></b><span><?= $st ? h($st[1]) : 'Runs when you calculate' ?></span></div>
<?php endforeach; ?>
</div>
<?php if (!empty($run['warnings'])): ?><div class="help-text"><strong>Please review:</strong><br><?= implode('<br>', array_map('h', $run['warnings'])) ?></div><?php endif; ?>
<div class="help-text"><strong>Method in use.</strong> A student attains a CO when their marks for that CO reach <b><?= h(rtrim(rtrim(number_format($settings['target_percent'], 2), '0'), '.')) ?>%</b>. CO level = 3 if ≥ <?= h(rtrim(rtrim(number_format($settings['level3_min'], 2), '0'), '.')) ?>% of assessed students attain it, 2 if ≥ <?= h(rtrim(rtrim(number_format($settings['level2_min'], 2), '0'), '.')) ?>%, 1 if ≥ <?= h(rtrim(rtrim(number_format($settings['level1_min'], 2), '0'), '.')) ?>%, otherwise 0. PO level = mapping-weighted average (mapping 1/2/3) of the linked CO levels. Only students with recorded marks for a CO are counted; invalid marks are excluded. These are common defaults — confirm them against your college's approved scheme.</div>
</div>

<?php if ($canEditRules): ?>
<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Attainment rules</h2><span><?= role_is('hod') ? 'Applies to your department' : 'College default or a specific department' ?></span></div></div>
<form method="post" class="panel-body"><?= csrf_field() ?><input type="hidden" name="action" value="save_settings">
<div class="form-row">
<?php if (role_is('principal')): ?><div class="field"><label>Applies to</label><select class="control" name="settings_scope"><option value="0">College default</option><?php foreach ($departments as $d): ?><option value="<?= (int)$d['id'] ?>"><?= h($d['name']) ?></option><?php endforeach; ?></select></div><?php endif; ?>
<div class="field"><label>Student target (%)</label><input class="control" type="number" step="0.01" min="1" max="100" name="target_percent" value="<?= h($settings['target_percent']) ?>"></div>
<div class="field"><label>Level 3 at ≥ (% students)</label><input class="control" type="number" step="0.01" min="0" max="100" name="level3_min" value="<?= h($settings['level3_min']) ?>"></div>
<div class="field"><label>Level 2 at ≥ (% students)</label><input class="control" type="number" step="0.01" min="0" max="100" name="level2_min" value="<?= h($settings['level2_min']) ?>"></div>
<div class="field"><label>Level 1 at ≥ (% students)</label><input class="control" type="number" step="0.01" min="0" max="100" name="level1_min" value="<?= h($settings['level1_min']) ?>"></div>
<div class="field"><label>CO target level (0–3)</label><input class="control" type="number" step="0.01" min="0" max="3" name="co_target_level" value="<?= h($settings['co_target_level']) ?>"></div>
<div class="field"><label>PO target level (0–3)</label><input class="control" type="number" step="0.01" min="0" max="3" name="po_target_level" value="<?= h($settings['po_target_level']) ?>"></div>
</div>
<div class="form-actions"><button class="btn btn-primary" type="submit">Save rules</button></div></form></div>
<?php endif; ?>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Course Outcome attainment</h2><span>Saved results for the selected session, semester and subject.</span></div><a class="btn btn-outline" href="co-po-mapping.php?session_id=<?= (int)$sessionId ?>&semester=<?= (int)$semester ?>&subject_id=<?= (int)$subjectId ?>">Review CO–PO mapping</a></div>
<?php if (!$subjectId): ?><div class="muted-empty">Select a subject above to view its saved attainment.</div>
<?php elseif (!$coResults): ?><div class="muted-empty">No CO attainment saved yet. Enter marks and choose Calculate &amp; save.</div>
<?php else: ?><div class="table-wrap"><table class="attain-table"><thead><tr><th>Course Outcome</th><th>Students attained</th><th>% attained</th><th>Level (0–3)</th><th>Progress</th><th>Last calculated</th></tr></thead><tbody>
<?php foreach ($coResults as $r): $pct = (float)$r['attainment_percent']; $lvl = $r['level_value'] === null ? null : (float)$r['level_value']; ?>
<tr><td><b><?= h($r['outcome_code']) ?></b></td><td><?= $r['students_total'] === null ? '—' : (int)$r['students_attained'] . ' / ' . (int)$r['students_total'] ?></td><td><?= number_format($pct, 2) ?>%</td><td><?= ui_level_badge($lvl, $settings['co_target_level']) ?></td><td><div class="bar-track"><div class="bar-fill <?= $pct >= 60 ? 'green' : ($pct < 40 ? 'rust' : '') ?>" style="width:<?= min(100, max(0, $pct)) ?>%"></div></div></td><td><?= h($r['calculated_at']) ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Program Outcome attainment</h2><span>Derived from the mapped CO levels; unmapped POs are not shown.</span></div><a class="btn btn-outline" href="report.php">Open reports</a></div>
<?php if (!$subjectId): ?><div class="muted-empty">Select a subject above to view its PO attainment.</div>
<?php elseif (!$poResults): ?><div class="muted-empty">No PO results yet. Save the CO–PO mapping, then calculate again.</div>
<?php else: ?><div class="table-wrap"><table class="attain-table"><thead><tr><th>Program Outcome</th><th>Title</th><th>Level (0–3)</th><th>Attainment</th><th>Progress</th><th>Last calculated</th></tr></thead><tbody>
<?php foreach ($poResults as $r): $pct = (float)$r['attainment_percent']; $lvl = $r['level_value'] === null ? null : (float)$r['level_value']; $poNo = (int)substr($r['outcome_code'], 2); ?>
<tr><td><b><?= h($r['outcome_code']) ?></b></td><td><?= h($poTitles[$poNo] ?? '—') ?></td><td><?= ui_level_badge($lvl, $settings['po_target_level']) ?></td><td><?= number_format($pct, 2) ?>%</td><td><div class="bar-track"><div class="bar-fill <?= $pct >= 60 ? 'green' : ($pct < 40 ? 'rust' : '') ?>" style="width:<?= min(100, max(0, $pct)) ?>%"></div></div></td><td><?= h($r['calculated_at']) ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
</section></div></main></div>
</body></html>
