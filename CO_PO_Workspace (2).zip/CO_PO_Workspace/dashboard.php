<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('dashboard.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/engine.php';

$conn = db();
$user = current_user() ?? [];
$role = user_role();
[$sessionId, $sessionName] = session_selected($conn);
$deptId = user_department_id($conn);

function dash_one(mysqli $conn, string $sql, string $types = '', array $params = []) {
    $stmt = $conn->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_row();
    $stmt->close();
    return $row ? $row[0] : null;
}
function dash_rows(mysqli $conn, string $sql, string $types = '', array $params = []): array {
    $stmt = $conn->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

$notice = '';
$kpis = []; $subjects = []; $classes = []; $deptRows = []; $poRoll = []; $poTitles = []; $poTarget = 2.0; $coTarget = 2.0;

try {
    // ---- subjects within this role's scope, with workflow progress ----
    $subjects = dash_rows($conn, "SELECT s.id, s.subject_code, s.subject_name, s.semester, s.academic_session_id, d.name AS department,
            (SELECT COUNT(*) FROM course_outcomes WHERE subject_id=s.id) AS cos,
            (SELECT COUNT(*) FROM assessment_components WHERE subject_id=s.id) AS comps,
            (SELECT COUNT(*) FROM marks m JOIN assessment_components ac ON ac.id=m.assessment_component_id WHERE ac.subject_id=s.id) AS mark_rows,
            (SELECT COUNT(DISTINCT m2.course_outcome_id) FROM co_po_mapping m2 JOIN course_outcomes c2 ON c2.id=m2.course_outcome_id WHERE c2.subject_id=s.id AND m2.mapping_level>0) AS mapped_cos,
            (SELECT COUNT(*) FROM attainment_results r WHERE r.subject_id=s.id AND r.academic_session_id=s.academic_session_id AND r.outcome_type='CO') AS calc_cos,
            (SELECT AVG(r2.level_value) FROM attainment_results r2 WHERE r2.subject_id=s.id AND r2.academic_session_id=s.academic_session_id AND r2.outcome_type='CO') AS avg_level
        FROM subjects s LEFT JOIN departments d ON d.id=s.department_id
        WHERE s.academic_session_id=?" . scope_subject_clause('s') . ' ORDER BY s.semester, s.subject_code', 'i', [$sessionId]);

    $students = (int)dash_one($conn, "SELECT COUNT(DISTINCT se.student_id) FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE se.academic_session_id=? AND se.status='active'" . scope_student_clause($conn, $sessionId), 'i', [$sessionId]);
    $calculated = count(array_filter($subjects, fn($s) => (int)$s['calc_cos'] > 0));
    $levels = array_filter(array_map(fn($s) => $s['avg_level'], $subjects), fn($v) => $v !== null);
    $avgLevel = $levels ? array_sum(array_map('floatval', $levels)) / count($levels) : null;

    $settings = engine_settings($conn, $role === 'principal' ? null : ($deptId ?: null));
    $poTarget = $settings['po_target_level']; $coTarget = $settings['co_target_level'];

    if ($role === 'principal') {
        $deptRows = dash_rows($conn, "SELECT d.id, d.name,
              (SELECT COUNT(*) FROM subjects s WHERE s.department_id=d.id AND s.academic_session_id=?) AS subjects,
              (SELECT COUNT(DISTINCT st.id) FROM students st JOIN student_enrollments se ON se.student_id=st.id WHERE st.department_id=d.id AND se.academic_session_id=? AND se.status='active') AS students,
              (SELECT AVG(r.level_value) FROM attainment_results r JOIN subjects s2 ON s2.id=r.subject_id WHERE s2.department_id=d.id AND r.outcome_type='CO' AND r.academic_session_id=?) AS avg_level
            FROM departments d ORDER BY d.name", 'iii', [$sessionId, $sessionId, $sessionId]);
        $pf = principal_dept_filter();
        $poRoll = engine_po_rollup($conn, $sessionId, $pf > 0 ? $pf : null);
        $faculty = (int)dash_one($conn, "SELECT COUNT(*) FROM users WHERE active=1 AND role<>'principal'");
        $kpis = [['Departments', count($deptRows), 'In the college'], ['Faculty accounts', $faculty, 'HOD, class and subject incharges'],
                 ['Students', $students, $sessionName . ($pf > 0 ? ' · selected department' : ' · all departments')], ['Avg CO level', $avgLevel === null ? '—' : number_format($avgLevel, 2), 'Target ' . number_format($coTarget, 2) . ' (0–3 scale)']];
    } elseif ($role === 'hod') {
        $poRoll = engine_po_rollup($conn, $sessionId, $deptId ?: null);
        $definedPos = (int)dash_one($conn, 'SELECT COUNT(*) FROM program_outcomes WHERE department_id=?', 'i', [$deptId]);
        $kpis = [['Students', $students, 'Your department · ' . $sessionName], ['Subjects', count($subjects), $calculated . ' with attainment calculated'],
                 ['Avg CO level', $avgLevel === null ? '—' : number_format($avgLevel, 2), 'Target ' . number_format($coTarget, 2)], ['POs defined', $definedPos . ' / 12', $definedPos < 12 ? 'Add the remaining POs' : 'Complete']];
        $poTitles = [];
        foreach (dash_rows($conn, 'SELECT po_number, title FROM program_outcomes WHERE department_id=?', 'i', [$deptId]) as $r) $poTitles[(int)$r['po_number']] = $r['title'];
    } elseif ($role === 'class_incharge') {
        foreach (scope_class_rows($conn, $sessionId) as $c) {
            $row = dash_rows($conn, "SELECT COUNT(DISTINCT se.id) AS students, COALESCE(SUM(m.marks_obtained),0) AS got, COALESCE(SUM(ac.max_marks),0) AS maxm
                FROM student_enrollments se JOIN students st ON st.id=se.student_id
                LEFT JOIN marks m ON m.enrollment_id=se.id LEFT JOIN assessment_components ac ON ac.id=m.assessment_component_id
                WHERE se.academic_session_id=? AND st.department_id=? AND se.semester=? AND se.section=? AND se.status='active'",
                'iiis', [$sessionId, (int)$c['department_id'], (int)$c['semester'], (string)$c['section']])[0];
            $classes[] = ['dept' => (int)$c['department_id'], 'semester' => (int)$c['semester'], 'section' => (string)$c['section'], 'students' => (int)$row['students'],
                          'pct' => (float)$row['maxm'] > 0 ? round((float)$row['got'] / (float)$row['maxm'] * 100, 1) : null];
        }
        $kpis = [['Assigned classes', count($classes), $sessionName], ['Students', array_sum(array_column($classes, 'students')), 'In your classes'],
                 ['Class average', ($classes && count(array_filter(array_column($classes, 'pct'), fn($v) => $v !== null)) > 0) ? number_format(array_sum(array_filter(array_column($classes, 'pct'), fn($v) => $v !== null)) / count(array_filter(array_column($classes, 'pct'), fn($v) => $v !== null)), 1) . '%' : '—', 'Marks recorded so far'],
                 ['Subjects in my class', count($subjects), 'Marks can be entered for these']];
    } else { // subject_incharge
        $kpis = [['My subjects', count($subjects), $sessionName], ['Calculated', $calculated . ' / ' . count($subjects), 'Attainment results saved'],
                 ['Students', $students, 'In my subjects'], ['Avg CO level', $avgLevel === null ? '—' : number_format($avgLevel, 2), 'Target ' . number_format($coTarget, 2)]];
    }
} catch (Throwable $e) {
    error_log('dashboard: ' . $e->getMessage());
    $notice = 'Some dashboard figures could not be loaded. If this is an upgraded install, run the database upgrade (Database Upgrade in the menu, principal only).';
}

/** Which step of the workflow is next for a subject, and where to do it. */
function dash_next_step(array $s): array {
    $qs = 'session_id=' . (int)$s['academic_session_id'] . '&semester=' . (int)$s['semester'] . '&subject_id=' . (int)$s['id'];
    if ((int)$s['cos'] === 0)          return ['Add course outcomes', 'course-outcomes.php?' . $qs];
    if ((int)$s['comps'] === 0)        return ['Add assessments', 'marks.php?' . $qs];
    if ((int)$s['mark_rows'] === 0)    return ['Enter marks', 'marks.php?' . $qs];
    if ((int)$s['mapped_cos'] < (int)$s['cos']) return ['Complete CO–PO mapping', 'co-po-mapping.php?' . $qs];
    if ((int)$s['calc_cos'] === 0)     return ['Calculate attainment', 'attainment.php?' . $qs];
    return ['Up to date', 'attainment.php?' . $qs];
}
function dash_dot(bool $ok): string { return '<span class="badge ' . ($ok ? 'green' : 'grey') . '">' . ($ok ? '✓' : '–') . '</span>'; }
$eyebrow = ['principal' => 'COLLEGE DASHBOARD', 'hod' => 'DEPARTMENT DASHBOARD', 'class_incharge' => 'CLASS DASHBOARD', 'subject_incharge' => 'SUBJECT DASHBOARD'][$role] ?? 'DASHBOARD';
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css">
<style>.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:20px}.kpi{background:#fff;border:1px solid var(--line);border-radius:5px;padding:16px 18px}.kpi .k-label{font-size:11px;color:#617087;font-weight:600}.kpi .k-value{font-family:Georgia,serif;font-size:26px;font-weight:600;margin-top:8px;color:var(--text)}.kpi .k-note{font-size:11px;color:#7d899b;margin-top:6px}.po-bars{display:flex;flex-direction:column;gap:11px;padding:18px 20px}.po-row{display:grid;grid-template-columns:54px 1fr 48px;gap:10px;align-items:center;font-size:12px;color:#53627a}.po-row small{display:block;color:#8792a3;font-size:10px}.target-line{font-size:11px;color:#7d899b;padding:0 20px 16px}@media(max-width:1100px){.kpis{grid-template-columns:repeat(2,1fr)}}</style>
</head><body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Dashboard'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow"><?= h($eyebrow) ?></div><h1>Welcome, <?= h($user['full_name'] ?? $user['name'] ?? 'User') ?></h1><p><?= h($sessionName) ?> · <?= $role === 'principal' ? 'All departments' : h($user['department'] ?? '') ?></p></div></div>
<?php ui_notice($notice, 'err'); ?>

<div class="kpis"><?php foreach ($kpis as [$label, $value, $note]): ?><div class="kpi"><div class="k-label"><?= h($label) ?></div><div class="k-value"><?= h($value) ?></div><div class="k-note"><?= h($note) ?></div></div><?php endforeach; ?></div>

<?php if ($role === 'principal'): ?>
<div class="card"><div class="card-head"><div><h2>Departments</h2><span>CO attainment level by department (0–3)</span></div><a class="btn btn-outline btn-sm" href="accreditation.php">Accreditation view</a></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Department</th><th class="num">Subjects</th><th class="num">Students</th><th class="num">Avg CO level</th></tr></thead><tbody>
<?php if (!$deptRows): ?><tr><td colspan="4"><div class="muted-empty">No departments yet.</div></td></tr><?php endif; ?>
<?php foreach ($deptRows as $d): ?><tr><td><b><?= h($d['name']) ?></b></td><td class="num"><?= (int)$d['subjects'] ?></td><td class="num"><?= (int)$d['students'] ?></td><td class="num"><?= $d['avg_level'] === null ? '<span class="badge grey">—</span>' : ui_level_badge((float)$d['avg_level'], $coTarget) ?></td></tr><?php endforeach; ?></tbody></table></div></div>
<?php endif; ?>

<?php if (in_array($role, ['principal', 'hod'], true)): ?>
<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>PO attainment<?= $role === 'principal' ? ((principal_dept_filter() > 0) ? ' — selected department' : ' — all departments (average)') : '' ?></h2><span>Average level (0–3) across subjects that map to each PO · target <?= number_format($poTarget, 2) ?></span></div><a class="btn btn-outline btn-sm" href="report.php">Reports</a></div>
<?php if (!$poRoll): ?><div class="muted-empty">No PO attainment yet. It appears once subject incharges calculate attainment.</div>
<?php else: ?><div class="po-bars"><?php foreach ($poRoll as $po => $v): $pct = min(100, max(0, $v['level'] / 3 * 100)); ?><div class="po-row"><span><b>PO<?= (int)$po ?></b><?php if (!empty($poTitles[$po])): ?><small><?= h(mb_strimwidth($poTitles[$po], 0, 22, '…')) ?></small><?php endif; ?></span><div class="bar-track"><div class="bar-fill <?= $v['level'] >= $poTarget ? 'green' : ($v['level'] < $poTarget - 0.5 ? 'rust' : '') ?>" style="width:<?= $pct ?>%"></div></div><span><?= number_format($v['level'], 2) ?></span></div><?php endforeach; ?></div><?php endif; ?></div>
<?php endif; ?>

<?php if ($role === 'class_incharge'): ?>
<div class="card"><div class="card-head"><div><h2>My classes</h2><span>Open a class to upload students and review performance</span></div><a class="btn btn-gold btn-sm" href="classes.php">Manage classes</a></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Semester</th><th>Section</th><th class="num">Students</th><th class="num">Average marks</th><th></th></tr></thead><tbody>
<?php if (!$classes): ?><tr><td colspan="5"><div class="muted-empty">No class is assigned to you for this session yet. Ask your HOD.</div></td></tr><?php endif; ?>
<?php foreach ($classes as $c): ?><tr><td>Semester <?= (int)$c['semester'] ?></td><td><?= h($c['section']) ?></td><td class="num"><?= (int)$c['students'] ?></td><td class="num"><?= $c['pct'] === null ? '<span class="badge grey">No marks</span>' : '<span class="badge ' . ($c['pct'] >= 60 ? 'green' : ($c['pct'] >= 40 ? 'gold' : 'rust')) . '">' . number_format($c['pct'], 1) . '%</span>' ?></td><td><a class="btn btn-outline btn-sm" href="classes.php?session_id=<?= (int)$sessionId ?>&dept=<?= (int)$c['dept'] ?>&semester=<?= (int)$c['semester'] ?>&section=<?= urlencode($c['section']) ?>">Open</a></td></tr><?php endforeach; ?></tbody></table></div></div>
<?php endif; ?>

<?php if ($role !== 'class_incharge'): ?>
<div class="card" style="margin-top:20px"><div class="card-head"><div><h2><?= $role === 'subject_incharge' ? 'My subjects' : 'Subjects' ?> — workflow progress</h2><span>COs → assessments → marks → CO–PO mapping → attainment</span></div><span class="badge grey"><?= count($subjects) ?></span></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Subject</th><th>Sem</th><th>COs</th><th>Assess.</th><th>Marks</th><th>Mapped</th><th>Calculated</th><th class="num">Avg CO level</th><th>Next step</th></tr></thead><tbody>
<?php if (!$subjects): ?><tr><td colspan="9"><div class="muted-empty"><?= $role === 'subject_incharge' ? 'No subjects are assigned to you for this session. Ask your HOD.' : 'No subjects for this session yet.' ?></div></td></tr><?php endif; ?>
<?php foreach ($subjects as $s): [$label, $link] = dash_next_step($s); ?>
<tr><td><b><?= h($s['subject_code']) ?></b> — <?= h($s['subject_name']) ?><?php if ($s['department'] && ($role !== 'subject_incharge' || $s['department'] !== ($user['department'] ?? ''))): ?><div class="stu-id"><?= h($s['department']) ?></div><?php endif; ?></td><td><?= (int)$s['semester'] ?></td>
<td><?= dash_dot((int)$s['cos'] > 0) ?></td><td><?= dash_dot((int)$s['comps'] > 0) ?></td><td><?= dash_dot((int)$s['mark_rows'] > 0) ?></td><td><?= dash_dot((int)$s['cos'] > 0 && (int)$s['mapped_cos'] >= (int)$s['cos']) ?></td><td><?= dash_dot((int)$s['calc_cos'] > 0) ?></td>
<td class="num"><?= $s['avg_level'] === null ? '<span class="badge grey">—</span>' : ui_level_badge((float)$s['avg_level'], $coTarget) ?></td>
<td><?php if ($label === 'Up to date'): ?><span class="badge green">Up to date</span><?php elseif (user_can_access_page(basename(parse_url($link, PHP_URL_PATH)))): ?><a class="btn btn-outline btn-sm" href="<?= h($link) ?>"><?= h($label) ?></a><?php else: ?><span class="badge gold"><?= h($label) ?></span><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div></div>
<?php endif; ?>
</section></div></main></div></body></html>
