
<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('analytics.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$sessions = $conn->query("SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC")->fetch_all(MYSQLI_ASSOC);
$activeId = 0;
foreach ($sessions as $s) { if ((int)$s['is_active'] === 1) { $activeId = (int)$s['id']; break; } }
$sessionId = isset($_GET['session_id']) ? (int)$_GET['session_id'] : $activeId;
$semester = isset($_GET['semester']) ? (int)$_GET['semester'] : 0;
if ($semester < 0 || $semester > 8) $semester = 0;
$sessionExists = false;
foreach ($sessions as $s) { if ((int)$s['id'] === $sessionId) $sessionExists = true; }
if (!$sessionExists && $sessions) $sessionId = (int)$sessions[0]['id'];

$subjectSql = "SELECT id, subject_code, subject_name, semester FROM subjects WHERE academic_session_id = ?" . ($semester ? " AND semester = ?" : "") . scope_subject_clause() . " ORDER BY semester, subject_name";
$stmt = $conn->prepare($subjectSql);
if ($semester) $stmt->bind_param('ii', $sessionId, $semester); else $stmt->bind_param('i', $sessionId);
$stmt->execute(); $subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

$subjectCount = count($subjects);
$subjectIds = array_map(fn($s) => (int)$s['id'], $subjects);
$coAvg = null; $poAvg = null; $studentCount = 0; $coRows = []; $poRows = []; $subjectRows = []; $distribution = ['Excellent'=>0,'Good'=>0,'Needs Support'=>0,'No Marks'=>0];

if ($subjectCount > 0) {
    $placeholders = implode(',', array_fill(0, count($subjectIds), '?'));
    $types = str_repeat('i', count($subjectIds));
    $sql = "SELECT outcome_type, outcome_code, AVG(attainment_percent) avg_percent, COUNT(*) result_count FROM attainment_results WHERE academic_session_id = ? AND subject_id IN ($placeholders) GROUP BY outcome_type, outcome_code ORDER BY outcome_type, outcome_code";
    $stmt = $conn->prepare($sql); $bindTypes = 'i' . $types; $params = array_merge([$sessionId], $subjectIds); $stmt->bind_param($bindTypes, ...$params); $stmt->execute(); $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    $coVals = []; $poVals = [];
    foreach ($results as $r) {
        $r['avg_percent'] = (float)$r['avg_percent'];
        if ($r['outcome_type'] === 'CO') { $coRows[] = $r; $coVals[] = $r['avg_percent']; }
        elseif ($r['outcome_type'] === 'PO') { $poRows[] = $r; $poVals[] = $r['avg_percent']; }
    }
    if ($coVals) $coAvg = array_sum($coVals) / count($coVals);
    if ($poVals) $poAvg = array_sum($poVals) / count($poVals);

    $sql = "SELECT s.id, s.subject_code, s.subject_name, s.semester,
        (SELECT AVG(ar.attainment_percent) FROM attainment_results ar WHERE ar.subject_id=s.id AND ar.academic_session_id=s.academic_session_id AND ar.semester=s.semester AND ar.outcome_type='CO') co_avg,
        (SELECT AVG(ar.attainment_percent) FROM attainment_results ar WHERE ar.subject_id=s.id AND ar.academic_session_id=s.academic_session_id AND ar.semester=s.semester AND ar.outcome_type='PO') po_avg
        FROM subjects s WHERE s.academic_session_id=?" . ($semester ? " AND s.semester=?" : "") . scope_subject_clause('s') . " ORDER BY s.semester, s.subject_name";
    $stmt = $conn->prepare($sql);
    if ($semester) $stmt->bind_param('ii', $sessionId, $semester); else $stmt->bind_param('i', $sessionId);
    $stmt->execute(); $subjectRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

    $enrollSql = "SELECT COUNT(DISTINCT se.student_id) c FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE se.academic_session_id=? AND se.status='active'" . ($semester ? " AND se.semester=?" : "") . scope_student_clause($conn, (int)$sessionId, 'se', 'st');
    $stmt = $conn->prepare($enrollSql); if ($semester) $stmt->bind_param('ii', $sessionId, $semester); else $stmt->bind_param('i', $sessionId); $stmt->execute(); $studentCount = (int)$stmt->get_result()->fetch_assoc()['c']; $stmt->close();

    // Distribution is based on each active student's recorded marks ratio across the selected session/semester.
    $distSql = "SELECT se.student_id, SUM(m.marks_obtained) earned, SUM(ac.max_marks) possible
        FROM student_enrollments se
        JOIN students st ON st.id=se.student_id
        JOIN marks m ON m.enrollment_id=se.id
        JOIN assessment_components ac ON ac.id=m.assessment_component_id
        JOIN subjects sub ON sub.id=ac.subject_id AND sub.academic_session_id=se.academic_session_id AND sub.semester=se.semester
        WHERE se.academic_session_id=? AND se.status='active' AND sub.id IN ($placeholders) AND m.course_outcome_id IS NOT NULL" . scope_student_clause($conn, (int)$sessionId, 'se', 'st') . "
        GROUP BY se.student_id";
    $stmt = $conn->prepare($distSql); $stmt->bind_param($bindTypes, ...$params); $stmt->execute(); $distRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    $studentCount = max($studentCount, 0); $seen = [];
    foreach ($distRows as $d) {
        $ratio = (float)$d['possible'] > 0 ? ((float)$d['earned'] / (float)$d['possible']) * 100 : null;
        if ($ratio === null) { $distribution['No Marks']++; }
        elseif ($ratio >= 75) { $distribution['Excellent']++; }
        elseif ($ratio >= 50) { $distribution['Good']++; }
        else { $distribution['Needs Support']++; }
        $seen[(int)$d['student_id']] = true;
    }
    $distribution['No Marks'] += max(0, $studentCount - count($seen));
}

$coCount = count($coRows); $poCount = count($poRows);
$calculatedAt = null;
if ($subjectCount) {
    $sql = "SELECT MAX(calculated_at) latest FROM attainment_results WHERE academic_session_id=? AND subject_id IN (" . implode(',', array_fill(0, count($subjectIds), '?')) . ")";
    $stmt = $conn->prepare($sql); $bindTypes = 'i' . str_repeat('i', count($subjectIds)); $params = array_merge([$sessionId], $subjectIds); $stmt->bind_param($bindTypes, ...$params); $stmt->execute(); $calculatedAt = $stmt->get_result()->fetch_assoc()['latest'] ?? null; $stmt->close();
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Attainment Analytics — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css">
<style>
.analytics-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:18px 0}.analytics-grid .stat-card{min-width:0}.analytics-two{display:grid;grid-template-columns:1fr 1fr;gap:18px}.analytics-card{margin-bottom:18px}.analytics-card .inner{padding:18px 20px}.bar-list{display:grid;gap:14px}.bar-row{display:grid;grid-template-columns:minmax(62px,100px) 1fr 58px;gap:10px;align-items:center}.bar-track{height:10px;border-radius:99px;background:#edf0f5;overflow:hidden}.bar-fill{height:100%;border-radius:99px;background:var(--gold,#bd882b)}.muted{color:#687386;font-size:13px}.metric{font-weight:700;text-align:right;font-variant-numeric:tabular-nums}.empty{padding:22px;border:1px dashed #cbd2dd;border-radius:10px;color:#687386;background:#fafbfc}.filter-row{display:flex;align-items:end;gap:12px;flex-wrap:wrap}.filter-row .field{min-width:180px}.filter-row label{display:block;font-size:13px;margin-bottom:6px}.filter-row select{width:100%;min-height:42px;padding:9px 11px;border:1px solid #d8dde6;border-radius:8px;background:white}.status-pill{display:inline-block;padding:4px 8px;border-radius:99px;background:#f3f4f6;font-size:12px}.analytics-table-wrap{overflow-x:auto}.analytics-table{width:100%;border-collapse:collapse}.analytics-table th,.analytics-table td{text-align:left;padding:11px 12px;border-bottom:1px solid #e9edf2;white-space:nowrap}.analytics-table th{font-size:12px;color:#657084;text-transform:uppercase;letter-spacing:.03em}.small-bar{display:flex;gap:3px;height:8px;min-width:90px}.small-bar span{display:block;border-radius:5px;background:var(--gold,#bd882b)}
@media(max-width:1050px){.analytics-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.analytics-two{grid-template-columns:1fr}}@media(max-width:650px){.analytics-grid{grid-template-columns:1fr 1fr}.bar-row{grid-template-columns:65px 1fr 45px;gap:6px}.analytics-card .inner{padding:14px}}
</style>
</head>
<body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main"><header class="topbar"><div class="crumb">CO–PO Workspace / <b>Attainment Analytics</b></div><div class="topbar-spacer"></div><a class="term-pill" href="profile.php" style="text-decoration:none">Profile</a><a class="term-pill" href="logout.php" style="text-decoration:none">Logout</a></header>
<div class="content"><section class="page active">
<div class="page-head"><div><h1>Attainment Analytics</h1><p>Review saved CO/PO attainment, subject comparisons and recorded-mark distribution.</p></div></div>
<div class="card analytics-card"><div class="inner"><form method="get" class="filter-row"><div class="field"><label for="session_id">Academic session</label><select name="session_id" id="session_id" required><?php foreach($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $sessionId===(int)$s['id']?'selected':'' ?>><?= h($s['session_name']) ?><?= (int)$s['is_active']===1?' (Active)':'' ?></option><?php endforeach; ?></select></div><div class="field"><label for="semester">Semester</label><select name="semester" id="semester"><option value="0" <?= $semester===0?'selected':'' ?>>All semesters</option><?php for($i=1;$i<=8;$i++): ?><option value="<?= $i ?>" <?= $semester===$i?'selected':'' ?>>Semester <?= $i ?></option><?php endfor; ?></select></div><button class="btn btn-primary" type="submit">Apply filters</button><a class="btn btn-outline" href="analytics.php">Reset</a></form></div></div>
<div class="analytics-grid">
<div class="stat-card"><div class="label">Average CO Attainment</div><div class="big"><?= $coAvg===null?'—':number_format($coAvg,1).'%' ?></div><div class="sub"><?= $coCount ?> saved CO result(s)</div></div>
<div class="stat-card"><div class="label">Average PO Attainment</div><div class="big"><?= $poAvg===null?'—':number_format($poAvg,1).'%' ?></div><div class="sub"><?= $poCount ?> saved PO result(s)</div></div>
<div class="stat-card"><div class="label">Subjects Analyzed</div><div class="big"><?= $subjectCount ?></div><div class="sub">Matching selected filters</div></div>
<div class="stat-card"><div class="label">Active Students</div><div class="big"><?= $studentCount ?></div><div class="sub">Session<?= $semester?' · Semester '.(int)$semester:'' ?></div></div>
</div>
<div class="analytics-two">
<div><div class="card analytics-card"><div class="card-head"><div><h2>CO Attainment Overview</h2><span>Average saved attainment by CO code across selected subjects</span></div></div><div class="inner">
<?php if(!$coRows): ?><div class="empty">No saved CO attainment results for these filters. Calculate attainment on the CO/PO Attainment page first.</div><?php else: ?><div class="bar-list"><?php foreach($coRows as $r): ?><div class="bar-row"><div><?= h($r['outcome_code']) ?></div><div class="bar-track"><div class="bar-fill" style="width:<?= max(0,min(100,(float)$r['avg_percent'])) ?>%"></div></div><div class="metric"><?= number_format((float)$r['avg_percent'],1) ?>%</div></div><?php endforeach; ?></div><?php endif; ?></div></div>
<div class="card analytics-card"><div class="card-head"><div><h2>PO Attainment Overview</h2><span>Average saved attainment by PO code across selected subjects</span></div></div><div class="inner">
<?php if(!$poRows): ?><div class="empty">No saved PO attainment results for these filters. Confirm CO–PO mappings and calculate attainment first.</div><?php else: ?><div class="bar-list"><?php foreach($poRows as $r): ?><div class="bar-row"><div><?= h($r['outcome_code']) ?></div><div class="bar-track"><div class="bar-fill" style="width:<?= max(0,min(100,(float)$r['avg_percent'])) ?>%"></div></div><div class="metric"><?= number_format((float)$r['avg_percent'],1) ?>%</div></div><?php endforeach; ?></div><?php endif; ?></div></div></div>
<div><div class="card analytics-card"><div class="card-head"><div><h2>Student Result Distribution</h2><span>Categories based on recorded marks ÷ maximum marks</span></div></div><div class="inner"><p class="muted">Informational bands: Excellent ≥75%, Good 50–74.9%, Needs Support &lt;50%. These are not official pass criteria.</p><div class="bar-list"><?php $distColors = ['Excellent'=>'#4f8a68','Good'=>'#bd882b','Needs Support'=>'#bd5c50','No Marks'=>'#9aa3b2']; foreach($distribution as $label=>$count): $pct=$studentCount>0?($count/$studentCount)*100:0; ?><div><div class="bar-row"><div><?= h($label) ?></div><div class="bar-track"><div class="bar-fill" style="width:<?= max(0,min(100,$pct)) ?>%;background:<?= $distColors[$label] ?>"></div></div><div class="metric"><?= (int)$count ?></div></div></div><?php endforeach; ?></div></div></div>
<div class="card analytics-card"><div class="card-head"><div><h2>Analytics status</h2><span>Data availability</span></div></div><div class="inner"><p><span class="status-pill"><?= $coCount || $poCount ? 'Attainment results available' : 'Awaiting attainment results' ?></span></p><p class="muted">Latest saved calculation: <?= $calculatedAt ? h(date('d M Y, h:i A', strtotime($calculatedAt))) : 'Not available' ?></p><a class="btn btn-outline" href="attainment.php">Open CO/PO Attainment</a> <a class="btn btn-outline" href="report.php">Open Reports</a></div></div></div>
</div>
<div class="card analytics-card"><div class="card-head"><div><h2>Subject Performance Comparison</h2><span>Subject-wise averages from saved attainment results</span></div></div><div class="analytics-table-wrap"><table class="analytics-table"><thead><tr><th>Subject</th><th>Semester</th><th>Average CO</th><th>Average PO</th><th>CO progress</th></tr></thead><tbody>
<?php if(!$subjectRows): ?><tr><td colspan="5"><div class="empty">No subjects found for the selected session and semester.</div></td></tr><?php else: foreach($subjectRows as $r): $c=$r['co_avg']!==null?(float)$r['co_avg']:null; $p=$r['po_avg']!==null?(float)$r['po_avg']:null; ?><tr><td><strong><?= h($r['subject_code']) ?></strong> — <?= h($r['subject_name']) ?></td><td><?= (int)$r['semester'] ?></td><td><?= $c===null?'—':number_format($c,1).'%' ?></td><td><?= $p===null?'—':number_format($p,1).'%' ?></td><td><?php if($c===null): ?>—<?php else: ?><div class="small-bar"><span style="width:<?= max(0,min(100,$c)) ?>%"></span></div><?php endif; ?></td></tr><?php endforeach; endif; ?></tbody></table></div></div>
<div class="card analytics-card"><div class="card-head"><div><h2>Analytics workflow</h2><span>For reliable results, complete each step before interpreting charts</span></div></div><div class="inner"><ol><li>Set up academic sessions, semesters, subjects and course outcomes.</li><li>Enter and verify student assessment marks.</li><li>Complete the approved CO–PO mapping.</li><li>Calculate attainment using the college-approved rules.</li><li>Return here to review saved attainment and export reports.</li></ol></div></div>
</section></div></main></div></body></html>
