<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('internal-marks.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$user = current_user() ?? [];
$userId = (int)($user['id'] ?? 0);
if (empty($_SESSION['csrf_internal_marks'])) {
    $_SESSION['csrf_internal_marks'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_internal_marks'];
$message = '';
$messageType = 'success';

function im_h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function im_redirect(array $params = []): never {
    $url = 'internal-marks.php';
    if ($params) $url .= '?' . http_build_query($params);
    header('Location: ' . $url);
    exit;
}
function im_subject_semester(array $subjects, int $subjectId, int $fallback): int {
    foreach ($subjects as $subject) if ((int)$subject['id'] === $subjectId) return (int)$subject['semester'];
    return $fallback;
}

$explicitSessionFilter = array_key_exists('session_id', $_GET);
$sessionId = $explicitSessionFilter ? (int)$_GET['session_id'] : 0;
$semester = (int)($_GET['semester'] ?? 0);
$subjectId = (int)($_GET['subject_id'] ?? 0);
$componentId = (int)($_GET['component_id'] ?? 0);

try {
    $sessions = $conn->query('SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
    if (!$sessionId && $sessions) {
        foreach ($sessions as $sessionRow) {
            if ((int)$sessionRow['is_active'] === 1) { $sessionId = (int)$sessionRow['id']; break; }
        }
        if (!$sessionId) $sessionId = (int)$sessions[0]['id'];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals($csrf, (string)($_POST['csrf_token'] ?? ''))) {
            throw new RuntimeException('Security token expired. Refresh the page and try again.');
        }
        $action = (string)($_POST['action'] ?? '');
        $postSession = (int)($_POST['session_id'] ?? 0);
        $postSemester = (int)($_POST['semester'] ?? 0);
        $postSubject = (int)($_POST['subject_id'] ?? 0);

        if ($action === 'create_component') {
            $name = trim((string)($_POST['component_name'] ?? ''));
            $maxMarks = filter_var($_POST['max_marks'] ?? null, FILTER_VALIDATE_FLOAT);
            $assessmentNo = max(1, min(255, (int)($_POST['assessment_no'] ?? 1)));
            $validSubject = $conn->prepare('SELECT id FROM subjects WHERE id=? AND academic_session_id=? AND semester=?' . scope_subject_clause() . ' LIMIT 1');
            $validSubject->bind_param('iii', $postSubject, $postSession, $postSemester);
            $validSubject->execute();
            if (!$validSubject->get_result()->fetch_assoc()) throw new RuntimeException('Select a valid subject for this academic session and semester.');
            if ($name === '' || strlen($name) > 100) throw new RuntimeException('Enter an assessment name (maximum 100 characters).');
            if ($maxMarks === false || $maxMarks <= 0 || $maxMarks > 10000) throw new RuntimeException('Maximum marks must be greater than zero.');
            $type = 'other';
            $stmt = $conn->prepare('INSERT INTO assessment_components (subject_id, component_name, max_marks, component_type, assessment_no) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('isdsi', $postSubject, $name, $maxMarks, $type, $assessmentNo);
            $stmt->execute();
            im_redirect(['session_id'=>$postSession, 'semester'=>$postSemester, 'subject_id'=>$postSubject, 'component_id'=>$stmt->insert_id, 'created'=>1]);
        }

        if ($action === 'save_marks') {
            $postComponent = (int)($_POST['component_id'] ?? 0);
            $componentStmt = $conn->prepare("SELECT ac.id, ac.subject_id, ac.max_marks FROM assessment_components ac JOIN subjects s ON s.id=ac.subject_id WHERE ac.id=? AND ac.subject_id=? AND s.academic_session_id=? AND s.semester=? AND ac.component_type='other' LIMIT 1");
            $componentStmt->bind_param('iiii', $postComponent, $postSubject, $postSession, $postSemester);
            $componentStmt->execute();
            $component = $componentStmt->get_result()->fetch_assoc();
            if (!$component) throw new RuntimeException('Selected internal assessment does not match the subject/session/semester.');
            $maxMarks = (float)$component['max_marks'];
            $coStmt = $conn->prepare('SELECT id FROM course_outcomes WHERE subject_id=?');
            $coStmt->bind_param('i', $postSubject); $coStmt->execute();
            $validCoRows = $coStmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $validCos = array_fill_keys(array_map(static fn($r)=>(int)$r['id'], $validCoRows), true);
            if (!$validCos) throw new RuntimeException('This subject has no Course Outcomes. Add COs before entering marks.');

            $enrollStmt = $conn->prepare("SELECT se.id FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE se.academic_session_id=? AND se.semester=? AND se.status='active'" . scope_roster_clause('se', (int)$postSubject));
            $enrollStmt->bind_param('ii', $postSession, $postSemester); $enrollStmt->execute();
            $validEnrollments = array_fill_keys(array_map(static fn($r)=>(int)$r['id'], $enrollStmt->get_result()->fetch_all(MYSQLI_ASSOC)), true);
            $entries = $_POST['marks'] ?? [];
            $conn->begin_transaction();
            $save = $conn->prepare('INSERT INTO marks (enrollment_id, assessment_component_id, course_outcome_id, marks_obtained, updated_by) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE marks_obtained=VALUES(marks_obtained), updated_by=VALUES(updated_by)');
            $saved = 0;
            foreach ($entries as $enrollmentKey => $coEntries) {
                $enrollmentId = (int)$enrollmentKey;
                if (!isset($validEnrollments[$enrollmentId]) || !is_array($coEntries)) continue;
                foreach ($coEntries as $coKey => $raw) {
                    $coId = (int)$coKey;
                    if (!isset($validCos[$coId]) || $raw === '') continue;
                    if (!is_numeric($raw)) throw new RuntimeException('Marks must be numeric values.');
                    $score = (float)$raw;
                    if ($score < 0 || $score > $maxMarks) throw new RuntimeException('Marks must be between 0 and ' . rtrim(rtrim(number_format($maxMarks, 2, '.', ''), '0'), '.') . '.');
                    $save->bind_param('iiidi', $enrollmentId, $postComponent, $coId, $score, $userId);
                    $save->execute(); $saved++;
                }
            }
            $conn->commit();
            im_redirect(['session_id'=>$postSession, 'semester'=>$postSemester, 'subject_id'=>$postSubject, 'component_id'=>$postComponent, 'saved'=>$saved]);
        }
        throw new RuntimeException('Unknown form action.');
    }

    $subjectSql = 'SELECT s.id, s.subject_code, s.subject_name, s.semester, d.name AS department_name FROM subjects s LEFT JOIN departments d ON d.id=s.department_id WHERE s.academic_session_id=?' . ($semester ? ' AND s.semester=?' : '') . scope_subject_clause('s') . ' ORDER BY s.semester, s.subject_name';
    $subjectStmt = $conn->prepare($subjectSql);
    if ($semester) $subjectStmt->bind_param('ii', $sessionId, $semester); else $subjectStmt->bind_param('i', $sessionId);
    $subjectStmt->execute(); $subjects = $subjectStmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // If this is the initial page load and the active/latest session has no subjects,
    // fall back to the newest academic session that actually contains subject records.
    // Explicit user-selected session filters are never silently overridden.
    if (!$explicitSessionFilter && !$subjects && !$semester) {
        $fallbackResult = $conn->query('SELECT a.id FROM academic_sessions a JOIN subjects s ON s.academic_session_id=a.id GROUP BY a.id, a.is_active, a.session_name ORDER BY a.is_active DESC, a.session_name DESC LIMIT 1');
        $fallbackSession = $fallbackResult ? $fallbackResult->fetch_assoc() : null;
        if ($fallbackSession) {
            $sessionId = (int)$fallbackSession['id'];
            $subjectStmt = $conn->prepare($subjectSql);
            $subjectStmt->bind_param('i', $sessionId);
            $subjectStmt->execute(); $subjects = $subjectStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        }
    }

    if ($subjectId && !array_filter($subjects, static fn($s)=>(int)$s['id']===$subjectId)) $subjectId = 0;
    $components = [];
    $cos = [];
    $students = [];
    $existingMarks = [];
    $selectedComponent = null;
    if ($subjectId) {
        $componentStmt = $conn->prepare("SELECT id, component_name, max_marks, assessment_no FROM assessment_components WHERE subject_id=? AND component_type='other' ORDER BY assessment_no, component_name");
        $componentStmt->bind_param('i', $subjectId); $componentStmt->execute(); $components = $componentStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        if ($componentId && !array_filter($components, static fn($c)=>(int)$c['id']===$componentId)) $componentId = 0;
        $coStmt = $conn->prepare('SELECT id, co_code, description FROM course_outcomes WHERE subject_id=? ORDER BY id');
        $coStmt->bind_param('i', $subjectId); $coStmt->execute(); $cos = $coStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $studentStmt = $conn->prepare("SELECT se.id AS enrollment_id, st.enrollment_no, st.full_name, se.section FROM student_enrollments se JOIN students st ON st.id=se.student_id JOIN subjects s ON s.academic_session_id=se.academic_session_id AND s.semester=se.semester WHERE s.id=? AND se.status='active'" . scope_roster_joined_clause('se') . " ORDER BY se.section, st.full_name");
        $studentStmt->bind_param('i', $subjectId); $studentStmt->execute(); $students = $studentStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        if ($componentId) {
            $selectedComponent = null; foreach ($components as $componentRow) { if ((int)$componentRow['id'] === $componentId) { $selectedComponent = $componentRow; break; } }
            $markStmt = $conn->prepare('SELECT enrollment_id, course_outcome_id, marks_obtained FROM marks WHERE assessment_component_id=? AND course_outcome_id IS NOT NULL');
            $markStmt->bind_param('i', $componentId); $markStmt->execute();
            foreach ($markStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $m) $existingMarks[(int)$m['enrollment_id']][(int)$m['course_outcome_id']] = $m['marks_obtained'];
        }
    }
} catch (Throwable $e) {
    if ($conn->errno) { try { $conn->rollback(); } catch (Throwable $ignored) {} }
    $message = $e->getMessage(); $messageType = 'error';
    $sessions = $sessions ?? []; $subjects = $subjects ?? []; $components = $components ?? []; $cos = $cos ?? []; $students = $students ?? []; $existingMarks = $existingMarks ?? []; $selectedComponent = $selectedComponent ?? null;
}
if (isset($_GET['created'])) { $message = 'Internal assessment created successfully.'; $messageType = 'success'; }
if (isset($_GET['saved'])) { $message = 'Marks saved successfully. ' . (int)$_GET['saved'] . ' CO mark entries updated.'; $messageType = 'success'; }
$sessionName = '';
foreach (($sessions ?? []) as $s) if ((int)$s['id'] === $sessionId) $sessionName = $s['session_name'];
$initials = strtoupper(substr((string)($user['name'] ?? $user['full_name'] ?? 'User'), 0, 1));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>CO–PO Workspace — Internal Marks</title><link rel="stylesheet" href="css/style.css">
<style>
.im-message{padding:12px 15px;margin:0 0 16px;border:1px solid #cfe3d5;background:#edf8ef;color:#205c31;border-radius:5px}.im-message.error{background:#fff0f0;border-color:#f1caca;color:#922b2b}.im-filters{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:14px;align-items:end}.im-actions{display:flex;gap:9px;flex-wrap:wrap;align-items:center}.im-table input{width:76px;max-width:100%;height:32px;text-align:center;border:1px solid var(--line);border-radius:4px;padding:0 6px}.im-table input:focus{outline:2px solid rgba(189,136,43,.18);border-color:var(--gold)}.im-student{min-width:190px}.im-co{min-width:120px}.im-foot{padding:14px 20px;display:flex;gap:12px;align-items:center;justify-content:space-between;border-top:1px solid var(--line2)}.im-muted{font-size:11px;color:var(--muted)}.im-create{margin-top:18px}.im-create-grid{display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:14px;align-items:end}.im-empty{padding:28px;text-align:center;color:#8793a6;border:1px dashed var(--line);border-radius:5px;background:#fcfcfa}.im-pill{display:inline-block;padding:4px 9px;background:var(--goldt);color:#91651c;border-radius:12px;font-size:10px;font-weight:700}
@media(max-width:1100px){.im-filters{grid-template-columns:repeat(2,minmax(0,1fr))}.im-create-grid{grid-template-columns:1fr 1fr}.content{padding:22px}}
@media(max-width:760px){body{min-width:0}.sidebar{width:205px;min-width:205px}.topbar{padding:0 14px;gap:8px}.content{padding:16px}.im-filters,.im-create-grid{grid-template-columns:1fr}.im-foot{align-items:flex-start;flex-direction:column}.term-pill{display:none}}
</style>
</head>
<body>
<div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<header class="topbar"><div class="crumb">CO–PO Workspace / <b>Record marks / Internal</b></div><div class="topbar-spacer"></div><div class="term-pill"><span class="dot"></span><?= im_h($sessionName ?: 'Select session') ?></div><a class="term-pill" href="profile.php" style="text-decoration:none">Profile</a><a class="term-pill" href="logout.php" style="text-decoration:none">Logout</a></header>
<div class="content">
 <div class="page-head"><div><div class="eyebrow">ASSESSMENT MANAGEMENT</div><h1>Internal marks</h1><p>Record CO-wise internal assessment marks for students enrolled in a subject.</p></div><span class="im-pill">DATABASE CONNECTED</span></div>
 <?php if ($message !== ''): ?><div class="im-message <?= $messageType === 'error' ? 'error' : '' ?>" role="status"><?= im_h($message) ?></div><?php endif; ?>
 <div class="card">
  <div class="card-head"><div><h2>Select class and assessment</h2><span>Choose the academic session, semester and subject to load enrolled students.</span></div></div>
  <form method="get" class="filter-bar">
   <div class="field"><label for="session_id">Academic session</label><select class="control" id="session_id" name="session_id" required><?php foreach (($sessions ?? []) as $s): ?><option value="<?= (int)$s['id'] ?>" <?= (int)$s['id']===$sessionId?'selected':'' ?>><?= im_h($s['session_name']) ?></option><?php endforeach; ?></select></div>
   <div class="field"><label for="semester">Semester</label><select class="control" id="semester" name="semester"><option value="0">All semesters</option><?php for($sem=1;$sem<=8;$sem++): ?><option value="<?= $sem ?>" <?= $semester===$sem?'selected':'' ?>>Semester <?= $sem ?></option><?php endfor; ?></select></div>
   <div class="field"><label for="subject_id">Subject</label><select class="control" id="subject_id" name="subject_id" required><option value="0">Select subject</option><?php foreach (($subjects ?? []) as $s): ?><option value="<?= (int)$s['id'] ?>" <?= (int)$s['id']===$subjectId?'selected':'' ?>><?= im_h($s['subject_code'].' — '.$s['subject_name'].' (Sem '.$s['semester'].')') ?></option><?php endforeach; ?></select></div>
   <div class="field"><label for="component_id">Internal assessment</label><select class="control" id="component_id" name="component_id"><option value="0">Select assessment</option><?php foreach (($components ?? []) as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$c['id']===$componentId?'selected':'' ?>><?= im_h($c['component_name'].' · '.$c['max_marks'].' marks') ?></option><?php endforeach; ?></select></div>
   <button class="btn btn-primary" type="submit">Load class list</button>
  </form>
  <?php if ($subjectId && !$components): ?><div class="panel-body"><div class="im-empty">No internal assessments created for this subject yet. Create one below to start entering marks.</div></div><?php elseif ($subjectId && $componentId && $selectedComponent): ?>
  <div class="section-note"><strong style="color:var(--text)"><?= im_h($selectedComponent['component_name']) ?></strong> · Maximum <?= im_h($selectedComponent['max_marks']) ?> marks per CO <span class="badge grey" style="float:right"><?= count($students) ?> students</span></div>
  <?php if (!$cos): ?><div class="panel-body"><div class="im-empty">This subject has no Course Outcomes. Add COs on the Subjects page before entering CO-wise marks.</div></div><?php elseif (!$students): ?><div class="panel-body"><div class="im-empty">No active students are enrolled in this session and semester.</div></div><?php else: ?>
  <form method="post">
   <input type="hidden" name="csrf_token" value="<?= im_h($csrf) ?>"><input type="hidden" name="action" value="save_marks"><input type="hidden" name="session_id" value="<?= $sessionId ?>"><input type="hidden" name="semester" value="<?= im_subject_semester($subjects, $subjectId, $semester) ?>"><input type="hidden" name="subject_id" value="<?= $subjectId ?>"><input type="hidden" name="component_id" value="<?= $componentId ?>">
   <div class="table-wrap"><table class="data im-table"><thead><tr><th>#</th><th>Student</th><th>Section</th><?php foreach($cos as $co): ?><th class="im-co"><?= im_h($co['co_code']) ?><br><span class="muted">/ <?= im_h($selectedComponent['max_marks']) ?></span></th><?php endforeach; ?></tr></thead><tbody>
   <?php foreach($students as $i=>$st): ?><tr><td class="row-index"><?= $i+1 ?></td><td class="im-student"><div class="stu-name"><?= im_h($st['full_name']) ?></div><div class="stu-id"><?= im_h($st['enrollment_no']) ?></div></td><td><?= im_h($st['section']) ?></td><?php foreach($cos as $co): $old=$existingMarks[(int)$st['enrollment_id']][(int)$co['id']] ?? ''; ?><td><input type="number" min="0" max="<?= im_h($selectedComponent['max_marks']) ?>" step="0.01" name="marks[<?= (int)$st['enrollment_id'] ?>][<?= (int)$co['id'] ?>]" value="<?= im_h($old) ?>" aria-label="<?= im_h($st['full_name'].' '.$co['co_code'].' marks') ?>"></td><?php endforeach; ?></tr><?php endforeach; ?>
   </tbody></table></div><div class="im-foot"><span class="im-muted">Leave a field blank if marks have not been entered. Values are validated before saving.</span><div class="im-actions"><button type="reset" class="btn btn-outline">Reset unsaved changes</button><button type="submit" class="btn btn-gold">Save internal marks</button></div></div>
  </form><?php endif; ?>
  <?php elseif ($subjectId): ?><div class="panel-body"><div class="im-empty">Choose an internal assessment from the list to load student marks.</div></div><?php else: ?><div class="panel-body"><div class="im-empty">No subjects are available for this academic session. Check the session filter or add a subject first. <a href="subjects.php">Open Subjects</a>.</div></div><?php endif; ?>
 </div>
 <?php if ($subjectId): ?><div class="card im-create"><div class="card-head"><div><h2>Create internal assessment</h2><span>Creates an assessment component for the selected subject.</span></div></div><form method="post" class="panel-body"><input type="hidden" name="csrf_token" value="<?= im_h($csrf) ?>"><input type="hidden" name="action" value="create_component"><input type="hidden" name="session_id" value="<?= $sessionId ?>"><input type="hidden" name="semester" value="<?= im_subject_semester($subjects, $subjectId, $semester) ?>"><input type="hidden" name="subject_id" value="<?= $subjectId ?>"><div class="im-create-grid"><div class="field"><label for="component_name">Assessment name</label><input class="control" id="component_name" name="component_name" maxlength="100" required placeholder="e.g. Internal Assessment I"></div><div class="field"><label for="max_marks">Maximum marks per CO</label><input class="control" id="max_marks" name="max_marks" type="number" min="0.01" max="10000" step="0.01" value="10" required></div><div class="field"><label for="assessment_no">Assessment number</label><select class="control" id="assessment_no" name="assessment_no"><option value="1">Assessment 1</option><option value="2">Assessment 2</option><option value="3">Assessment 3</option></select></div><button class="btn btn-primary" type="submit">＋ Create assessment</button></div></form></div><?php endif; ?>
</div></main></div>
<script>
(function(){
 const session=document.getElementById('session_id'), semester=document.getElementById('semester');
 if(session && semester){session.addEventListener('change',()=>{const u=new URL(window.location.href);u.searchParams.set('session_id',session.value);u.searchParams.delete('subject_id');u.searchParams.delete('component_id');window.location.href=u.toString();});semester.addEventListener('change',()=>{const u=new URL(window.location.href);u.searchParams.set('semester',semester.value);u.searchParams.delete('subject_id');u.searchParams.delete('component_id');window.location.href=u.toString();});}
 const subject=document.getElementById('subject_id');if(subject){subject.addEventListener('change',()=>{const u=new URL(window.location.href);u.searchParams.set('subject_id',subject.value);u.searchParams.delete('component_id');window.location.href=u.toString();});}
})();
</script>
</body></html>

