CREATE DATABASE IF NOT EXISTS sspace_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sspace_db;
CREATE TABLE IF NOT EXISTS academic_sessions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 session_name VARCHAR(20) NOT NULL UNIQUE,
 is_active TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS departments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL UNIQUE,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('principal','hod','subject_incharge','class_incharge') NOT NULL,
 department VARCHAR(150) NOT NULL DEFAULT 'Computer Science Engineering',
 department_id BIGINT UNSIGNED NULL,
 employee_id VARCHAR(80) NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_user_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS students (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 enrollment_no VARCHAR(80) NOT NULL UNIQUE,
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NULL,
 mobile VARCHAR(30) NULL,
 gender ENUM('Male','Female','Other','Prefer not to say') NULL,
 department_id BIGINT UNSIGNED NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_student_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS student_enrollments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 student_id BIGINT UNSIGNED NOT NULL,
 academic_session_id BIGINT UNSIGNED NOT NULL,
 semester TINYINT UNSIGNED NOT NULL,
 section VARCHAR(30) NOT NULL DEFAULT 'A',
 status ENUM('active','completed','withdrawn') NOT NULL DEFAULT 'active',
 UNIQUE KEY uq_student_session_semester(student_id,academic_session_id,semester),
 CONSTRAINT fk_enrollment_student FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
 CONSTRAINT fk_enrollment_session FOREIGN KEY(academic_session_id) REFERENCES academic_sessions(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS subjects (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 subject_code VARCHAR(40) NOT NULL,
 subject_name VARCHAR(180) NOT NULL,
 department_id BIGINT UNSIGNED NULL,
 academic_session_id BIGINT UNSIGNED NOT NULL,
 semester TINYINT UNSIGNED NOT NULL,
 credits DECIMAL(4,1) NOT NULL DEFAULT 0,
 subject_type ENUM('Core','Elective','Theory','Practical','Other') NOT NULL DEFAULT 'Core',
 subject_incharge_id BIGINT UNSIGNED NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_subject_session_sem(subject_code,academic_session_id,semester),
 CONSTRAINT fk_subject_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL,
 CONSTRAINT fk_subject_session FOREIGN KEY(academic_session_id) REFERENCES academic_sessions(id),
 CONSTRAINT fk_subject_incharge FOREIGN KEY(subject_incharge_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS course_outcomes (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 subject_id BIGINT UNSIGNED NOT NULL,
 co_code VARCHAR(20) NOT NULL,
 description TEXT NOT NULL,
 UNIQUE KEY uq_co_subject(subject_id,co_code),
 CONSTRAINT fk_co_subject FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS assessment_components (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 subject_id BIGINT UNSIGNED NOT NULL,
 component_name VARCHAR(100) NOT NULL,
 max_marks DECIMAL(7,2) NOT NULL,
 component_type ENUM('sessional','unit_test','assignment','activity','practical','attendance','other') NOT NULL,
 assessment_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_component_subject FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS marks (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 enrollment_id BIGINT UNSIGNED NOT NULL,
 assessment_component_id BIGINT UNSIGNED NOT NULL,
 course_outcome_id BIGINT UNSIGNED NULL,
 marks_obtained DECIMAL(7,2) NOT NULL DEFAULT 0,
 updated_by BIGINT UNSIGNED NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_mark(enrollment_id,assessment_component_id,course_outcome_id),
 CONSTRAINT fk_marks_enrollment FOREIGN KEY(enrollment_id) REFERENCES student_enrollments(id) ON DELETE CASCADE,
 CONSTRAINT fk_marks_component FOREIGN KEY(assessment_component_id) REFERENCES assessment_components(id) ON DELETE CASCADE,
 CONSTRAINT fk_marks_co FOREIGN KEY(course_outcome_id) REFERENCES course_outcomes(id) ON DELETE SET NULL,
 CONSTRAINT fk_marks_user FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS co_po_mapping (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 course_outcome_id BIGINT UNSIGNED NOT NULL,
 po_number TINYINT UNSIGNED NOT NULL,
 mapping_level TINYINT UNSIGNED NOT NULL DEFAULT 0,
 updated_by BIGINT UNSIGNED NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_co_po(course_outcome_id,po_number),
 CONSTRAINT fk_mapping_co FOREIGN KEY(course_outcome_id) REFERENCES course_outcomes(id) ON DELETE CASCADE,
 CONSTRAINT fk_mapping_user FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL,
 CONSTRAINT chk_po_number CHECK(po_number BETWEEN 1 AND 12),
 CONSTRAINT chk_mapping_level CHECK(mapping_level BETWEEN 0 AND 3)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS attainment_results (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 subject_id BIGINT UNSIGNED NOT NULL,
 academic_session_id BIGINT UNSIGNED NOT NULL,
 semester TINYINT UNSIGNED NOT NULL,
 outcome_type ENUM('CO','PO') NOT NULL,
 outcome_code VARCHAR(20) NOT NULL,
 attainment_percent DECIMAL(6,2) NOT NULL DEFAULT 0,
 level_value DECIMAL(4,2) NULL,
 students_total INT UNSIGNED NULL,
 students_attained INT UNSIGNED NULL,
 calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_attainment(subject_id,academic_session_id,semester,outcome_type,outcome_code),
 CONSTRAINT fk_attainment_subject FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
 CONSTRAINT fk_attainment_session FOREIGN KEY(academic_session_id) REFERENCES academic_sessions(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS audit_log (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 action VARCHAR(100) NOT NULL,
 entity_type VARCHAR(80) NOT NULL,
 entity_id BIGINT UNSIGNED NULL,
 details JSON NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_audit_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS program_outcomes (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 department_id BIGINT UNSIGNED NOT NULL,
 po_number TINYINT UNSIGNED NOT NULL,
 title VARCHAR(150) NOT NULL,
 description TEXT NULL,
 updated_by BIGINT UNSIGNED NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_po_dept(department_id,po_number),
 CONSTRAINT fk_po_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE CASCADE,
 CONSTRAINT fk_po_user FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL,
 CONSTRAINT chk_po_no CHECK(po_number BETWEEN 1 AND 12)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS class_assignments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 academic_session_id BIGINT UNSIGNED NOT NULL,
 department_id BIGINT UNSIGNED NOT NULL,
 semester TINYINT UNSIGNED NOT NULL,
 section VARCHAR(30) NOT NULL DEFAULT 'A',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_class(academic_session_id,department_id,semester,section),
 CONSTRAINT fk_class_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_class_session FOREIGN KEY(academic_session_id) REFERENCES academic_sessions(id),
 CONSTRAINT fk_class_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS attainment_settings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 department_id BIGINT UNSIGNED NULL,
 target_percent DECIMAL(5,2) NOT NULL DEFAULT 60,
 level3_min DECIMAL(5,2) NOT NULL DEFAULT 70,
 level2_min DECIMAL(5,2) NOT NULL DEFAULT 60,
 level1_min DECIMAL(5,2) NOT NULL DEFAULT 50,
 co_target_level DECIMAL(3,2) NOT NULL DEFAULT 2.00,
 po_target_level DECIMAL(3,2) NOT NULL DEFAULT 2.00,
 updated_by BIGINT UNSIGNED NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_settings_dept(department_id),
 CONSTRAINT fk_settings_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE CASCADE
) ENGINE=InnoDB;
INSERT IGNORE INTO departments(name) VALUES ('Computer Science Engineering');
INSERT IGNORE INTO academic_sessions(session_name,is_active) VALUES ('2026-27',1),('2025-26',0),('2024-25',0);
INSERT INTO attainment_settings(department_id) SELECT NULL FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM attainment_settings WHERE department_id IS NULL);
