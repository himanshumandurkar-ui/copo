<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('marks.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$user = current_user() ?? [];
function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function redirect_marks(array $params = []): never {
    $url = 'marks.php';
    if ($params) $url .= '?' . http_build_query($params);
    header('Location: ' . $url); exit;
}

if (empty($_SESSION['marks_csrf'])) $_SESSION['marks_csrf'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['marks_csrf'];
$message = '';
$messageType = 'success';

$sessions = $conn->query('SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
$defaultSessionId = (int)($_SESSION['academic_session_id'] ?? 0);
if (!$defaultSessionId && $sessions) $defaultSessionId = (int)$sessions[0]['id'];
$sessionId = filter_input(INPUT_GET, 'session_id', FILTER_VALIDATE_INT) ?: $defaultSessionId;
$semester = filter_input(INPUT_GET, 'semester', FILTER_VALIDATE_INT) ?: 1;
$semester = max(1, min(8, (int)$semester));
$subjectId = filter_input(INPUT_GET, 'subject_id', FILTER_VALIDATE_INT) ?: 0;
$componentId = filter_input(INPUT_GET, 'component_id', FILTER_VALIDATE_INT) ?: 0;

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals($csrf, (string)($_POST['csrf_token'] ?? ''))) throw new RuntimeException('Your session expired. Refresh the page and try again.');
        $action = (string)($_POST['action'] ?? '');
        $postSessionId = (int)($_POST['session_id'] ?? 0);
        $postSemester = (int)($_POST['semester'] ?? 1);
        $postSubjectId = (int)($_POST['subject_id'] ?? 0);
        $postComponentId = (int)($_POST['component_id'] ?? 0);

        if ($action === 'create_component') {
            $componentName = trim((string)($_POST['component_name'] ?? ''));
            $componentType = (string)($_POST['component_type'] ?? 'sessional');
            $assessmentNo = max(1, min(20, (int)($_POST['assessment_no'] ?? 1)));
            $maxMarks = filter_var($_POST['max_marks'] ?? null, FILTER_VALIDATE_FLOAT);
            $allowedTypes = ['sessional','unit_test','assignment','activity','practical','attendance','other'];
            $validSubject = $conn->prepare('SELECT id FROM subjects WHERE id=? AND academic_session_id=? AND semester=?' . scope_subject_clause());
            $validSubject->bind_param('iii', $postSubjectId, $postSessionId, $postSemester); $validSubject->execute();
            if (!$validSubject->get_result()->fetch_assoc()) throw new RuntimeException('Select a valid subject before adding an assessment.');
            if ($componentName === '' || strlen($componentName) > 100) throw new RuntimeException('Enter an assessment name (up to 100 characters).');
            if (!in_array($componentType, $allowedTypes, true)) throw new RuntimeException('Select a valid assessment type.');
            if ($maxMarks === false || $maxMarks <= 0 || $maxMarks > 100000) throw new RuntimeException('Maximum marks must be greater than zero.');
            $stmt = $conn->prepare('INSERT INTO assessment_components (subject_id, component_name, max_marks, component_type, assessment_no) VALUES (?,?,?,?,?)');
            $stmt->bind_param('isdsi', $postSubjectId, $componentName, $maxMarks, $componentType, $assessmentNo); $stmt->execute();
            redirect_marks(['session_id'=>$postSessionId,'semester'=>$postSemester,'subject_id'=>$postSubjectId,'component_id'=>$stmt->insert_id,'created'=>'1']);
        }

        if ($action === 'save_marks') {
            $valid = $conn->prepare('SELECT ac.id, ac.max_marks FROM assessment_components ac JOIN subjects s ON s.id=ac.subject_id WHERE ac.id=? AND s.id=? AND s.academic_session_id=? AND s.semester=?');
            $valid->bind_param('iiii', $postComponentId, $postSubjectId, $postSessionId, $postSemester); $valid->execute();
            $component = $valid->get_result()->fetch_assoc();
            if (!$component) throw new RuntimeException('Assessment does not match the selected subject/session/semester.');
            $coStmt = $conn->prepare('SELECT id FROM course_outcomes WHERE subject_id=?');
            $coStmt->bind_param('i', $postSubjectId); $coStmt->execute();
            $coIds = array_map('intval', array_column($coStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'id'));
            if (!$coIds) throw new RuntimeException('This subject has no Course Outcomes. Add COs in Subjects & COs before entering marks.');
            $studentsStmt = $conn->prepare("SELECT se.id AS enrollment_id FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE se.academic_session_id=? AND se.semester=? AND se.status='active'" . scope_roster_clause('se', (int)$postSubjectId));
            $studentsStmt->bind_param('ii', $postSessionId, $postSemester); $studentsStmt->execute();
            $enrollmentIds = array_map('intval', array_column($studentsStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'enrollment_id'));
            $marksInput = $_POST['marks'] ?? [];
            $conn->begin_transaction();
            $upsert = $conn->prepare('INSERT INTO marks (enrollment_id, assessment_component_id, course_outcome_id, marks_obtained, updated_by) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE marks_obtained=VALUES(marks_obtained), updated_by=VALUES(updated_by), updated_at=CURRENT_TIMESTAMP');
            $userId = (int)($user['id'] ?? 0); $maxMarks = (float)$component['max_marks']; $savedCount = 0;
            foreach ($enrollmentIds as $enrollmentId) {
                foreach ($coIds as $coId) {
                    $raw = $marksInput[$enrollmentId][$coId] ?? null;
                    if ($raw === null || trim((string)$raw) === '') continue; // blank cells are left unchanged
                    if (!is_numeric($raw)) throw new RuntimeException('Marks must be numeric.');
                    $score = (float)$raw;
                    if ($score < 0 || $score > $maxMarks) throw new RuntimeException('Marks must be between 0 and ' . rtrim(rtrim(number_format($maxMarks, 2, '.', ''), '0'), '.') . '.');
                    $upsert->bind_param('iiidi', $enrollmentId, $postComponentId, $coId, $score, $userId); $upsert->execute(); $savedCount++;
                }
            }
            $conn->commit();
            redirect_marks(['session_id'=>$postSessionId,'semester'=>$postSemester,'subject_id'=>$postSubjectId,'component_id'=>$postComponentId,'saved'=>$savedCount]);
        }
        throw new RuntimeException('Unknown request. Please try again.');
    }
} catch (Throwable $e) {
    if ($conn->errno || $conn->in_transaction) { try { $conn->rollback(); } catch (Throwable $ignored) {} }
    error_log('CO-PO marks page: ' . $e->getMessage());
    $message = $e instanceof mysqli_sql_exception ? 'Database error while processing this request. Check the database setup and try again.' : $e->getMessage();
    $messageType = 'error';
}

if (isset($_GET['created'])) { $message = 'Assessment created successfully.'; $messageType = 'success'; }
if (isset($_GET['saved'])) { $message = 'Marks saved successfully. ' . (int)$_GET['saved'] . ' mark entries updated.'; $messageType = 'success'; }

$subjectStmt = $conn->prepare('SELECT id, subject_code, subject_name FROM subjects WHERE academic_session_id=? AND semester=?' . scope_subject_clause() . ' ORDER BY subject_name');
$subjectStmt->bind_param('ii', $sessionId, $semester); $subjectStmt->execute();
$subjects = $subjectStmt->get_result()->fetch_all(MYSQLI_ASSOC);
if ($subjectId && !array_filter($subjects, fn($s) => (int)$s['id'] === (int)$subjectId)) $subjectId = 0;
if (!$subjectId && $subjects) $subjectId = (int)$subjects[0]['id'];

$components = [];
$cos = [];
$students = [];
$marks = [];
$selectedComponent = null;
if ($subjectId) {
    $componentStmt = $conn->prepare('SELECT id, component_name, max_marks, component_type, assessment_no FROM assessment_components WHERE subject_id=? ORDER BY component_type, assessment_no, component_name');
    $componentStmt->bind_param('i', $subjectId); $componentStmt->execute(); $components = $componentStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    if ($componentId && !array_filter($components, fn($c) => (int)$c['id'] === (int)$componentId)) $componentId = 0;
    if (!$componentId && $components) $componentId = (int)$components[0]['id'];
    $coStmt = $conn->prepare('SELECT id, co_code, description FROM course_outcomes WHERE subject_id=? ORDER BY id');
    $coStmt->bind_param('i', $subjectId); $coStmt->execute(); $cos = $coStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $studentStmt = $conn->prepare("SELECT se.id AS enrollment_id, st.id AS student_id, st.enrollment_no, st.full_name, se.section FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE se.academic_session_id=? AND se.semester=? AND se.status='active'" . scope_roster_clause('se', (int)$subjectId) . " ORDER BY se.section, st.full_name");
    $studentStmt->bind_param('ii', $sessionId, $semester); $studentStmt->execute(); $students = $studentStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    if ($componentId) {
        $selectedComponent = array_values(array_filter($components, fn($c) => (int)$c['id'] === (int)$componentId))[0] ?? null;
        $marksStmt = $conn->prepare('SELECT m.enrollment_id, m.course_outcome_id, m.marks_obtained FROM marks m WHERE m.assessment_component_id=? AND m.course_outcome_id IS NOT NULL');
        $marksStmt->bind_param('i', $componentId); $marksStmt->execute();
        foreach ($marksStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $row) $marks[(int)$row['enrollment_id']][(int)$row['course_outcome_id']] = (string)$row['marks_obtained'];
    }
}

$sessionName = '';
foreach ($sessions as $s) if ((int)$s['id'] === (int)$sessionId) $sessionName = $s['session_name'];
$roleLabel = ucwords(str_replace('_', ' ', (string)($user['role'] ?? 'User')));
$displayName = (string)($user['full_name'] ?? $user['name'] ?? 'User');
$initials = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $displayName) ?: 'U', 0, 2));
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>CO–PO Workspace — Sessional Marks</title><link rel="stylesheet" href="css/style.css">
<style>
.marks-page .filters{display:grid;grid-template-columns:repeat(5,minmax(125px,1fr));gap:12px;align-items:end;padding:18px 20px;border-bottom:1px solid var(--line)}
.marks-page .filters .btn{height:36px;white-space:nowrap}.notice{margin:0 0 16px;padding:12px 15px;border:1px solid #cde4d4;border-radius:5px;background:#edf8f0;color:#245d37}.notice.error{border-color:#f0c9c3;background:#fff0ed;color:#8e3025}
.marks-page .section-note{display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap}.marks-page .co-head small{display:block;font-weight:400;color:var(--muted);margin-top:3px}.marks-page .score-input{width:70px;height:32px;border:1px solid var(--line);border-radius:4px;text-align:center;background:#fff;color:var(--text)}.marks-page .score-input:focus{outline:2px solid #ead9b5;border-color:var(--gold)}.marks-page .student-cell{min-width:200px}.marks-page .student-cell strong{display:block}.marks-page .student-cell small{display:block;color:var(--muted);margin-top:3px}.marks-page .total-cell{font-weight:700;font-variant-numeric:tabular-nums}.marks-page .savebar{padding:15px 20px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}.marks-page .savebar .actions{display:flex;gap:9px}.marks-page .component-box{padding:18px 20px}.marks-page .component-form{display:grid;grid-template-columns:2fr 1fr 1fr 1fr auto;gap:12px;align-items:end}.marks-page .empty-state{padding:28px 20px;text-align:center;color:var(--muted)}.marks-page .empty-state strong{display:block;color:var(--text);margin-bottom:6px}.marks-page .table-wrap{max-height:65vh}.marks-page .data thead th{position:sticky;top:0;z-index:1}.marks-page .small-note{font-size:11px;color:var(--muted);line-height:1.5}.marks-page .score-summary{display:flex;gap:8px;align-items:center}.marks-page .score-summary b{color:var(--text)}
@media(max-width:1200px){.marks-page .filters{grid-template-columns:repeat(3,minmax(140px,1fr))}.marks-page .component-form{grid-template-columns:repeat(2,minmax(140px,1fr))}}
@media(max-width:700px){body{min-width:0}.shell{display:block}.sidebar{width:100%;min-width:0;min-height:0}.side-nav{display:flex;flex-wrap:wrap}.side-group-label{padding-top:10px}.foot{display:none}.topbar{padding:12px;height:auto;flex-wrap:wrap}.content{padding:16px 12px}.page-head{gap:12px;flex-wrap:wrap}.marks-page .filters,.marks-page .component-form{grid-template-columns:1fr}.marks-page .student-cell{min-width:170px}}
</style></head>
<body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main"><header class="topbar"><div class="crumb">CO–PO Workspace / <b>Record marks / Sessional</b></div><div class="topbar-spacer"></div><div class="term-pill"><span class="dot"></span><?=h($sessionName ?: 'No session selected')?> · Semester <?=h($semester)?></div><a class="term-pill" href="profile.php" style="text-decoration:none">Profile</a><a class="term-pill" href="logout.php" style="text-decoration:none">Logout</a></header>
<div class="content marks-page"><section class="page active"><div class="page-head"><div><div class="eyebrow">ASSESSMENT MANAGEMENT</div><h1>Record sessional marks</h1><p>Choose a class and assessment, then enter marks for each student and Course Outcome.</p></div></div>
<?php if ($message !== ''): ?><div class="notice <?= $messageType === 'error' ? 'error' : '' ?>" role="status"><?=h($message)?></div><?php endif; ?>
<div class="card"><form method="get" class="filters">
<div class="field"><label for="session_id">Academic session</label><select class="control" id="session_id" name="session_id" required><?php foreach ($sessions as $s): ?><option value="<?= (int)$s['id']?>" <?=$sessionId===(int)$s['id']?'selected':''?>><?=h($s['session_name'])?><?= (int)$s['is_active']?' · Active':''?></option><?php endforeach; ?></select></div>
<div class="field"><label for="semester">Semester</label><select class="control" id="semester" name="semester"><?php for($i=1;$i<=8;$i++): ?><option value="<?=$i?>" <?=$semester===$i?'selected':''?>>Semester <?=$i?></option><?php endfor; ?></select></div>
<div class="field"><label for="subject_id">Subject</label><select class="control" id="subject_id" name="subject_id" required><option value="">Select subject</option><?php foreach($subjects as $s): ?><option value="<?=(int)$s['id']?>" <?=$subjectId===(int)$s['id']?'selected':''?>><?=h($s['subject_code'].' — '.$s['subject_name'])?></option><?php endforeach; ?></select></div>
<div class="field"><label for="component_id">Assessment</label><select class="control" id="component_id" name="component_id"><option value="">Select assessment</option><?php foreach($components as $c): ?><option value="<?=(int)$c['id']?>" <?=$componentId===(int)$c['id']?'selected':''?>><?=h($c['component_name'])?> · /<?=h($c['max_marks'])?></option><?php endforeach; ?></select></div>
<button class="btn btn-primary" type="submit">Load class list</button></form>
<?php if ($subjectId): ?>
<div class="section-note"><div><b style="font-family:Lora,serif;color:var(--text);font-size:15px"><?=h(array_values(array_filter($subjects,fn($s)=>(int)$s['id']===$subjectId))[0]['subject_name'] ?? 'Selected subject')?></b><div class="small-note">Session <?=h($sessionName)?> · Semester <?=h($semester)?> · Marks are stored per student and CO.</div></div><span class="badge grey"><?=count($students)?> active students</span></div>
<?php if (!$components): ?><div class="empty-state"><strong>No assessments configured for this subject.</strong>Add a sessional test or other assessment below before entering marks.</div><?php elseif (!$cos): ?><div class="empty-state"><strong>No Course Outcomes found.</strong>Add COs for this subject on the Subjects page first. Marks are recorded CO-wise.</div><?php elseif (!$students): ?><div class="empty-state"><strong>No active students found for this class.</strong>Register students for the selected academic session and semester first.</div><?php elseif (!$selectedComponent): ?><div class="empty-state"><strong>Select an assessment.</strong>Choose an assessment from the filter above.</div><?php else: ?>
<form method="post" action="marks.php" id="marksForm"><input type="hidden" name="csrf_token" value="<?=h($csrf)?>"><input type="hidden" name="action" value="save_marks"><input type="hidden" name="session_id" value="<?=(int)$sessionId?>"><input type="hidden" name="semester" value="<?=(int)$semester?>"><input type="hidden" name="subject_id" value="<?=(int)$subjectId?>"><input type="hidden" name="component_id" value="<?=(int)$componentId?>">
<div class="section-note"><div class="co-head"><b style="font-family:Lora,serif;color:var(--text);font-size:14px"><?=h($selectedComponent['component_name'])?></b><small>Maximum <?=h($selectedComponent['max_marks'])?> marks per CO · <?=h(ucwords(str_replace('_',' ',$selectedComponent['component_type'])))?></small></div><div class="score-summary"><span class="small-note">Students</span><b><?=count($students)?></b><span class="small-note">· COs</span><b><?=count($cos)?></b></div></div>
<div class="table-wrap"><table class="data" id="marksTable"><thead><tr><th>#</th><th>Student</th><?php foreach($cos as $co): ?><th class="co-head"><?=h($co['co_code'])?><small>/ <?=h($selectedComponent['max_marks'])?></small></th><?php endforeach; ?><th class="num">Total</th><th>Progress</th></tr></thead><tbody>
<?php foreach($students as $idx=>$st): $eid=(int)$st['enrollment_id']; ?><tr><td class="row-index"><?=$idx+1?></td><td class="student-cell"><strong><?=h($st['full_name'])?></strong><small><?=h($st['enrollment_no'])?> · Section <?=h($st['section'])?></small></td><?php $rowTotal=0; foreach($cos as $co): $coid=(int)$co['id']; $value=$marks[$eid][$coid] ?? ''; if($value!=='') $rowTotal+=(float)$value; ?><td><input class="score-input" type="number" min="0" max="<?=h($selectedComponent['max_marks'])?>" step="0.01" name="marks[<?=$eid?>][<?=$coid?>]" value="<?=h($value)?>" aria-label="<?=h($st['full_name'].' '.$co['co_code'])?>" data-max="<?=h($selectedComponent['max_marks'])?>"></td><?php endforeach; ?><td class="num total-cell" data-total><?=$rowTotal ? h(number_format($rowTotal,2)) : '—'?></td><td><span class="badge grey" data-progress><?=count(array_filter(array_map(fn($co)=>isset($marks[$eid][(int)$co['id']])?'1':'', $cos)))?>/<?=count($cos)?> entered</span></td></tr><?php endforeach; ?>
</tbody></table></div><div class="savebar"><span class="small-note">Leave a cell blank to keep its existing value unchanged. Enter 0 for zero marks.</span><div class="actions"><button class="btn btn-outline" type="reset">Reset form</button><button class="btn btn-gold" type="submit">Save marks</button></div></div></form>
<?php endif; ?>
<?php else: ?><div class="empty-state"><strong>No subjects found for this session and semester.</strong>Add a subject in Subjects &amp; COs, then return here to enter marks.</div><?php endif; ?>
</div>
<div class="card"><div class="card-head"><div><h2>Add assessment</h2><span>Create an assessment component for the selected subject.</span></div></div><div class="component-box"><form method="post" class="component-form"><input type="hidden" name="csrf_token" value="<?=h($csrf)?>"><input type="hidden" name="action" value="create_component"><input type="hidden" name="session_id" value="<?=(int)$sessionId?>"><input type="hidden" name="semester" value="<?=(int)$semester?>"><input type="hidden" name="subject_id" value="<?=(int)$subjectId?>"><div class="field"><label for="component_name">Assessment name</label><input class="control" id="component_name" name="component_name" maxlength="100" placeholder="e.g. Sessional Test I" required></div><div class="field"><label for="component_type">Type</label><select class="control" id="component_type" name="component_type"><?php foreach(['sessional'=>'Sessional','unit_test'=>'Unit test','assignment'=>'Assignment','activity'=>'Activity','practical'=>'Practical','attendance'=>'Attendance','other'=>'Other'] as $key=>$label): ?><option value="<?=h($key)?>"><?=h($label)?></option><?php endforeach; ?></select></div><div class="field"><label for="assessment_no">Assessment no.</label><input class="control" id="assessment_no" name="assessment_no" type="number" min="1" max="20" value="1" required></div><div class="field"><label for="max_marks">Maximum marks</label><input class="control" id="max_marks" name="max_marks" type="number" min="0.01" step="0.01" max="100000" value="10" required></div><button class="btn btn-primary" type="submit" <?=$subjectId?'':'disabled'?>>＋ Add assessment</button></form><p class="small-note" style="margin-top:12px">Assessments are saved against the selected subject. Marks entered in this page are recorded against each Course Outcome.</p></div></div>
</section></div></main></div>
<script>
(function(){
 const table=document.getElementById('marksTable'); if(!table)return;
 function recalc(row){let total=0,entered=0;row.querySelectorAll('.score-input').forEach(input=>{if(input.value.trim()!==''){total+=Number(input.value)||0;entered++;}});const totalCell=row.querySelector('[data-total]');if(totalCell)totalCell.textContent=entered?total.toFixed(2):'—';const progress=row.querySelector('[data-progress]');if(progress)progress.textContent=entered+'/'+row.querySelectorAll('.score-input').length+' entered';}
 table.querySelectorAll('tbody tr').forEach(row=>{recalc(row);row.querySelectorAll('.score-input').forEach(input=>{input.addEventListener('input',()=>{const max=Number(input.dataset.max);if(input.value!==''&&(Number(input.value)<0||Number(input.value)>max)){input.setCustomValidity('Enter a mark between 0 and '+max+'.');}else input.setCustomValidity('');recalc(row);});});});
 const form=document.getElementById('marksForm');if(form)form.addEventListener('submit',e=>{if(!form.reportValidity())e.preventDefault();});
})();
</script></body></html>
