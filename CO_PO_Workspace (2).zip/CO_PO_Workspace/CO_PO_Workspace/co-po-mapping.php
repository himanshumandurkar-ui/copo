<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('co-po-mapping.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = db();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf_token'];
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$sessions = $conn->query("SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC")->fetch_all(MYSQLI_ASSOC);
$sessionId = filter_input(INPUT_GET, 'session_id', FILTER_VALIDATE_INT) ?: 0;
if (!$sessionId && $sessions) $sessionId = (int)$sessions[0]['id'];
$semester = filter_input(INPUT_GET, 'semester', FILTER_VALIDATE_INT) ?: 1;
$semester = max(1, min(8, $semester));
$subjectId = filter_input(INPUT_GET, 'subject_id', FILTER_VALIDATE_INT) ?: 0;
$message = '';
$error = '';

function selected_subject(mysqli $conn, int $subjectId, int $sessionId, int $semester): ?array {
    if (!$subjectId) return null;
    $stmt = $conn->prepare('SELECT id, subject_code, subject_name, semester, academic_session_id FROM subjects WHERE id=? AND academic_session_id=? AND semester=?' . scope_subject_clause());
    $stmt->bind_param('iii', $subjectId, $sessionId, $semester);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && role_is('principal', 'subject_incharge')) {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals($csrf, $postedToken)) {
        $error = 'Session expired. Refresh the page and try again.';
    } else {
        $sessionId = (int)($_POST['session_id'] ?? 0);
        $semester = max(1, min(8, (int)($_POST['semester'] ?? 1)));
        $subjectId = (int)($_POST['subject_id'] ?? 0);
        $subject = selected_subject($conn, $subjectId, $sessionId, $semester);
        if (!$subject) {
            $error = 'Please select a valid subject for the chosen session and semester.';
        } else {
            $levels = $_POST['mapping'] ?? [];
            $coStmt = $conn->prepare('SELECT id FROM course_outcomes WHERE subject_id=? ORDER BY id');
            $coStmt->bind_param('i', $subjectId);
            $coStmt->execute();
            $validCOs = array_map('intval', array_column($coStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'id'));
            $coStmt->close();
            if (!$validCOs) {
                $error = 'Add Course Outcomes for this subject before saving CO–PO mapping.';
            } else {
                $user = current_user() ?? [];
                $userId = isset($user['id']) ? (int)$user['id'] : 0;
                try {
                    $conn->begin_transaction();
                    $upsert = $conn->prepare('INSERT INTO co_po_mapping (course_outcome_id, po_number, mapping_level, updated_by) VALUES (?, ?, ?, NULLIF(?,0)) ON DUPLICATE KEY UPDATE mapping_level=VALUES(mapping_level), updated_by=VALUES(updated_by)');
                    foreach ($validCOs as $coId) {
                        for ($po = 1; $po <= 12; $po++) {
                            $level = isset($levels[$coId][$po]) ? (int)$levels[$coId][$po] : 0;
                            if ($level < 0 || $level > 3) throw new RuntimeException('Mapping levels must be between 0 and 3.');
                            $upsert->bind_param('iiii', $coId, $po, $level, $userId);
                            $upsert->execute();
                        }
                    }
                    $upsert->close();
                    $conn->commit();
                    $message = 'CO–PO mapping saved successfully.';
                } catch (Throwable $ex) {
                    $conn->rollback();
                    $error = 'Unable to save mapping. Check the database and try again.';
                }
            }
        }
    }
}

$subjectStmt = $conn->prepare('SELECT id, subject_code, subject_name FROM subjects WHERE academic_session_id=? AND semester=?' . scope_subject_clause() . ' ORDER BY subject_code, subject_name');
$subjectStmt->bind_param('ii', $sessionId, $semester);
$subjectStmt->execute();
$subjects = $subjectStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$subjectStmt->close();
if ($subjectId && !array_filter($subjects, fn($s) => (int)$s['id'] === $subjectId)) $subjectId = 0;
$subject = selected_subject($conn, $subjectId, $sessionId, $semester);
$cos = [];
$mapping = [];
if ($subject) {
    $coStmt = $conn->prepare('SELECT id, co_code, description FROM course_outcomes WHERE subject_id=? ORDER BY id');
    $coStmt->bind_param('i', $subjectId);
    $coStmt->execute();
    $cos = $coStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $coStmt->close();
    $mapStmt = $conn->prepare('SELECT course_outcome_id, po_number, mapping_level FROM co_po_mapping WHERE course_outcome_id IN (SELECT id FROM course_outcomes WHERE subject_id=?)');
    $mapStmt->bind_param('i', $subjectId);
    $mapStmt->execute();
    foreach ($mapStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $row) $mapping[(int)$row['course_outcome_id']][(int)$row['po_number']] = (int)$row['mapping_level'];
    $mapStmt->close();
}
$activeSessionName = '';
foreach ($sessions as $s) if ((int)$s['id'] === $sessionId) $activeSessionName = $s['session_name'];
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>CO–PO Workspace — CO–PO Mapping</title><link rel="stylesheet" href="css/style.css">
<style>
.mapping-toolbar{display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;padding:16px 20px;background:#fff;border-bottom:1px solid var(--line)}.mapping-toolbar .field{min-width:145px;flex:1}.mapping-toolbar .subject-field{min-width:250px;flex:2}.notice{padding:11px 14px;margin:0 0 16px;border-radius:4px;font-size:12px}.notice.success{background:var(--greent);color:var(--green);border:1px solid #cce5d8}.notice.error{background:var(--redt);color:var(--red);border:1px solid #f0d0c8}.mapping-cell{padding:4px!important;min-width:58px}.mapping-select{width:50px;height:31px;border:1px solid var(--line);border-radius:4px;background:#fff;text-align:center;color:var(--text);font-weight:600}.mapping-select.level-3{background:#c38b28;color:#2a1e08;border-color:#c38b28}.mapping-select.level-2{background:#f2e4c8;color:#80591a;border-color:#e4cfaa}.mapping-select.level-1{background:#f0f0ea;color:#657185}.mapping-select.level-0{background:#fff;color:#9aa3b0}.co-description{min-width:240px;max-width:330px;white-space:normal;line-height:1.45;color:#68758a}.matrix-footer{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-top:16px}.mapping-stats{display:flex;gap:10px;flex-wrap:wrap}.mapping-stats span{background:#f7f8f6;border:1px solid var(--line2);border-radius:4px;padding:8px 10px;color:#5d6a7f;font-size:11px}.mapping-stats b{color:var(--text)}.empty-state{padding:28px;text-align:center;color:#78859a}.empty-state strong{display:block;color:var(--text);margin-bottom:6px}.legend{flex-wrap:wrap}.top-actions{display:flex;gap:8px;flex-wrap:wrap}@media(max-width:900px){body{min-width:0}.shell{min-width:0}.sidebar{width:210px;min-width:210px}.content{padding:18px 12px}.topbar{padding:0 12px}.co-description{min-width:180px}}
</style></head>
<body><div class="shell"><?php require __DIR__ . '/includes/sidebar.php'; ?><main class="main">
<header class="topbar"><div class="crumb">CO–PO Workspace / <b>Attainment / CO–PO Mapping</b></div><div class="topbar-spacer"></div><div class="term-pill"><span class="dot"></span><?= e($activeSessionName ?: 'Select session') ?> · Semester <?= (int)$semester ?></div><a class="term-pill" href="profile.php" style="text-decoration:none">Profile</a><a class="term-pill" href="logout.php" style="text-decoration:none">Logout</a></header>
<div class="content"><div class="page-head"><div><h1>CO–PO Mapping</h1><p>Map each Course Outcome to Program Outcomes using correlation levels.</p></div><div class="top-actions"><button class="btn btn-outline" type="button" onclick="window.print()">Print matrix</button></div></div>
<?php if ($message): ?><div class="notice success" role="status"><?= e($message) ?></div><?php endif; ?><?php if ($error): ?><div class="notice error" role="alert"><?= e($error) ?></div><?php endif; ?>
<div class="card"><form method="get" class="mapping-toolbar"><div class="field"><label for="session_id">Academic session</label><select class="control" id="session_id" name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= (int)$s['id']===$sessionId?'selected':'' ?>><?= e($s['session_name']) ?><?= (int)$s['is_active']===1?' (Active)':'' ?></option><?php endforeach; ?></select></div><div class="field"><label for="semester">Semester</label><select class="control" id="semester" name="semester" onchange="this.form.submit()"><?php for($sem=1;$sem<=8;$sem++): ?><option value="<?= $sem ?>" <?= $sem===$semester?'selected':'' ?>>Semester <?= $sem ?></option><?php endfor; ?></select></div><div class="field subject-field"><label for="subject_id">Subject</label><select class="control" id="subject_id" name="subject_id" onchange="this.form.submit()"><option value="">Select subject</option><?php foreach ($subjects as $s): ?><option value="<?= (int)$s['id'] ?>" <?= (int)$s['id']===$subjectId?'selected':'' ?>><?= e($s['subject_code']) ?> — <?= e($s['subject_name']) ?></option><?php endforeach; ?></select></div><noscript><button class="btn btn-primary" type="submit">Load</button></noscript></form>
<?php if (!$sessions): ?><div class="empty-state"><strong>No academic sessions found</strong>Add an academic session before setting up mappings.</div><?php elseif (!$subjects): ?><div class="empty-state"><strong>No subjects found for this selection</strong>Add a subject for the selected academic session and semester.</div><?php elseif (!$subject): ?><div class="empty-state"><strong>Select a subject</strong>Choose a subject above to load its Course Outcomes and mapping matrix.</div><?php elseif (!$cos): ?><div class="empty-state"><strong>No Course Outcomes found for <?= e($subject['subject_code']) ?></strong>Add COs on the Subjects & COs page before creating the mapping.</div><?php else: ?>
<form method="post" id="mappingForm"><input type="hidden" name="csrf_token" value="<?= e($csrf) ?>"><input type="hidden" name="session_id" value="<?= (int)$sessionId ?>"><input type="hidden" name="semester" value="<?= (int)$semester ?>"><input type="hidden" name="subject_id" value="<?= (int)$subjectId ?>">
<div class="card-head"><div><h2><?= e($subject['subject_name']) ?> · <?= e($subject['subject_code']) ?></h2><span>Semester <?= (int)$subject['semester'] ?> · <?= e($activeSessionName) ?> · <?= count($cos) ?> Course Outcome(s)</span></div><button class="btn btn-gold" type="submit">＋ Save mapping</button></div>
<div class="panel-body"><div class="matrix-wrap"><table class="matrix"><thead><tr><th class="row-h">Course Outcome</th><th style="min-width:240px;text-align:left;padding-left:12px">Description</th><?php for($po=1;$po<=12;$po++): ?><th>PO <?= $po ?></th><?php endfor; ?></tr></thead><tbody>
<?php foreach($cos as $co): ?><tr><th class="row-h"><?= e($co['co_code']) ?></th><td class="co-description"><?= e($co['description']) ?></td><?php for($po=1;$po<=12;$po++): $level=$mapping[(int)$co['id']][$po]??0; ?><td class="mapping-cell"><select aria-label="<?= e($co['co_code']) ?> to PO <?= $po ?>" name="mapping[<?= (int)$co['id'] ?>][<?= $po ?>]" class="mapping-select level-<?= $level ?>" <?= role_is('hod') ? 'disabled' : '' ?> data-co="<?= (int)$co['id'] ?>" data-po="<?= $po ?>"><option value="0" <?= $level===0?'selected':'' ?>>–</option><option value="1" <?= $level===1?'selected':'' ?>>1</option><option value="2" <?= $level===2?'selected':'' ?>>2</option><option value="3" <?= $level===3?'selected':'' ?>>3</option></select></td><?php endfor; ?></tr><?php endforeach; ?>
</tbody></table></div><div class="legend"><span><span class="sw" style="background:#c38b28"></span>3 – Strong</span><span><span class="sw" style="background:#f2e4c8"></span>2 – Moderate</span><span><span class="sw" style="background:#f0f0ea"></span>1 – Slight</span><span><span class="sw" style="background:#fff;border:1px solid #dfe3e2"></span>– No mapping</span></div><div class="matrix-footer"><div class="mapping-stats"><span>COs: <b><?= count($cos) ?></b></span><span>Possible mappings: <b><?= count($cos)*12 ?></b></span><span>Mapped cells: <b id="mappedCount">0</b></span></div><?php if (role_is('principal', 'subject_incharge')): ?><button class="btn btn-gold" type="submit">Save mapping</button><?php else: ?><span class="muted">Read-only CO–PO mapping report — edited by the subject incharge.</span><?php endif; ?></div></div></form><?php endif; ?></div>
<div class="card" style="margin-top:18px"><div class="card-head"><div><h2>Mapping guide</h2><span>Use the department-approved correlation scale for each CO–PO relationship.</span></div></div><div class="panel-body"><div class="legend"><span><span class="sw" style="background:#c38b28"></span><b>3 — Strong</b> relationship</span><span><span class="sw" style="background:#f2e4c8"></span><b>2 — Moderate</b> relationship</span><span><span class="sw" style="background:#f0f0ea"></span><b>1 — Slight</b> relationship</span><span><span class="sw" style="background:#fff;border:1px solid #dfe3e2"></span><b>0 — None</b></span></div><p class="hint" style="margin-top:14px">Only approved mappings should be entered. Saving replaces the current correlation level for each CO–PO pair shown in this matrix.</p></div></div>
</div></main></div><script>
(function(){const selects=document.querySelectorAll('.mapping-select');const count=document.getElementById('mappedCount');function refresh(){let n=0;selects.forEach(s=>{s.className='mapping-select level-'+s.value;if(s.value!=='0')n++;});if(count)count.textContent=n;}selects.forEach(s=>s.addEventListener('change',refresh));refresh();})();
</script></body></html>
