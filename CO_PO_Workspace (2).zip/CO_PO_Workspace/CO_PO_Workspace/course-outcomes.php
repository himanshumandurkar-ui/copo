<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('course-outcomes.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$msg = ''; $error = '';
$sessions = $conn->query('SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
[$loginSessionId] = session_selected($conn);
$sessionId = filter_input(INPUT_GET, 'session_id', FILTER_VALIDATE_INT) ?: $loginSessionId;
$semester  = filter_input(INPUT_GET, 'semester', FILTER_VALIDATE_INT) ?: 1;
$subjectId = filter_input(INPUT_GET, 'subject_id', FILTER_VALIDATE_INT) ?: 0;
if ($semester < 1 || $semester > 8) $semester = 1;

function co_load_subjects(mysqli $conn, int $sessionId, int $semester): array {
    $sql = 'SELECT id, subject_code, subject_name FROM subjects WHERE academic_session_id=? AND semester=?' . scope_subject_clause() . ' ORDER BY subject_code';
    $stmt = $conn->prepare($sql); $stmt->bind_param('ii', $sessionId, $semester); $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    return $rows;
}
function co_count_for(mysqli $conn, string $sql, int $id): int {
    $stmt = $conn->prepare($sql); $stmt->bind_param('i', $id); $stmt->execute();
    $n = (int)$stmt->get_result()->fetch_assoc()['n']; $stmt->close();
    return $n;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    try {
        $sessionId = (int)($_POST['session_id'] ?? 0);
        $semester  = max(1, min(8, (int)($_POST['semester'] ?? 1)));
        $subjectId = (int)($_POST['subject_id'] ?? 0);
        $action = (string)($_POST['action'] ?? '');
        if (!scope_can_use_subject($conn, $subjectId)) throw new RuntimeException('You do not have access to this subject.');
        $chk = $conn->prepare('SELECT id FROM subjects WHERE id=? AND academic_session_id=? AND semester=?');
        $chk->bind_param('iii', $subjectId, $sessionId, $semester); $chk->execute();
        if (!$chk->get_result()->fetch_assoc()) throw new RuntimeException('Subject does not match the selected session and semester.');
        $chk->close();

        if ($action === 'save_cos') {
            $descs = $_POST['description'] ?? [];
            $conn->begin_transaction();
            $up = $conn->prepare('UPDATE course_outcomes SET description=? WHERE id=? AND subject_id=?');
            $n = 0;
            foreach ($descs as $coId => $text) {
                $coId = (int)$coId; $text = trim((string)$text);
                if ($coId < 1) continue;
                if ($text === '') throw new RuntimeException('Every course outcome needs a description.');
                if (mb_strlen($text) > 2000) throw new RuntimeException('A course outcome description is too long.');
                $up->bind_param('sii', $text, $coId, $subjectId); $up->execute(); $n++;
            }
            $conn->commit();
            audit_write($conn, 'co.save', 'subject', $subjectId, ['updated' => $n]);
            $msg = "Course outcomes saved ({$n}).";
        } elseif ($action === 'add_co') {
            $count = co_count_for($conn, 'SELECT COUNT(*) n FROM course_outcomes WHERE subject_id=?', $subjectId);
            if ($count >= 12) throw new RuntimeException('A subject can have at most 12 course outcomes.');
            $stmt = $conn->prepare('SELECT COALESCE(MAX(CAST(SUBSTRING(co_code,3) AS UNSIGNED)),0) n FROM course_outcomes WHERE subject_id=?');
            $stmt->bind_param('i', $subjectId); $stmt->execute();
            $next = (int)$stmt->get_result()->fetch_assoc()['n'] + 1; $stmt->close();
            $code = 'CO' . $next; $text = trim((string)($_POST['new_description'] ?? ''));
            if ($text === '') throw new RuntimeException('Enter a description for the new course outcome.');
            $ins = $conn->prepare('INSERT INTO course_outcomes(subject_id, co_code, description) VALUES (?,?,?)');
            $ins->bind_param('iss', $subjectId, $code, $text); $ins->execute();
            audit_write($conn, 'co.add', 'subject', $subjectId, ['co' => $code]);
            $msg = $code . ' added.';
        } elseif ($action === 'delete_co') {
            $coId = (int)($_POST['co_id'] ?? 0);
            if ($coId < 1) throw new RuntimeException('Select a valid course outcome.');
            $marks = co_count_for($conn, 'SELECT COUNT(*) n FROM marks WHERE course_outcome_id=?', $coId);
            if ($marks > 0) throw new RuntimeException('This course outcome already has marks recorded, so it cannot be deleted (records are kept for audit).');
            $del = $conn->prepare('DELETE FROM course_outcomes WHERE id=? AND subject_id=?');
            $del->bind_param('ii', $coId, $subjectId); $del->execute();
            audit_write($conn, 'co.delete', 'subject', $subjectId, ['co_id' => $coId]);
            $msg = 'Course outcome deleted.';
        }
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $e2) {}
        $error = $e instanceof RuntimeException ? $e->getMessage() : 'Could not save. Please try again.';
    }
}

$subjects = co_load_subjects($conn, $sessionId, $semester);
$subject = null;
foreach ($subjects as $s) if ((int)$s['id'] === $subjectId) $subject = $s;
if (!$subject) $subjectId = 0;
$cos = [];
if ($subjectId) {
    $stmt = $conn->prepare('SELECT co.id, co.co_code, co.description, (SELECT COUNT(*) FROM marks m WHERE m.course_outcome_id=co.id) AS mark_rows FROM course_outcomes co WHERE co.subject_id=? ORDER BY CAST(SUBSTRING(co.co_code,3) AS UNSIGNED)');
    $stmt->bind_param('i', $subjectId); $stmt->execute(); $cos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Course Outcomes — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css">
<script>function ctx(){var s=document.getElementById('session_id').value,m=document.getElementById('semester').value,j=document.getElementById('subject_id');window.location='course-outcomes.php?session_id='+s+'&semester='+m+(j&&j.value?'&subject_id='+j.value:'');}function ctxReset(){var s=document.getElementById('session_id').value,m=document.getElementById('semester').value;window.location='course-outcomes.php?session_id='+s+'&semester='+m;}</script>
</head><body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Course Outcomes'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow">SUBJECT LEVEL</div><h1>Course Outcomes (COs)</h1><p>Select a subject semester-wise, then add or edit the statements of its course outcomes.</p></div></div>
<?php ui_notice($msg, 'ok'); ui_notice($error, 'err'); ?>

<div class="card"><div class="card-head"><div><h2>Select subject</h2><span><?= role_is('subject_incharge') ? 'Only subjects assigned to you are listed' : 'Subjects you can manage' ?></span></div></div>
<div class="panel-body"><div class="form-row tight">
<div class="field"><label>Academic session</label><select class="control" id="session_id" onchange="ctxReset()"><?php foreach ($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $sessionId === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['session_name']) ?></option><?php endforeach; ?></select></div>
<div class="field"><label>Semester</label><select class="control" id="semester" onchange="ctxReset()"><?php for ($i = 1; $i <= 8; $i++): ?><option value="<?= $i ?>" <?= $semester === $i ? 'selected' : '' ?>>Semester <?= $i ?></option><?php endfor; ?></select></div>
<div class="field"><label>Subject</label><select class="control" id="subject_id" onchange="ctx()"><option value="">Select subject</option><?php foreach ($subjects as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $subjectId === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['subject_code'] . ' — ' . $s['subject_name']) ?></option><?php endforeach; ?></select></div>
</div></div></div>

<?php if ($subject): ?>
<form method="post" class="card" style="margin-top:20px"><?= csrf_field() ?>
<input type="hidden" name="session_id" value="<?= (int)$sessionId ?>"><input type="hidden" name="semester" value="<?= (int)$semester ?>"><input type="hidden" name="subject_id" value="<?= (int)$subjectId ?>">
<div class="card-head"><div><h2><?= h($subject['subject_code'] . ' — ' . $subject['subject_name']) ?></h2><span><?= count($cos) ?> course outcome<?= count($cos) === 1 ? '' : 's' ?></span></div><button class="btn btn-gold btn-sm" type="submit" name="action" value="save_cos">Save descriptions</button></div>
<div class="table-wrap"><table class="data"><thead><tr><th style="width:80px">CO</th><th>Description</th><th style="width:110px">Marks entered</th><th style="width:90px"></th></tr></thead><tbody>
<?php if (!$cos): ?><tr><td colspan="4"><div class="muted-empty">No course outcomes yet. Add the first one below.</div></td></tr><?php endif; ?>
<?php foreach ($cos as $co): ?>
<tr><td><b><?= h($co['co_code']) ?></b></td>
<td><textarea class="control" name="description[<?= (int)$co['id'] ?>]" rows="2" maxlength="2000"><?= h($co['description']) ?></textarea></td>
<td><?= (int)$co['mark_rows'] > 0 ? '<span class="badge gold">' . (int)$co['mark_rows'] . ' rows</span>' : '<span class="badge grey">none</span>' ?></td>
<td><?php if ((int)$co['mark_rows'] === 0): ?><button class="btn btn-danger btn-sm" type="submit" name="action" value="delete_co" onclick="this.form.co_id.value=<?= (int)$co['id'] ?>;return confirm('Delete <?= h($co['co_code']) ?>?');">Delete</button><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<input type="hidden" name="co_id" value="0">
<div class="panel-body" style="border-top:1px solid var(--line2)"><div class="form-row"><div class="field" style="grid-column:1/-1"><label>Add a course outcome</label><textarea class="control" name="new_description" rows="2" maxlength="2000" placeholder="e.g. Apply normalization techniques to relational schemas"></textarea></div></div>
<div class="form-actions"><button class="btn btn-outline" type="submit" name="action" value="add_co">＋ Add course outcome</button></div></div>
</form>
<?php elseif ($subjects): ?><div class="card" style="margin-top:20px"><div class="muted-empty">Select a subject above to manage its course outcomes.</div></div>
<?php else: ?><div class="card" style="margin-top:20px"><div class="muted-empty">No subjects found for this session and semester<?= role_is('subject_incharge') ? ' that are assigned to you. Ask your HOD to assign a subject.' : '.' ?></div></div><?php endif; ?>
</section></div></main></div></body></html>
