<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('departments.php');          // principal only
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$msg = ''; $error = '';
[$sessionId, $sessionName] = session_selected($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    try {
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'add') {
            $name = trim((string)($_POST['name'] ?? ''));
            if ($name === '' || mb_strlen($name) > 150) throw new RuntimeException('Enter a department name (up to 150 characters).');
            $stmt = $conn->prepare('INSERT INTO departments(name) VALUES (?)'); $stmt->bind_param('s', $name); $stmt->execute();
            audit_write($conn, 'department.add', 'department', (int)$conn->insert_id, ['name' => $name]);
            $msg = 'Department added.';
        } elseif ($action === 'rename') {
            $id = (int)($_POST['id'] ?? 0); $name = trim((string)($_POST['name'] ?? ''));
            if ($id < 1 || $name === '' || mb_strlen($name) > 150) throw new RuntimeException('Enter a valid department name.');
            $stmt = $conn->prepare('SELECT name FROM departments WHERE id=?'); $stmt->bind_param('i', $id); $stmt->execute();
            $old = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$old) throw new RuntimeException('Department not found.');
            $conn->begin_transaction();
            $stmt = $conn->prepare('UPDATE departments SET name=? WHERE id=?'); $stmt->bind_param('si', $name, $id); $stmt->execute(); $stmt->close();
            $stmt = $conn->prepare('UPDATE users SET department=? WHERE department=?'); $oldName = $old['name']; $stmt->bind_param('ss', $name, $oldName); $stmt->execute(); $stmt->close();
            $conn->commit();
            audit_write($conn, 'department.rename', 'department', $id, ['from' => $oldName, 'to' => $name]);
            $msg = 'Department renamed.';
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $refs = 0;
            foreach (['SELECT COUNT(*) n FROM students WHERE department_id=?', 'SELECT COUNT(*) n FROM subjects WHERE department_id=?',
                      'SELECT COUNT(*) n FROM users u JOIN departments d ON d.name=u.department WHERE d.id=?'] as $sql) {
                $stmt = $conn->prepare($sql); $stmt->bind_param('i', $id); $stmt->execute();
                $refs += (int)$stmt->get_result()->fetch_assoc()['n']; $stmt->close();
            }
            if ($refs > 0) throw new RuntimeException('This department still has students, subjects or staff, so it cannot be deleted (records are kept for history).');
            $stmt = $conn->prepare('DELETE FROM departments WHERE id=?'); $stmt->bind_param('i', $id); $stmt->execute();
            audit_write($conn, 'department.delete', 'department', $id);
            $msg = 'Department deleted.';
        }
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $e2) {}
        $error = $e instanceof mysqli_sql_exception && (int)$e->getCode() === 1062 ? 'A department with that name already exists.'
               : ($e instanceof RuntimeException ? $e->getMessage() : 'Could not save the department.');
    }
}

$base = "SELECT d.id, d.name,
  (SELECT COUNT(*) FROM users u WHERE u.department=d.name AND u.active=1) AS faculty,
  (SELECT COUNT(DISTINCT st.id) FROM students st JOIN student_enrollments se ON se.student_id=st.id WHERE st.department_id=d.id AND se.academic_session_id=? AND se.status='active') AS students,
  (SELECT COUNT(*) FROM subjects s WHERE s.department_id=d.id AND s.academic_session_id=?) AS subjects";
$rows = [];
try {
    $stmt = $conn->prepare($base . ",
      (SELECT COUNT(*) FROM program_outcomes po WHERE po.department_id=d.id) AS pos,
      (SELECT AVG(ar.level_value) FROM attainment_results ar JOIN subjects s2 ON s2.id=ar.subject_id WHERE s2.department_id=d.id AND ar.outcome_type='CO' AND ar.academic_session_id=?) AS avg_co
      FROM departments d ORDER BY d.name");
    $stmt->bind_param('iii', $sessionId, $sessionId, $sessionId);
} catch (Throwable $e) {
    $stmt = $conn->prepare($base . ', 0 AS pos, NULL AS avg_co FROM departments d ORDER BY d.name');
    $stmt->bind_param('ii', $sessionId, $sessionId);
}
$stmt->execute(); $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Departments — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Departments'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow">COLLEGE LEVEL</div><h1>Departments</h1><p>Overview of every department for <?= h($sessionName) ?>. Open a department's outcomes, or add a new department.</p></div></div>
<?php ui_notice($msg, 'ok'); ui_notice($error, 'err'); ?>

<div class="card"><div class="card-head"><div><h2>Add department</h2></div></div>
<form method="post" class="panel-body"><?= csrf_field() ?><input type="hidden" name="action" value="add"><div class="form-row"><div class="field"><label>Department name</label><input class="control" name="name" maxlength="150" required placeholder="e.g. Mechanical Engineering"></div><div class="field"><button class="btn btn-gold" type="submit">＋ Add department</button></div></div></form></div>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>All departments</h2><span>Counts are for the selected academic session</span></div><span class="badge grey"><?= count($rows) ?> departments</span></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Department</th><th class="num">Faculty</th><th class="num">Students</th><th class="num">Subjects</th><th class="num">POs defined</th><th class="num">Avg CO level</th><th style="width:300px">Manage</th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="7"><div class="muted-empty">No departments yet.</div></td></tr><?php endif; ?>
<?php foreach ($rows as $d): ?><tr><td><b><?= h($d['name']) ?></b></td><td class="num"><?= (int)$d['faculty'] ?></td><td class="num"><?= (int)$d['students'] ?></td><td class="num"><?= (int)$d['subjects'] ?></td><td class="num"><?= (int)$d['pos'] ?> / 12</td><td class="num"><?= $d['avg_co'] === null ? '<span class="badge grey">—</span>' : ui_level_badge((float)$d['avg_co']) ?></td>
<td><form method="post" class="inline-form" style="display:inline-flex;gap:6px"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><input class="control" style="height:30px;width:150px" name="name" value="<?= h($d['name']) ?>" maxlength="150"><button class="btn btn-outline btn-sm" name="action" value="rename" type="submit">Rename</button><a class="btn btn-outline btn-sm" href="program-outcomes.php?dept=<?= (int)$d['id'] ?>">POs</a><button class="btn btn-danger btn-sm" name="action" value="delete" type="submit" onclick="return confirm('Delete this department?')">Delete</button></form></td></tr>
<?php endforeach; ?></tbody></table></div></div>
</section></div></main></div></body></html>
