<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('dashboard.php');
require_once __DIR__ . '/includes/db.php';

$user = current_user();
$userId = (int)($user['id'] ?? 0);
if ($userId < 1) {
    header('Location: index.php?error=' . urlencode('Please sign in again.'));
    exit;
}
if (empty($_SESSION['profile_csrf'])) {
    $_SESSION['profile_csrf'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['profile_csrf'];
$success = '';
$error = '';

function profile_h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function profile_redirect_message(string $type, string $message): void {
    header('Location: profile.php?' . $type . '=' . urlencode($message));
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $postedToken = (string)($_POST['csrf_token'] ?? '');
        if (!hash_equals($csrf, $postedToken)) {
            throw new RuntimeException('Your session token expired. Refresh the page and try again.');
        }

        $action = (string)($_POST['action'] ?? '');
        if ($action === 'update_profile') {
            $name = trim((string)($_POST['full_name'] ?? ''));
            $email = strtolower(trim((string)($_POST['email'] ?? '')));
            $department = trim((string)($_POST['department'] ?? ''));
            $employeeId = trim((string)($_POST['employee_id'] ?? ''));

            if ($name === '' || mb_strlen($name) > 150) {
                throw new RuntimeException('Enter a name between 1 and 150 characters.');
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
                throw new RuntimeException('Enter a valid email address.');
            }
            if ($department === '' || mb_strlen($department) > 150) {
                throw new RuntimeException('Enter a department up to 150 characters.');
            }
            if (mb_strlen($employeeId) > 80) {
                throw new RuntimeException('Employee ID must be 80 characters or fewer.');
            }

            $stmt = db()->prepare('UPDATE users SET full_name = ?, email = ?, department = ?, employee_id = ? WHERE id = ? AND active = 1');
            $employeeIdValue = $employeeId === '' ? null : $employeeId;
            $stmt->bind_param('ssssi', $name, $email, $department, $employeeIdValue, $userId);
            $stmt->execute();
            if ($stmt->affected_rows === 0) {
                $check = db()->prepare('SELECT id FROM users WHERE id = ? AND active = 1');
                $check->bind_param('i', $userId);
                $check->execute();
                if (!$check->get_result()->fetch_assoc()) {
                    throw new RuntimeException('Your account is inactive or no longer available.');
                }
                // affected_rows can be zero when the submitted values are unchanged.
            }
            $_SESSION['user']['name'] = $name;
            $_SESSION['user']['full_name'] = $name;
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['department'] = $department;
            $_SESSION['user']['employee_id'] = $employeeIdValue;
            profile_redirect_message('success', 'Profile details updated successfully.');
        }

        if ($action === 'change_password') {
            $currentPassword = (string)($_POST['current_password'] ?? '');
            $newPassword = (string)($_POST['new_password'] ?? '');
            $confirmPassword = (string)($_POST['confirm_password'] ?? '');
            if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
                throw new RuntimeException('Complete all password fields.');
            }
            if (strlen($newPassword) < 8) {
                throw new RuntimeException('New password must be at least 8 characters long.');
            }
            if ($newPassword !== $confirmPassword) {
                throw new RuntimeException('New password and confirmation do not match.');
            }
            if ($currentPassword === $newPassword) {
                throw new RuntimeException('Choose a new password different from your current password.');
            }

            $stmt = db()->prepare('SELECT password_hash FROM users WHERE id = ? AND active = 1 LIMIT 1');
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            if (!$row || !password_verify($currentPassword, $row['password_hash'])) {
                throw new RuntimeException('Current password is incorrect.');
            }
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $update = db()->prepare('UPDATE users SET password_hash = ? WHERE id = ? AND active = 1');
            $update->bind_param('si', $newHash, $userId);
            $update->execute();
            session_regenerate_id(true);
            $_SESSION['profile_csrf'] = bin2hex(random_bytes(32));
            profile_redirect_message('success', 'Password changed successfully.');
        }
        throw new RuntimeException('Unknown profile action.');
    }

    $stmt = db()->prepare('SELECT full_name, email, role, department, employee_id, created_at FROM users WHERE id = ? AND active = 1 LIMIT 1');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $profile = $stmt->get_result()->fetch_assoc();
    if (!$profile) {
        $_SESSION = [];
        session_destroy();
        header('Location: index.php?error=' . urlencode('Account not found. Please sign in again.'));
        exit;
    }
} catch (Throwable $e) {
    if ($e instanceof mysqli_sql_exception && (int)$e->getCode() === 1062) {
        $error = 'That email address is already used by another account.';
    } else {
        $error = $e->getMessage();
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        error_log('CO-PO profile error: ' . $e->getMessage());
        $error = 'Unable to load profile details. Check the database connection and try again.';
    }
    // Keep the current database-backed profile visible after validation errors.
    if (!isset($profile)) {
        $profile = [
            'full_name' => $user['full_name'] ?? $user['name'] ?? '',
            'email' => $user['email'] ?? '',
            'role' => $user['role'] ?? '',
            'department' => $user['department'] ?? '',
            'employee_id' => $user['employee_id'] ?? '',
            'created_at' => null,
        ];
    }
}

if (isset($_GET['success'])) $success = trim((string)$_GET['success']);
if (isset($_GET['error'])) $error = trim((string)$_GET['error']);
$roleLabel = ucwords(str_replace('_', ' ', (string)($profile['role'] ?? '')));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>My Profile — CO–PO Workspace</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .profile-grid{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(280px,.9fr);gap:20px;align-items:start}
        .profile-card{padding:24px;min-width:0}.profile-card h2{margin:0 0 6px;font-size:20px}.profile-card .intro{margin:0 0 20px;color:var(--muted,#687083);font-size:14px}
        .profile-form{display:grid;gap:15px}.profile-field{display:grid;gap:7px}.profile-field label{font-weight:600;font-size:13px}.profile-field input{width:100%;box-sizing:border-box}
        .profile-field input[readonly]{background:#f3f4f6;color:#626b7c}.profile-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:4px}
        .profile-alert{padding:12px 15px;border-radius:10px;margin:0 0 18px;font-size:14px}.profile-alert.success{background:#e9f7ef;color:#17663a;border:1px solid #b8e3c9}.profile-alert.error{background:#fff0ef;color:#922d28;border:1px solid #f0c4c0}
        .profile-summary{display:flex;align-items:center;gap:15px;margin-bottom:22px}.profile-avatar{width:58px;height:58px;flex:0 0 58px;border-radius:16px;background:var(--navy,#16213b);color:#fff;display:grid;place-items:center;font-size:25px;font-weight:700}.profile-summary h3{margin:0 0 4px;font-size:18px}.profile-summary p{margin:0;color:var(--muted,#687083);font-size:13px;overflow-wrap:anywhere}
        .profile-meta{display:grid;gap:0}.profile-meta-row{display:flex;justify-content:space-between;gap:16px;padding:13px 0;border-bottom:1px solid #e8eaf0;font-size:14px}.profile-meta-row:last-child{border-bottom:0}.profile-meta-row span:first-child{color:var(--muted,#687083)}.profile-meta-row span:last-child{text-align:right;font-weight:600;overflow-wrap:anywhere}
        .profile-security{margin-top:20px}.profile-security-note{font-size:13px;color:var(--muted,#687083);line-height:1.5;margin-top:14px}
        @media(max-width:900px){.profile-grid{grid-template-columns:1fr}.profile-card{padding:18px}}
    </style>
</head>
<body>
<div class="shell">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <main class="main">
        <header class="topbar"><div class="crumb">CO–PO Workspace / <b>My Profile</b></div><div class="topbar-spacer"></div><a class="term-pill" href="logout.php">Logout</a></header>
        <div class="content">
            <div class="page-head"><div><h1>My profile</h1><p>Manage your account details and password.</p></div></div>
            <?php if ($success !== ''): ?><div class="profile-alert success" role="status"><?= profile_h($success) ?></div><?php endif; ?>
            <?php if ($error !== ''): ?><div class="profile-alert error" role="alert"><?= profile_h($error) ?></div><?php endif; ?>

            <div class="profile-grid">
                <section class="card profile-card">
                    <h2>Account details</h2><p class="intro">Changes are saved to your account in the database.</p>
                    <form method="post" class="profile-form" autocomplete="on">
                        <input type="hidden" name="csrf_token" value="<?= profile_h($csrf) ?>">
                        <input type="hidden" name="action" value="update_profile">
                        <div class="profile-field"><label for="full_name">Full name</label><input class="control" id="full_name" name="full_name" type="text" maxlength="150" required value="<?= profile_h($profile['full_name'] ?? '') ?>"></div>
                        <div class="profile-field"><label for="email">Email address</label><input class="control" id="email" name="email" type="email" maxlength="190" required value="<?= profile_h($profile['email'] ?? '') ?>"></div>
                        <div class="profile-field"><label for="department">Department</label><input class="control" id="department" name="department" type="text" maxlength="150" required value="<?= profile_h($profile['department'] ?? '') ?>"></div>
                        <div class="profile-field"><label for="employee_id">Employee ID <span class="muted">(optional)</span></label><input class="control" id="employee_id" name="employee_id" type="text" maxlength="80" value="<?= profile_h($profile['employee_id'] ?? '') ?>"></div>
                        <div class="profile-actions"><button class="btn btn-primary" type="submit">Save profile</button></div>
                    </form>
                </section>

                <div>
                    <section class="card profile-card">
                        <h2>Account overview</h2><p class="intro">Your current account information.</p>
                        <div class="profile-summary"><div class="profile-avatar" aria-hidden="true"><?= profile_h(strtoupper(mb_substr((string)($profile['full_name'] ?? 'U'), 0, 1))) ?></div><div><h3><?= profile_h($profile['full_name'] ?? 'User') ?></h3><p><?= profile_h($profile['email'] ?? '') ?></p></div></div>
                        <div class="profile-meta">
                            <div class="profile-meta-row"><span>Role</span><span><?= profile_h($roleLabel ?: 'Not set') ?></span></div>
                            <div class="profile-meta-row"><span>Department</span><span><?= profile_h($profile['department'] ?? 'Not set') ?></span></div>
                            <div class="profile-meta-row"><span>Employee ID</span><span><?= profile_h(($profile['employee_id'] ?? '') !== '' ? $profile['employee_id'] : 'Not set') ?></span></div>
                            <div class="profile-meta-row"><span>Account created</span><span><?= !empty($profile['created_at']) ? profile_h(date('d M Y', strtotime($profile['created_at']))) : 'Not available' ?></span></div>
                        </div>
                    </section>

                    <section class="card profile-card profile-security">
                        <h2>Change password</h2><p class="intro">Confirm your current password before choosing a new one.</p>
                        <form method="post" class="profile-form" autocomplete="off">
                            <input type="hidden" name="csrf_token" value="<?= profile_h($csrf) ?>">
                            <input type="hidden" name="action" value="change_password">
                            <div class="profile-field"><label for="current_password">Current password</label><input class="control" id="current_password" name="current_password" type="password" autocomplete="current-password" required></div>
                            <div class="profile-field"><label for="new_password">New password</label><input class="control" id="new_password" name="new_password" type="password" minlength="8" autocomplete="new-password" required><small class="muted">Use at least 8 characters.</small></div>
                            <div class="profile-field"><label for="confirm_password">Confirm new password</label><input class="control" id="confirm_password" name="confirm_password" type="password" minlength="8" autocomplete="new-password" required></div>
                            <div class="profile-actions"><button class="btn btn-primary" type="submit">Update password</button></div>
                        </form>
                        <p class="profile-security-note">Your password is stored as a secure password hash. Never share your password with anyone.</p>
                    </section>
                </div>
            </div>
        </div>
    </main>
</div>
</body>
</html>
