<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('classes.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$msg = ''; $error = ''; $importReport = null;
$sessions = $conn->query('SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
[$loginSessionId] = session_selected($conn);
$sessionId = filter_input(INPUT_GET, 'session_id', FILTER_VALIDATE_INT) ?: $loginSessionId;
$departments = scope_departments($conn);
$canManage = role_is('principal', 'hod');           // assign class incharges
$isClassIncharge = role_is('class_incharge');

/* ---- current class selection (department + semester + section) ---- */
$assigned = $isClassIncharge ? scope_class_rows($conn, $sessionId) : [];
$deptId   = filter_input(INPUT_GET, 'dept', FILTER_VALIDATE_INT) ?: 0;
$semester = filter_input(INPUT_GET, 'semester', FILTER_VALIDATE_INT) ?: 0;
$section  = trim((string)($_GET['section'] ?? ''));
if ($isClassIncharge && $assigned && !$deptId) {
    $deptId = (int)$assigned[0]['department_id']; $semester = (int)$assigned[0]['semester']; $section = (string)$assigned[0]['section'];
}
if (!$deptId && $departments) $deptId = (int)$departments[0]['id'];
if ($semester < 1 || $semester > 8) $semester = 1;
if ($section === '') $section = 'A';

/** May the signed-in user work with this exact class? */
function cls_allowed(mysqli $conn, int $sessionId, int $deptId, int $semester, string $section): bool {
    if (role_is('principal')) return true;
    if (role_is('hod')) return $deptId === user_department_id($conn);
    if (role_is('class_incharge')) {
        foreach (scope_class_rows($conn, $sessionId) as $r) {
            if ((int)$r['department_id'] === $deptId && (int)$r['semester'] === $semester && (string)$r['section'] === $section) return true;
        }
    }
    return false;
}

/* ================================================================ POST actions */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    try {
        $action = (string)($_POST['action'] ?? '');
        $sessionId = (int)($_POST['session_id'] ?? $sessionId);
        $deptId    = (int)($_POST['dept'] ?? $deptId);
        $semester  = max(1, min(8, (int)($_POST['semester'] ?? $semester)));
        $section   = trim((string)($_POST['section'] ?? $section)); if ($section === '') $section = 'A';
        if (mb_strlen($section) > 30) throw new RuntimeException('Section name is too long.');

        if ($action === 'assign') {
            if (!$canManage) throw new RuntimeException('Only the HOD or Principal can assign class incharges.');
            if (!cls_allowed($conn, $sessionId, $deptId, $semester, $section)) throw new RuntimeException('You cannot manage this department.');
            $uid = (int)($_POST['user_id'] ?? 0);
            $stmt = $conn->prepare("SELECT id FROM users WHERE id=? AND role='class_incharge' AND active=1 AND (department_id=? OR department_id IS NULL)");
            $stmt->bind_param('ii', $uid, $deptId); $stmt->execute();
            if (!$stmt->get_result()->fetch_assoc()) throw new RuntimeException('Choose an active class-incharge account from this department.');
            $stmt->close();
            $stmt = $conn->prepare('INSERT INTO class_assignments(user_id, academic_session_id, department_id, semester, section) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id)');
            $stmt->bind_param('iiiis', $uid, $sessionId, $deptId, $semester, $section); $stmt->execute(); $stmt->close();
            audit_write($conn, 'class.assign', 'class', null, ['user_id' => $uid, 'dept' => $deptId, 'semester' => $semester, 'section' => $section]);
            $msg = "Class incharge assigned to Semester {$semester}, Section {$section}.";
        } elseif ($action === 'unassign') {
            if (!$canManage) throw new RuntimeException('Only the HOD or Principal can change class assignments.');
            $aid = (int)($_POST['assignment_id'] ?? 0);
            $stmt = $conn->prepare('SELECT department_id FROM class_assignments WHERE id=?'); $stmt->bind_param('i', $aid); $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$row || (!role_is('principal') && (int)$row['department_id'] !== user_department_id($conn))) throw new RuntimeException('Assignment not found.');
            $stmt = $conn->prepare('DELETE FROM class_assignments WHERE id=?'); $stmt->bind_param('i', $aid); $stmt->execute(); $stmt->close();
            audit_write($conn, 'class.unassign', 'class_assignment', $aid);
            $msg = 'Class assignment removed.';
        } elseif ($action === 'import_csv') {
            if (!cls_allowed($conn, $sessionId, $deptId, $semester, $section)) throw new RuntimeException('You can only upload students into a class assigned to you.');
            $f = $_FILES['csv'] ?? null;
            if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Choose a CSV file to upload.');
            if ((int)$f['size'] > 2 * 1024 * 1024) throw new RuntimeException('The file is larger than 2 MB.');
            if (strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION)) !== 'csv') throw new RuntimeException('Only .csv files are accepted. In Excel use File → Save As → CSV.');
            if (!is_uploaded_file($f['tmp_name'])) throw new RuntimeException('Upload failed. Please try again.');
            $fh = fopen($f['tmp_name'], 'r');
            if (!$fh) throw new RuntimeException('Could not read the uploaded file.');
            $header = fgetcsv($fh);
            if (!$header) throw new RuntimeException('The file is empty.');
            $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string)$header[0]);       // strip Excel BOM
            $map = [];
            $alias = ['enrollment_no' => ['enrollment_no', 'enrollment no', 'enrollment', 'roll_no', 'roll no', 'enrollmentno'],
                      'full_name' => ['full_name', 'full name', 'name', 'student name'], 'email' => ['email', 'email id', 'e-mail'],
                      'mobile' => ['mobile', 'phone', 'mobile no', 'contact'], 'gender' => ['gender', 'sex']];
            foreach ($header as $i => $col) {
                $c = strtolower(trim((string)$col));
                foreach ($alias as $key => $names) if (in_array($c, $names, true)) $map[$key] = $i;
            }
            if (!isset($map['enrollment_no'], $map['full_name'])) throw new RuntimeException('The first row must contain the columns: enrollment_no, full_name (optional: email, mobile, gender).');

            $conn->begin_transaction();
            $findStudent = $conn->prepare('SELECT id, department_id FROM students WHERE enrollment_no=?');
            $insStudent  = $conn->prepare('INSERT INTO students(enrollment_no, full_name, email, mobile, gender, department_id) VALUES (?,?,?,?,?,?)');
            $updStudent  = $conn->prepare('UPDATE students SET full_name=?, email=?, mobile=?, gender=COALESCE(?,gender) WHERE id=?');
            $findEnroll  = $conn->prepare('SELECT id FROM student_enrollments WHERE student_id=? AND academic_session_id=? AND semester=?');
            $insEnroll   = $conn->prepare("INSERT INTO student_enrollments(student_id, academic_session_id, semester, section, status) VALUES (?,?,?,?,'active')");
            $updEnroll   = $conn->prepare("UPDATE student_enrollments SET section=?, status='active' WHERE id=?");
            $added = 0; $updated = 0; $skipped = []; $line = 1; $genders = ['male' => 'Male', 'female' => 'Female', 'other' => 'Other', 'prefer not to say' => 'Prefer not to say'];
            while (($row = fgetcsv($fh)) !== false) {
                $line++;
                if ($line > 2001) { $skipped[] = 'Stopped at 2000 rows; split larger files.'; break; }
                if (count(array_filter($row, fn($v) => trim((string)$v) !== '')) === 0) continue;
                $enr = trim((string)($row[$map['enrollment_no']] ?? '')); $name = trim((string)($row[$map['full_name']] ?? ''));
                $email = isset($map['email']) ? trim((string)($row[$map['email']] ?? '')) : '';
                $mobile = isset($map['mobile']) ? trim((string)($row[$map['mobile']] ?? '')) : '';
                $g = isset($map['gender']) ? ($genders[strtolower(trim((string)($row[$map['gender']] ?? '')))] ?? null) : null;
                if ($enr === '' || $name === '') { $skipped[] = "Row {$line}: enrollment number and name are required."; continue; }
                if (mb_strlen($enr) > 80 || mb_strlen($name) > 150) { $skipped[] = "Row {$line}: value too long."; continue; }
                if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) { $skipped[] = "Row {$line} ({$enr}): invalid email."; continue; }
                $emailDb = $email === '' ? null : $email; $mobileDb = $mobile === '' ? null : mb_substr($mobile, 0, 30);
                $findStudent->bind_param('s', $enr); $findStudent->execute();
                $st = $findStudent->get_result()->fetch_assoc();
                if ($st) {
                    if ($st['department_id'] !== null && (int)$st['department_id'] !== $deptId) { $skipped[] = "Row {$line} ({$enr}): belongs to another department."; continue; }
                    $sid = (int)$st['id'];
                    $updStudent->bind_param('ssssi', $name, $emailDb, $mobileDb, $g, $sid); $updStudent->execute();
                    $updated++;
                } else {
                    $insStudent->bind_param('sssssi', $enr, $name, $emailDb, $mobileDb, $g, $deptId); $insStudent->execute();
                    $sid = (int)$conn->insert_id; $added++;
                }
                $findEnroll->bind_param('iii', $sid, $sessionId, $semester); $findEnroll->execute();
                $en = $findEnroll->get_result()->fetch_assoc();
                if ($en) { $eid = (int)$en['id']; $updEnroll->bind_param('si', $section, $eid); $updEnroll->execute(); }
                else { $insEnroll->bind_param('iiis', $sid, $sessionId, $semester, $section); $insEnroll->execute(); }
            }
            fclose($fh);
            $conn->commit();
            audit_write($conn, 'students.import_csv', 'class', null, ['added' => $added, 'updated' => $updated, 'skipped' => count($skipped), 'dept' => $deptId, 'semester' => $semester, 'section' => $section]);
            $importReport = ['added' => $added, 'updated' => $updated, 'skipped' => $skipped];
            $msg = "Import finished: {$added} added, {$updated} updated, " . count($skipped) . ' skipped.';
        }
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $e2) {}
        $error = $e instanceof RuntimeException ? $e->getMessage() : 'Could not complete the request. Run the database upgrade (migrate.php) if you have not yet.';
    }
}

/* ================================================================ data for display */
$classOptionsTable = true;
try {
    $assignSql = "SELECT ca.id, ca.department_id, ca.semester, ca.section, d.name AS department, u.full_name AS incharge, u.email,
                    (SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id=se.student_id
                       WHERE se.academic_session_id=ca.academic_session_id AND st.department_id=ca.department_id AND se.semester=ca.semester AND se.section=ca.section AND se.status='active') AS students
                  FROM class_assignments ca JOIN users u ON u.id=ca.user_id JOIN departments d ON d.id=ca.department_id
                  WHERE ca.academic_session_id=?";
    if (role_is('hod')) $assignSql .= ' AND ca.department_id=' . (int)user_department_id($conn);
    if ($isClassIncharge) $assignSql .= ' AND ca.user_id=' . (int)user_id_int();
    $assignSql .= ' ORDER BY d.name, ca.semester, ca.section';
    $stmt = $conn->prepare($assignSql); $stmt->bind_param('i', $sessionId); $stmt->execute();
    $assignments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
} catch (Throwable $e) { $assignments = []; $classOptionsTable = false; $error = $error ?: 'Class assignments are not set up yet. Run the database upgrade (migrate.php).'; }

$inchargeUsers = [];
if ($canManage && $classOptionsTable) {
    $sql = "SELECT id, full_name, email FROM users WHERE role='class_incharge' AND active=1";
    if (role_is('hod')) $sql .= ' AND (department_id=' . (int)user_department_id($conn) . ' OR department_id IS NULL)';
    $inchargeUsers = $conn->query($sql . ' ORDER BY full_name')->fetch_all(MYSQLI_ASSOC);
}

// classes that actually have students (overview)
$scopeSt = scope_student_clause($conn, $sessionId);
$stmt = $conn->prepare("SELECT st.department_id, d.name AS department, se.semester, se.section, COUNT(*) AS students
    FROM student_enrollments se JOIN students st ON st.id=se.student_id LEFT JOIN departments d ON d.id=st.department_id
    WHERE se.academic_session_id=? AND se.status='active'" . $scopeSt . ' GROUP BY st.department_id, se.semester, se.section ORDER BY d.name, se.semester, se.section');
$stmt->bind_param('i', $sessionId); $stmt->execute();
$overview = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

// student database + class performance for the selected class
$classOk = cls_allowed($conn, $sessionId, $deptId, $semester, $section);
$roster = [];
if ($classOk) {
    $stmt = $conn->prepare("SELECT st.enrollment_no, st.full_name, st.email, st.mobile, st.gender,
            COALESCE(SUM(m.marks_obtained),0) AS got, COALESCE(SUM(ac.max_marks),0) AS maxm, COUNT(m.id) AS entries
        FROM student_enrollments se JOIN students st ON st.id=se.student_id
        LEFT JOIN marks m ON m.enrollment_id=se.id LEFT JOIN assessment_components ac ON ac.id=m.assessment_component_id
        WHERE se.academic_session_id=? AND st.department_id=? AND se.semester=? AND se.section=? AND se.status='active'
        GROUP BY se.id ORDER BY st.enrollment_no");
    $stmt->bind_param('iiis', $sessionId, $deptId, $semester, $section); $stmt->execute();
    $roster = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
}
$deptName = ''; foreach ($departments as $d) if ((int)$d['id'] === $deptId) $deptName = $d['name'];
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Classes & Sections — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Classes & Sections'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow"><?= $isClassIncharge ? 'CLASS LEVEL' : 'CLASS MANAGEMENT' ?></div><h1>Classes &amp; Sections</h1><p>Manage class sections, upload student lists, and review class performance<?= $isClassIncharge ? ' for the classes assigned to you' : '' ?>.</p></div></div>
<?php ui_notice($msg, 'ok'); ui_notice($error, 'err'); ?>

<div class="card"><div class="card-head"><div><h2>Select class</h2><span><?= $isClassIncharge ? 'Only your assigned classes are available' : 'Department, semester and section' ?></span></div></div>
<form method="get" class="panel-body"><div class="form-row tight">
<div class="field"><label>Session</label><select class="control" name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $sessionId === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['session_name']) ?></option><?php endforeach; ?></select></div>
<div class="field"><label>Department</label><select class="control" name="dept"><?php foreach ($departments as $d): ?><option value="<?= (int)$d['id'] ?>" <?= $deptId === (int)$d['id'] ? 'selected' : '' ?>><?= h($d['name']) ?></option><?php endforeach; ?></select></div>
<div class="field"><label>Semester</label><select class="control" name="semester"><?php for ($i = 1; $i <= 8; $i++): ?><option value="<?= $i ?>" <?= $semester === $i ? 'selected' : '' ?>>Semester <?= $i ?></option><?php endfor; ?></select></div>
<div class="field"><label>Section</label><input class="control" name="section" maxlength="30" value="<?= h($section) ?>"></div>
<div class="field"><button class="btn btn-primary" type="submit">Open class</button></div>
</div></form></div>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Class assignments</h2><span>Who is the class incharge of each section this session</span></div><span class="badge grey"><?= count($assignments) ?> assigned</span></div>
<?php if ($canManage && $classOptionsTable): ?>
<form method="post" class="panel-body" style="border-bottom:1px solid var(--line2)"><?= csrf_field() ?><input type="hidden" name="action" value="assign"><input type="hidden" name="session_id" value="<?= (int)$sessionId ?>"><input type="hidden" name="dept" value="<?= (int)$deptId ?>">
<div class="form-row tight"><div class="field"><label>Class incharge</label><select class="control" name="user_id" required><option value="">Select account</option><?php foreach ($inchargeUsers as $u): ?><option value="<?= (int)$u['id'] ?>"><?= h($u['full_name'] . ' — ' . $u['email']) ?></option><?php endforeach; ?></select></div>
<div class="field"><label>Semester</label><select class="control" name="semester"><?php for ($i = 1; $i <= 8; $i++): ?><option value="<?= $i ?>" <?= $semester === $i ? 'selected' : '' ?>>Semester <?= $i ?></option><?php endfor; ?></select></div>
<div class="field"><label>Section</label><input class="control" name="section" maxlength="30" value="<?= h($section) ?>" required></div>
<div class="field"><button class="btn btn-gold" type="submit">Assign to <?= h($deptName ?: 'department') ?></button></div></div>
<?php if (!$inchargeUsers): ?><p class="hint">No class-incharge accounts yet. Create one under Faculty &amp; Access.</p><?php endif; ?></form>
<?php endif; ?>
<div class="table-wrap"><table class="data"><thead><tr><th>Department</th><th>Semester</th><th>Section</th><th>Class incharge</th><th class="num">Students</th><th></th></tr></thead><tbody>
<?php if (!$assignments): ?><tr><td colspan="6"><div class="muted-empty"><?= $isClassIncharge ? 'No class is assigned to you for this session yet. Ask your HOD.' : 'No class assignments for this session yet.' ?></div></td></tr><?php endif; ?>
<?php foreach ($assignments as $a): ?><tr><td><?= h($a['department']) ?></td><td>Semester <?= (int)$a['semester'] ?></td><td><?= h($a['section']) ?></td><td><b><?= h($a['incharge']) ?></b><div class="stu-id"><?= h($a['email']) ?></div></td><td class="num"><?= (int)$a['students'] ?></td>
<td style="white-space:nowrap"><a class="btn btn-outline btn-sm" href="classes.php?session_id=<?= (int)$sessionId ?>&dept=<?= (int)$a['department_id'] ?>&semester=<?= (int)$a['semester'] ?>&section=<?= urlencode($a['section']) ?>">Open</a>
<?php if ($canManage): ?><form method="post" class="inline-form" onsubmit="return confirm('Remove this class assignment?')"><?= csrf_field() ?><input type="hidden" name="action" value="unassign"><input type="hidden" name="assignment_id" value="<?= (int)$a['id'] ?>"><input type="hidden" name="session_id" value="<?= (int)$sessionId ?>"><button class="btn btn-danger btn-sm" type="submit">Remove</button></form><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>

<?php if ($classOk): ?>
<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Upload students (CSV)</h2><span><?= h($deptName) ?> · Semester <?= (int)$semester ?> · Section <?= h($section) ?></span></div></div>
<form method="post" enctype="multipart/form-data" class="panel-body"><?= csrf_field() ?><input type="hidden" name="action" value="import_csv"><input type="hidden" name="session_id" value="<?= (int)$sessionId ?>"><input type="hidden" name="dept" value="<?= (int)$deptId ?>"><input type="hidden" name="semester" value="<?= (int)$semester ?>"><input type="hidden" name="section" value="<?= h($section) ?>">
<div class="form-row"><div class="field"><label>CSV file (max 2 MB, up to 2000 rows)</label><input class="control" type="file" name="csv" accept=".csv,text/csv" required style="padding-top:7px"></div><div class="field"><button class="btn btn-gold" type="submit">Upload &amp; enrol</button></div></div>
<p class="hint">First row must be the header: <code>enrollment_no, full_name</code> and optionally <code>email, mobile, gender</code>. Existing enrollment numbers are updated, new ones are added and enrolled in this class. Students belonging to another department are skipped. In Excel use File → Save As → CSV.</p></form>
<?php if ($importReport && $importReport['skipped']): ?><div class="help-text"><strong>Skipped rows:</strong><br><?= implode('<br>', array_map('h', array_slice($importReport['skipped'], 0, 50))) ?></div><?php endif; ?></div>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Student database &amp; class performance</h2><span>Overall marks percentage across every recorded assessment</span></div><span class="badge grey"><?= count($roster) ?> students</span></div>
<div class="table-wrap"><table class="data"><thead><tr><th>#</th><th>Enrollment no.</th><th>Student</th><th>Email</th><th>Gender</th><th class="num">Entries</th><th class="num">Overall %</th></tr></thead><tbody>
<?php if (!$roster): ?><tr><td colspan="7"><div class="muted-empty">No students in this class yet. Upload a CSV above or add students on the Students page.</div></td></tr><?php endif; ?>
<?php foreach ($roster as $i => $r): $maxm = (float)$r['maxm']; $pct = $maxm > 0 ? round((float)$r['got'] / $maxm * 100, 1) : null; ?>
<tr><td class="row-index"><?= $i + 1 ?></td><td><?= h($r['enrollment_no']) ?></td><td><b><?= h($r['full_name']) ?></b></td><td><?= h($r['email'] ?? '—') ?></td><td><?= h($r['gender'] ?? '—') ?></td><td class="num"><?= (int)$r['entries'] ?></td>
<td class="num"><?= $pct === null ? '<span class="badge grey">No marks</span>' : '<span class="badge ' . ($pct >= 60 ? 'green' : ($pct >= 40 ? 'gold' : 'rust')) . '">' . number_format($pct, 1) . '%</span>' ?></td></tr>
<?php endforeach; ?></tbody></table></div></div>
<?php endif; ?>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Classes with students</h2><span>This session, within your access</span></div></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Department</th><th>Semester</th><th>Section</th><th class="num">Students</th><th></th></tr></thead><tbody>
<?php if (!$overview): ?><tr><td colspan="5"><div class="muted-empty">No enrolled students yet.</div></td></tr><?php endif; ?>
<?php foreach ($overview as $o): ?><tr><td><?= h($o['department'] ?? '—') ?></td><td>Semester <?= (int)$o['semester'] ?></td><td><?= h($o['section']) ?></td><td class="num"><?= (int)$o['students'] ?></td><td><?php if ($o['department_id'] !== null): ?><a class="btn btn-outline btn-sm" href="classes.php?session_id=<?= (int)$sessionId ?>&dept=<?= (int)$o['department_id'] ?>&semester=<?= (int)$o['semester'] ?>&section=<?= urlencode($o['section']) ?>">Open</a><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
</section></div></main></div></body></html>
