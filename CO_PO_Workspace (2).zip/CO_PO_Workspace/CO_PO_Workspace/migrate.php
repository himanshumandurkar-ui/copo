<?php
/*
 * One-click, repeatable database upgrade for installs created from the ORIGINAL database.sql.
 * - Never drops or rewrites existing data (workflow rule: "maintains history, no data loss").
 * - Safe to run more than once: every step first checks information_schema.
 * - Works on both MySQL and MariaDB (no "ADD COLUMN IF NOT EXISTS" syntax needed).
 * Fresh installs do not need this file: import the updated database.sql instead.
 */
require_once __DIR__ . '/includes/auth.php';
require_page_access('migrate.php');           // principal only (see includes/auth.php)
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$log = [];
$ran = false;

function m_col_exists(mysqli $c, string $table, string $col): bool {
    $s = $c->prepare('SELECT COUNT(*) n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?');
    $s->bind_param('ss', $table, $col); $s->execute();
    $n = (int)$s->get_result()->fetch_assoc()['n']; $s->close();
    return $n > 0;
}
function m_table_exists(mysqli $c, string $table): bool {
    $s = $c->prepare('SELECT COUNT(*) n FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');
    $s->bind_param('s', $table); $s->execute();
    $n = (int)$s->get_result()->fetch_assoc()['n']; $s->close();
    return $n > 0;
}
function m_fk_exists(mysqli $c, string $table, string $name): bool {
    $s = $c->prepare("SELECT COUNT(*) n FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND CONSTRAINT_NAME=? AND CONSTRAINT_TYPE='FOREIGN KEY'");
    $s->bind_param('ss', $table, $name); $s->execute();
    $n = (int)$s->get_result()->fetch_assoc()['n']; $s->close();
    return $n > 0;
}

/** Each step: [label, check-callable returning true when ALREADY applied, apply-callable]. */
$steps = [
    ['users.department_id column',
        fn() => m_col_exists($conn, 'users', 'department_id'),
        fn() => $conn->query('ALTER TABLE users ADD COLUMN department_id BIGINT UNSIGNED NULL AFTER department')],
    ['Register every department named on a user account',
        fn() => false,
        fn() => $conn->query("INSERT IGNORE INTO departments(name) SELECT DISTINCT department FROM users WHERE department <> ''")],
    ['Link users to departments (department_id)',
        fn() => false,
        fn() => $conn->query('UPDATE users u JOIN departments d ON d.name=u.department SET u.department_id=d.id WHERE u.department_id IS NULL')],
    ['users → departments foreign key',
        fn() => m_fk_exists($conn, 'users', 'fk_user_department'),
        fn() => $conn->query('ALTER TABLE users ADD CONSTRAINT fk_user_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL')],
    ['attainment_results.level_value column',
        fn() => m_col_exists($conn, 'attainment_results', 'level_value'),
        fn() => $conn->query('ALTER TABLE attainment_results ADD COLUMN level_value DECIMAL(4,2) NULL AFTER attainment_percent')],
    ['attainment_results.students_total column',
        fn() => m_col_exists($conn, 'attainment_results', 'students_total'),
        fn() => $conn->query('ALTER TABLE attainment_results ADD COLUMN students_total INT UNSIGNED NULL AFTER level_value')],
    ['attainment_results.students_attained column',
        fn() => m_col_exists($conn, 'attainment_results', 'students_attained'),
        fn() => $conn->query('ALTER TABLE attainment_results ADD COLUMN students_attained INT UNSIGNED NULL AFTER students_total')],
    ['program_outcomes table',
        fn() => m_table_exists($conn, 'program_outcomes'),
        fn() => $conn->query("CREATE TABLE program_outcomes (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            department_id BIGINT UNSIGNED NOT NULL,
            po_number TINYINT UNSIGNED NOT NULL,
            title VARCHAR(150) NOT NULL,
            description TEXT NULL,
            updated_by BIGINT UNSIGNED NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_po_dept(department_id,po_number),
            CONSTRAINT fk_po_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE CASCADE,
            CONSTRAINT fk_po_user FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL,
            CONSTRAINT chk_po_no CHECK(po_number BETWEEN 1 AND 12)
        ) ENGINE=InnoDB")],
    ['class_assignments table',
        fn() => m_table_exists($conn, 'class_assignments'),
        fn() => $conn->query("CREATE TABLE class_assignments (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            academic_session_id BIGINT UNSIGNED NOT NULL,
            department_id BIGINT UNSIGNED NOT NULL,
            semester TINYINT UNSIGNED NOT NULL,
            section VARCHAR(30) NOT NULL DEFAULT 'A',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_class(academic_session_id,department_id,semester,section),
            CONSTRAINT fk_class_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_class_session FOREIGN KEY(academic_session_id) REFERENCES academic_sessions(id),
            CONSTRAINT fk_class_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE CASCADE
        ) ENGINE=InnoDB")],
    ['attainment_settings table',
        fn() => m_table_exists($conn, 'attainment_settings'),
        fn() => $conn->query("CREATE TABLE attainment_settings (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            department_id BIGINT UNSIGNED NULL,
            target_percent DECIMAL(5,2) NOT NULL DEFAULT 60,
            level3_min DECIMAL(5,2) NOT NULL DEFAULT 70,
            level2_min DECIMAL(5,2) NOT NULL DEFAULT 60,
            level1_min DECIMAL(5,2) NOT NULL DEFAULT 50,
            co_target_level DECIMAL(3,2) NOT NULL DEFAULT 2.00,
            po_target_level DECIMAL(3,2) NOT NULL DEFAULT 2.00,
            updated_by BIGINT UNSIGNED NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_settings_dept(department_id),
            CONSTRAINT fk_settings_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE CASCADE
        ) ENGINE=InnoDB")],
    ['Default (college-wide) attainment rule row',
        fn() => m_table_exists($conn, 'attainment_settings')
                && (int)$conn->query('SELECT COUNT(*) n FROM attainment_settings WHERE department_id IS NULL')->fetch_assoc()['n'] > 0,
        fn() => $conn->query('INSERT INTO attainment_settings(department_id) VALUES (NULL)')],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    $ran = true;
    foreach ($steps as [$label, $isDone, $apply]) {
        try {
            if ($isDone()) { $log[] = ['skip', $label, 'already in place']; continue; }
            $apply();
            $log[] = ['ok', $label, 'applied'];
        } catch (Throwable $e) {
            $log[] = ['fail', $label, $e->getMessage()];
            break;   // stop at the first failure so nothing is left half-applied silently
        }
    }
}
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Database upgrade — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css">
<style>.log{font:12.5px/1.7 Inter,Arial,sans-serif;padding:6px 20px 18px}.log div{border-bottom:1px solid var(--line2);padding:7px 0;display:flex;gap:10px}.log b{min-width:46px}.log .ok b{color:var(--green)}.log .skip b{color:#8b96a7}.log .fail b{color:var(--red)}</style>
</head><body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Database upgrade'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow">ADMINISTRATION</div><h1>Database upgrade</h1>
<p>Adds the tables and columns the full workflow needs (program outcomes, class assignments, attainment rules, department links). Existing records are never deleted or changed beyond linking users to their department. Safe to run repeatedly.</p></div></div>
<div class="card"><div class="card-head"><div><h2>Upgrade steps</h2><span><?= count($steps) ?> checks</span></div></div>
<?php if ($ran): ?>
  <div class="log"><?php foreach ($log as [$state, $label, $note]): ?><div class="<?= h($state) ?>"><b><?= h(strtoupper($state)) ?></b><span><?= h($label) ?> — <?= h($note) ?></span></div><?php endforeach; ?></div>
<?php else: ?>
  <div class="panel-body"><p class="muted">Back up your database first (phpMyAdmin → Export). Then run the upgrade.</p>
  <form method="post"><?= csrf_field() ?><button class="btn btn-gold" type="submit">Run database upgrade</button></form></div>
<?php endif; ?>
</div></section></div></main></div></body></html>
