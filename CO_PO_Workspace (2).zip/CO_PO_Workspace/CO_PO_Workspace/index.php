<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

// Create the CSRF token used by login_action.php.
if (empty($_SESSION['login_csrf_token'])) {
    $_SESSION['login_csrf_token'] = bin2hex(random_bytes(32));
}
if (current_user()) { header('Location: dashboard.php'); exit; }
$error = trim($_GET['error'] ?? '');

// Academic sessions offered on the sign-in form (active session first).
$loginSessions = [];
try {
    $loginSessions = db()->query('SELECT session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {
    error_log('index.php sessions: ' . $e->getMessage());
}

?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in — CO–PO Workspace</title>
<style>
@font-face{ font-family:'Lora'; src: local('Lora'); font-weight:400 700; }
:root{
  --ink:#1B2A44; --ink-2:#4B5568; --ink-3:#8891A0; --paper:#F3F4F0;
  --card:#FFFFFF; --line:#DEE1E2; --gold:#B9852E; --gold-deep:#8C6420; --rust:#B24632;
  --radius-s:3px;
}
*{ box-sizing:border-box; }
html,body{ margin:0; padding:0; }
body{
  background:var(--paper); color:var(--ink);
  font-family:'Liberation Sans', Arial, sans-serif; font-size:13.5px;
  -webkit-font-smoothing:antialiased;
  min-height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center;
  position:relative;
}
h1{ margin:0; font-family:'Lora', Georgia, serif; font-weight:600; color:var(--ink); }

/* top accent strip */
.strip{ position:fixed; top:0; left:0; right:0; height:5px; background:linear-gradient(90deg, var(--gold) 0%, var(--gold-deep) 100%); }

/* brand row above the card */
.topbrand{ display:flex; align-items:center; gap:10px; margin-bottom:28px; }
.bp-mark{
  width:36px; height:36px; border-radius:9px; flex-shrink:0;
  background:linear-gradient(155deg, var(--gold) 0%, var(--gold-deep) 100%);
  display:flex; align-items:center; justify-content:center;
  font-family:'Lora', serif; font-weight:700; color:#1B2A44; font-size:17px;
}
.topbrand .t1{ font-family:'Lora',serif; font-size:16.5px; font-weight:600; color:var(--ink); }
.topbrand .t2{ font-size:10.8px; color:var(--ink-3); margin-top:1px; }

/* card */
.card{ width:400px; background:var(--card); border:1px solid var(--line); border-radius:8px; padding:36px 36px 28px 36px; }
.card h1{ font-size:20px; text-align:center; }
.card .sub{ font-size:12.5px; color:var(--ink-2); text-align:center; margin-top:6px; }

.field{ margin-top:16px; }
.field label{ display:block; font-size:12px; font-weight:600; color:var(--ink); margin-bottom:6px; }
.control{ width:100%; padding:9px 11px; border:1px solid var(--line); border-radius:var(--radius-s); background:#fff; font-size:13px; color:var(--ink); font-family:'Liberation Sans', Arial, sans-serif; }
select.control{ appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%238891A0'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:30px; }
.control::placeholder{ color:#A6ADBB; }

.field-icon{ position:relative; }
.field-icon input.control{ padding-left:36px; }
.field-icon svg{ position:absolute; left:11px; top:50%; transform:translateY(-50%); width:15px; height:15px; color:var(--ink-3); }

.row-between{ display:flex; align-items:center; justify-content:space-between; margin:14px 0 22px 0; }
.remember{ display:flex; align-items:center; gap:8px; font-size:12.5px; color:var(--ink-2); cursor:pointer; }
.remember input{ width:15px; height:15px; }
.link{ font-size:12.5px; color:var(--gold-deep); font-weight:600; text-decoration:none; }

.btn{ font-family:'Liberation Sans', Arial, sans-serif; font-size:13.5px; font-weight:600; padding:11px; border-radius:var(--radius-s); border:1px solid transparent; cursor:pointer; width:100%; display:flex; align-items:center; justify-content:center; }
.btn-primary{ background:var(--ink); color:#fff; }
.btn-primary:hover{ background:#223457; }

.errbox{ display:none; background:#FAE7E2; border:1px solid #EBC3B8; color:var(--rust); font-size:12px; padding:9px 12px; border-radius:var(--radius-s); margin-top:16px; }
.errbox.show{ display:block; }

.tiny-print{ text-align:center; font-size:11px; color:var(--ink-3); margin-top:22px; }
</style>
</head>
<body>

<div class="strip"></div>

<div class="topbrand">
  <div class="bp-mark">CP</div>
  <div>
   <div class="t1">SSPACE</div>
    <div class="t2">Dept. of Computer Science</div>
  </div>
</div>

<div class="card">
  <h1>Sign in to your account</h1>
  <div class="sub">Enter your credentials to access the attainment workspace</div>

  <form id="loginForm" method="post" action="login_action.php">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['login_csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

    <div class="field">
      <label for="academic_session">Academic session</label>
      <select class="control" id="academic_session" name="academic_session" required>
        <?php if (!$loginSessions): ?>
          <option value="">No academic session found — import database.sql</option>
        <?php else: foreach ($loginSessions as $ls): ?>
          <option value="<?= htmlspecialchars($ls['session_name'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($ls['session_name'], ENT_QUOTES, 'UTF-8') ?><?= (int)$ls['is_active'] === 1 ? ' (Active)' : '' ?></option>
        <?php endforeach; endif; ?>
      </select>
    </div>

    <div class="field">
      <label>Email address</label>
      <div class="field-icon">
        <svg viewBox="0 0 16 16" fill="none"><rect x="1.5" y="3.2" width="13" height="9.6" rx="1.4" stroke="currentColor" stroke-width="1.3"/><path d="M2.2 4l5.8 4.6L13.8 4" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <input class="control" type="email" id="email" name="email" autocomplete="username" required placeholder="you@college.edu">
      </div>
    </div>

    <div class="field">
      <label>Password</label>
      <div class="field-icon">
        <svg viewBox="0 0 16 16" fill="none"><rect x="2.8" y="7" width="10.4" height="7" rx="1.4" stroke="currentColor" stroke-width="1.3"/><path d="M5 7V5a3 3 0 016 0v2" stroke="currentColor" stroke-width="1.3"/></svg>
        <input class="control" type="password" id="password" name="password" autocomplete="current-password" required placeholder="Enter your password">
      </div>
    </div>

    <div class="row-between">
      <label class="remember"><input type="checkbox"> Remember me</label>
      <a class="link" href="#">Forgot password?</a>
    </div>

    <div class="errbox <?php echo $error !== '' ? 'show' : ''; ?>" id="errBox"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>

    <button class="btn btn-primary" type="submit" style="margin-top:18px;">Sign in</button>
  </form>

  <div class="tiny-print">Protected access · Computer Science Engineering department only</div>
</div>


</body>
</html>
