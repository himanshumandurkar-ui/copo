<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('performance.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$user = current_user() ?? [];
$errors = [];
$sessionId = filter_input(INPUT_GET, 'session_id', FILTER_VALIDATE_INT) ?: 0;
$semester = filter_input(INPUT_GET, 'semester', FILTER_VALIDATE_INT) ?: 0;
$subjectId = filter_input(INPUT_GET, 'subject_id', FILTER_VALIDATE_INT) ?: 0;
$target = filter_input(INPUT_GET, 'target', FILTER_VALIDATE_FLOAT);
$target = ($target !== false && $target !== null && $target >= 0 && $target <= 100) ? (float)$target : 60.0;

function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function pct($value): string { return $value === null ? '—' : number_format((float)$value, 1) . '%'; }

$sessions = [];
$result = $conn->query("SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC");
while ($row = $result->fetch_assoc()) $sessions[] = $row;
if (!$sessionId && $sessions) {
    foreach ($sessions as $s) if ((int)$s['is_active'] === 1) { $sessionId = (int)$s['id']; break; }
    if (!$sessionId) $sessionId = (int)$sessions[0]['id'];
}
$semesters = range(1, 8);

$subjects = [];
if ($sessionId && $semester >= 1 && $semester <= 8) {
    $stmt = $conn->prepare('SELECT id, subject_code, subject_name FROM subjects WHERE academic_session_id=? AND semester=?' . scope_subject_clause() . ' ORDER BY subject_code');
    $stmt->bind_param('ii', $sessionId, $semester); $stmt->execute();
    $subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
} elseif ($sessionId) {
    $stmt = $conn->prepare('SELECT id, subject_code, subject_name FROM subjects WHERE academic_session_id=?' . scope_subject_clause() . ' ORDER BY semester, subject_code');
    $stmt->bind_param('i', $sessionId); $stmt->execute();
    $subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
}
if ($subjectId && !array_filter($subjects, fn($s) => (int)$s['id'] === $subjectId)) $subjectId = 0;

$rows = [];
if ($sessionId) {
    $sql = "SELECT st.id AS student_id, st.enrollment_no, st.full_name,
        AVG(CASE WHEN ac.component_type='sessional' AND ac.max_marks>0 THEN LEAST(100, GREATEST(0, m.marks_obtained/ac.max_marks*100)) END) AS sessional_pct,
        AVG(CASE WHEN ac.component_type IN ('other','attendance') AND ac.max_marks>0 THEN LEAST(100, GREATEST(0, m.marks_obtained/ac.max_marks*100)) END) AS internal_pct,
        AVG(CASE WHEN ac.component_type='unit_test' AND ac.max_marks>0 THEN LEAST(100, GREATEST(0, m.marks_obtained/ac.max_marks*100)) END) AS unit_test_pct
      FROM student_enrollments se
      JOIN students st ON st.id=se.student_id
      LEFT JOIN marks m ON m.enrollment_id=se.id
      LEFT JOIN assessment_components ac ON ac.id=m.assessment_component_id
      LEFT JOIN subjects sub ON sub.id=ac.subject_id
      WHERE se.academic_session_id=? AND se.status='active'" . scope_student_clause($conn, (int)$sessionId, 'se', 'st')
        . " AND (sub.id IS NULL OR sub.id IN (SELECT id FROM subjects WHERE 1=1" . scope_subject_clause() . "))";
    $types = 'i'; $params = [$sessionId];
    if ($semester >= 1 && $semester <= 8) { $sql .= ' AND se.semester=?'; $types .= 'i'; $params[] = $semester; }
    if ($subjectId) { $sql .= ' AND sub.id=?'; $types .= 'i'; $params[] = $subjectId; }
    $sql .= ' GROUP BY st.id, st.enrollment_no, st.full_name ORDER BY st.full_name';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute(); $raw = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    foreach ($raw as $r) {
        $parts = array_values(array_filter([$r['sessional_pct'], $r['internal_pct'], $r['unit_test_pct']], fn($v) => $v !== null));
        $r['average_pct'] = $parts ? array_sum(array_map('floatval', $parts)) / count($parts) : null;
        $r['standing'] = $r['average_pct'] === null ? 'No marks' : ((float)$r['average_pct'] < $target ? 'At risk' : 'On target');
        $rows[] = $r;
    }
}

$scored = array_values(array_filter($rows, fn($r) => $r['average_pct'] !== null));
$classAverage = $scored ? array_sum(array_map(fn($r) => (float)$r['average_pct'], $scored)) / count($scored) : null;
$highest = null;
foreach ($scored as $r) if ($highest === null || (float)$r['average_pct'] > (float)$highest['average_pct']) $highest = $r;
$atRisk = count(array_filter($scored, fn($r) => (float)$r['average_pct'] < $target));
$aboveTarget = count(array_filter($scored, fn($r) => (float)$r['average_pct'] >= $target));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>CO–PO Workspace — Student Performance</title>
<link rel="stylesheet" href="css/style.css">
<style>
.performance-filters{display:flex;flex-wrap:wrap;gap:12px;align-items:end;padding:18px}.performance-filters .field{display:flex;flex-direction:column;gap:6px;min-width:150px;flex:1}.performance-filters label{font-size:12px;color:#64708a;font-weight:600}.performance-filters select,.performance-filters input{width:100%;min-height:40px;border:1px solid #d8deea;border-radius:8px;padding:8px 10px;background:#fff;color:#16213b}.performance-filters .btn{min-height:40px;cursor:pointer}.perf-progress{height:7px;min-width:70px;background:#e9edf4;border-radius:99px;overflow:hidden}.perf-progress span{display:block;height:100%;background:#bd882b;border-radius:99px}.standing{display:inline-block;padding:5px 9px;border-radius:99px;font-size:12px;font-weight:700;white-space:nowrap}.standing.good{background:#e5f5ec;color:#176b3a}.standing.risk{background:#fff0e7;color:#9b4215}.standing.none{background:#eef1f6;color:#596579}.muted-note{color:#6b7589;font-size:12px}.stat-card .val.small{font-size:19px;line-height:1.35;overflow-wrap:anywhere}.table-wrap{overflow-x:auto}.data td.num,.data th.num{text-align:right;font-variant-numeric:tabular-nums}@media(max-width:760px){.performance-filters .field{min-width:130px}.page-head{gap:10px;flex-wrap:wrap}}
</style>
</head>
<body>
<div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<header class="topbar"><div class="crumb">CO–PO Workspace / <b>Attainment / Student performance</b></div><div class="topbar-spacer"></div><a class="term-pill" href="profile.php" style="text-decoration:none">Profile</a><a class="term-pill" href="logout.php" style="text-decoration:none">Logout</a></header>
<div class="content"><section class="page active">
<div class="page-head"><div><h1>Student performance</h1><p>Compare student marks by assessment type for the selected session, semester and subject.</p></div></div>
<div class="card" style="margin-bottom:18px"><form method="get" class="performance-filters">
<div class="field"><label for="session_id">Academic session</label><select id="session_id" name="session_id" required><?php foreach($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $sessionId===(int)$s['id']?'selected':'' ?>><?= h($s['session_name']) ?><?= (int)$s['is_active']===1?' (Active)':'' ?></option><?php endforeach; ?></select></div>
<div class="field"><label for="semester">Semester</label><select id="semester" name="semester"><option value="0" <?= $semester===0?'selected':'' ?>>All semesters</option><?php foreach($semesters as $sem): ?><option value="<?= $sem ?>" <?= $semester===$sem?'selected':'' ?>>Semester <?= $sem ?></option><?php endforeach; ?></select></div>
<div class="field"><label for="subject_id">Subject</label><select id="subject_id" name="subject_id"><option value="0">All subjects</option><?php foreach($subjects as $sub): ?><option value="<?= (int)$sub['id'] ?>" <?= $subjectId===(int)$sub['id']?'selected':'' ?>><?= h($sub['subject_code'].' — '.$sub['subject_name']) ?></option><?php endforeach; ?></select></div>
<div class="field"><label for="target">Target percentage</label><input id="target" name="target" type="number" min="0" max="100" step="1" value="<?= h($target) ?>"></div>
<button class="btn btn-primary" type="submit">Apply filters</button>
</form></div>
<div class="stat-row">
<div class="stat-card"><div class="lbl">Class average</div><div class="val"><?= $classAverage===null?'—':number_format($classAverage,1) ?><span class="unit"><?= $classAverage===null?'':'%' ?></span></div><div class="delta">Based on <?= count($scored) ?> students with marks</div></div>
<div class="stat-card"><div class="lbl">Highest average</div><div class="val small"><?= $highest?h($highest['full_name']):'—' ?></div><div class="delta"><?= $highest?pct($highest['average_pct']):'No recorded marks' ?></div></div>
<div class="stat-card"><div class="lbl">Students at risk</div><div class="val"><?= $atRisk ?><span class="unit"> / <?= count($scored) ?></span></div><div class="delta">Below <?= h($target) ?>% target</div></div>
<div class="stat-card"><div class="lbl">At or above target</div><div class="val"><?= $aboveTarget ?><span class="unit"> / <?= count($scored) ?></span></div><div class="delta">Students with recorded marks</div></div>
</div>
<div class="card"><div class="card-head"><div><h2>Semester averages</h2><span>Each assessment category is shown as a percentage of its maximum marks; average uses categories with recorded marks.</span></div></div>
<div class="table-wrap"><table class="data"><thead><tr><th>#</th><th>Enrollment no.</th><th>Student</th><th class="num">Sessional</th><th class="num">Internal*</th><th class="num">Unit test</th><th>Average</th><th>Standing</th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="8" style="text-align:center;padding:28px">No enrolled students found for these filters.</td></tr>
<?php else: $rank=0; foreach($rows as $r): $rank++; $avg=$r['average_pct']; $standingClass=$avg===null?'none':((float)$avg<$target?'risk':'good'); ?>
<tr><td><?= $rank ?></td><td><?= h($r['enrollment_no']) ?></td><td><?= h($r['full_name']) ?></td>
<td class="num"><?= pct($r['sessional_pct']) ?></td><td class="num"><?= pct($r['internal_pct']) ?></td><td class="num"><?= pct($r['unit_test_pct']) ?></td>
<td><?php if($avg===null): ?>—<?php else: ?><div style="display:flex;align-items:center;gap:10px"><strong><?= number_format((float)$avg,1) ?>%</strong><div class="perf-progress"><span style="width:<?= max(0,min(100,(float)$avg)) ?>%"></span></div></div><?php endif; ?></td>
<td><span class="standing <?= $standingClass ?>"><?= h($r['standing']) ?></span></td></tr>
<?php endforeach; endif; ?>
</tbody></table></div><div style="padding:14px 18px" class="muted-note">*Internal currently groups assessment components stored as “Other” or “Attendance”. If your internal assessments use another component type, adjust that mapping to match your college’s setup.</div>
</div>
</section></div></main></div></body></html>
