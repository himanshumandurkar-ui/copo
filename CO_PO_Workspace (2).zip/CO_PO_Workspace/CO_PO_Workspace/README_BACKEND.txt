CO–PO Attainment Monitoring System — complete workflow build
=============================================================
Stack: PHP 8.1+ (uses `never` return type), MySQL 5.7+/8 or MariaDB 10.4+, XAMPP/WAMP/any PHP host.

1) INSTALL (new database)
   - Create a database, import database.sql (phpMyAdmin → Import).
   - Edit config.php (DB_HOST / DB_USER / DB_PASS / DB_NAME).
   - Open setup-admin.php once to create the first Principal account, then DELETE setup-admin.php.
   - Sign in at index.php, add Departments, then create HOD / class / subject incharge accounts under "Faculty & Access".

2) UPGRADE (you already ran the older database.sql)
   - Back up the database first.
   - Copy these files over the old site, sign in as Principal, open  migrate.php  and press "Run database upgrade".
   - It only ADDS tables/columns (program_outcomes, class_assignments, attainment_settings, users.department_id,
     attainment_results level/coverage columns). Nothing is deleted. Safe to run repeatedly.
   - Existing HOD / incharge accounts keep working; check each one is linked to a department under Faculty & Access.

3) WHO CAN DO WHAT  (follows the workflow chart; data is filtered in SQL, not just hidden in the menu)
   Principal (college)      College dashboard, Departments, Faculty & Access, POs (all departments), CO–PO overview,
                            all reports, Analytics, Accreditation (NBA/NAAC support), Database Upgrade.
   HOD (own department)     Manage POs, Faculty & Access (own department's incharges + subject assignment),
                            Classes & Sections (assign class incharges), Student list, Subject list (create subjects),
                            CO–PO mapping REPORT (read-only), CO attainment report, Department reports, Analytics.
   Class incharge           Their assigned class/section only: add students, CSV upload, student database, class performance,
                            class/student reports.
   Subject incharge         Only subjects assigned to them: Course Outcomes (add/edit), assessment marks (sessional, internal,
                            unit tests, assignments/activities, practicals), CO–PO mapping (edit), CO/PO attainment, subject reports.
   Changes versus the old starter: HOD and class incharge no longer enter marks (the chart gives that to the subject
   incharge); only HOD/Principal create subjects; a new HOD/Principal page assigns subject incharges and class incharges.

4) PROCESSING PIPELINE (includes/engine.php, run from "CO/PO Attainment")
   Marks validation (0 <= marks <= max; bad rows excluded and reported) → total/percentage per student per CO →
   CO attainment → CO–PO mapping (0/1/2/3) → PO attainment → saved for reports/analytics.
   Default rule (EDITABLE by HOD/Principal on the same page; stored in attainment_settings):
     * a student attains a CO when their marks for that CO reach 60%
     * CO level 3 if >= 70% of assessed students attain it, level 2 if >= 60%, level 1 if >= 50%, else 0
     * PO level = mapping-weighted average of the linked CO levels (e.g. mappings 3,2,1 on CO levels 3,2,0 → (9+4+0)/6 = 2.17)
     * targets for the "meets target" colours: CO 2.0, PO 2.0
   !! These are common NBA-style defaults, NOT your college's official scheme. Confirm thresholds, weights and targets
      with your accreditation cell before using the numbers in any submission.
   Only students who have marks recorded for a CO are counted; the count (e.g. 28/32) is shown next to each result.
   Recalculating overwrites that subject's results for that session/semester only; other sessions are untouched (history kept).

5) REPORTS & OUTPUT
   Reports & Export: attainment summary, CO, PO, student, subject, class, department reports, scoped to the user's role.
   Export CSV, Excel (.xls) or Print / Save as PDF (browser print dialog). Exports neutralise spreadsheet formulas.
   Accreditation page: PO attainment per department vs target, POs below target, outcome coverage gaps, CSV/Excel/print.
   It summarises your own recorded data; it is not an official NBA/NAAC submission format.

6) SECURITY / DATA-SAFETY CHANGES MADE
   - students.php: delete/update/register now require a CSRF token, respect department/class scope, and an enrolment that
     has marks can no longer be deleted (it used to cascade-delete the marks).
   - api/students.php and api/subjects.php are now read-only + role-scoped (the old POST endpoints accepted cross-site writes).
   - Removed from the package: debug pages (test-db.php, inspect-db.php), " - Copy" backup folders, .lnk shortcuts, and the
     demo js/app.js (fake students/marks in localStorage).
   - Delete setup-admin.php after creating the first Principal. Change the DB password in config.php.

7) VERIFICATION STATUS — please read
   This build was written without a PHP/MySQL runtime available, so it has NOT been executed. What was done instead:
   a static checker (lexer errors, bracket balance, undefined helper functions, bind_param type/argument counts vs SQL
   placeholders, role-map and sidebar-link integrity) found no problems, and the CO/PO maths was checked on a worked example.
   Before real use: run migrate.php (or import database.sql), then walk through each role once with sample data
   (create dept → HOD → incharges → subject → COs → students → marks → mapping → Calculate → reports) and check
   PHP's error log. Expect to fix small issues the first time it runs.

8) NOT COVERED / STILL TO CONFIRM
   - The older marks pages (internal-marks, assignments, practical-marks) were scoped but not redesigned; the chart's
     "Practicals internal/external", "Activities" and "Attendance/other" components depend on how those pages label
     components — check they match your scheme.
   - Indirect assessment (surveys) and per-assessment weightage are not part of the calculation.
   - PDF export is via the browser's print dialog, not server-generated.
