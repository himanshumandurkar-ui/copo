<?php
/*
 * ONE-TIME TOOL — create or reset the Principal login (email + password).
 * Use it when you cannot sign in as Principal (new database, forgotten password, or you want a different login email).
 *
 * Safety (this page can take over the whole system, so it is locked down):
 *   1) It works only from the same computer (localhost) unless you set $ALLOW_REMOTE = true below.
 *   2) You must first change $SETUP_KEY below to your own secret and type the same secret in the form.
 *   3) DELETE this file from the project folder as soon as you have signed in.
 */
$SETUP_KEY    = 'himanshu2';   // <-- put your own secret word/phrase here (at least 8 characters)
$ALLOW_REMOTE = false;                    // keep false on a live server; true only if you must run it from another computer

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$msg = ''; $ok = false; $problem = '';
$ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
if (!$ALLOW_REMOTE && !in_array($ip, ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('This tool only runs on the computer hosting the site (localhost). Open it from that machine, or set $ALLOW_REMOTE = true inside the file.');
}
if ($SETUP_KEY === 'CHANGE-ME-BEFORE-USE' || strlen($SETUP_KEY) < 8) {
    $problem = 'Open reset-principal.php in a text editor and replace CHANGE-ME-BEFORE-USE with your own secret key (8+ characters). Then reload this page.';
}
if (empty($_SESSION['reset_csrf'])) $_SESSION['reset_csrf'] = bin2hex(random_bytes(32));

$conn = null; $dbError = '';
try { $conn = db(); } catch (Throwable $e) { $dbError = 'Cannot connect to the database. Open config.php and make DB_NAME match your database (for example sspace_db), plus the correct DB_USER / DB_PASS.'; }

if ($problem === '' && $conn && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals((string)$_SESSION['reset_csrf'], (string)($_POST['csrf'] ?? ''))) throw new RuntimeException('Form expired. Reload the page and try again.');
        if (!hash_equals($SETUP_KEY, (string)($_POST['key'] ?? ''))) { usleep(600000); throw new RuntimeException('Wrong setup key.'); }
        $name  = trim((string)($_POST['name'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $pass  = (string)($_POST['password'] ?? '');
        $dept  = trim((string)($_POST['department'] ?? 'Computer Science Engineering'));
        if ($name === '' || mb_strlen($name) > 150) throw new RuntimeException('Enter the full name (up to 150 characters).');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) throw new RuntimeException('Enter a valid email address.');
        if (strlen($pass) < 10) throw new RuntimeException('Password must be at least 10 characters.');
        if ($pass !== (string)($_POST['password2'] ?? '')) throw new RuntimeException('The two passwords do not match.');
        if ($dept === '' || mb_strlen($dept) > 150) throw new RuntimeException('Enter a department name.');

        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $conn->begin_transaction();

        // make sure the department row exists and get its id
        $stmt = $conn->prepare('INSERT IGNORE INTO departments(name) VALUES (?)'); $stmt->bind_param('s', $dept); $stmt->execute(); $stmt->close();
        $stmt = $conn->prepare('SELECT id FROM departments WHERE name=? LIMIT 1'); $stmt->bind_param('s', $dept); $stmt->execute();
        $deptId = (int)($stmt->get_result()->fetch_assoc()['id'] ?? 0); $stmt->close();

        $stmt = $conn->prepare('SELECT id FROM users WHERE email=? LIMIT 1'); $stmt->bind_param('s', $email); $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc(); $stmt->close();

        // users.department_id exists in the new schema; fall back gracefully on an older table
        $hasDeptId = (int)$conn->query("SELECT COUNT(*) n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='department_id'")->fetch_assoc()['n'] > 0;

        if ($existing) {
            $uid = (int)$existing['id'];
            if ($hasDeptId) { $stmt = $conn->prepare("UPDATE users SET full_name=?, password_hash=?, role='principal', department=?, department_id=?, active=1 WHERE id=?"); $stmt->bind_param('sssii', $name, $hash, $dept, $deptId, $uid); }
            else            { $stmt = $conn->prepare("UPDATE users SET full_name=?, password_hash=?, role='principal', department=?, active=1 WHERE id=?"); $stmt->bind_param('sssi', $name, $hash, $dept, $uid); }
            $stmt->execute(); $stmt->close();
            $what = 'Existing account updated and set as Principal';
        } else {
            if ($hasDeptId) { $stmt = $conn->prepare("INSERT INTO users(full_name,email,password_hash,role,department,department_id,active) VALUES (?,?,?,'principal',?,?,1)"); $stmt->bind_param('ssssi', $name, $email, $hash, $dept, $deptId); }
            else            { $stmt = $conn->prepare("INSERT INTO users(full_name,email,password_hash,role,department,active) VALUES (?,?,?,'principal',?,1)"); $stmt->bind_param('ssss', $name, $email, $hash, $dept); }
            $stmt->execute(); $uid = (int)$conn->insert_id; $stmt->close();
            $what = 'New Principal account created';
        }
        if (!empty($_POST['deactivate_others'])) {
            $stmt = $conn->prepare("UPDATE users SET active=0 WHERE role='principal' AND id<>?"); $stmt->bind_param('i', $uid); $stmt->execute(); $stmt->close();
            $what .= '; other Principal accounts deactivated';
        }
        $conn->commit();
        try {   // best-effort audit entry (never blocks the reset)
            $stmt = $conn->prepare("INSERT INTO audit_log(user_id, action, entity_type, entity_id, details) VALUES (?, 'principal.reset_tool', 'user', ?, NULL)");
            $stmt->bind_param('ii', $uid, $uid); $stmt->execute(); $stmt->close();
        } catch (Throwable $e) { /* audit table optional here */ }
        $ok = true; $msg = $what . '. Sign in at index.php with ' . $email . '. Now DELETE reset-principal.php from the project folder.';
        $_SESSION['reset_csrf'] = bin2hex(random_bytes(32));
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $e2) {}
        $msg = $e instanceof RuntimeException ? $e->getMessage() : 'Could not save. Check config.php and that database.sql was imported.';
        error_log('reset-principal: ' . $e->getMessage());
    }
}

// existing principals, shown only after the page is unlocked (key check happens on submit)
$principals = [];
if ($problem === '' && $conn && !$ok) {
    try { $principals = $conn->query("SELECT full_name, email, active FROM users WHERE role='principal' ORDER BY id")->fetch_all(MYSQLI_ASSOC); } catch (Throwable $e) { $principals = []; }
}
function rp_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Principal login reset — CO–PO Workspace</title>
<style>body{font:15px Arial,sans-serif;max-width:560px;margin:40px auto;padding:0 18px;color:#1b2a44;background:#f3f4f0}h1{font-size:22px}.card{background:#fff;border:1px solid #dee1e2;border-radius:6px;padding:22px}label{display:block;margin:14px 0 5px;font-size:13px;font-weight:700}input[type=text],input[type=email],input[type=password]{width:100%;padding:10px;border:1px solid #dee1e2;border-radius:3px;box-sizing:border-box;font-size:14px}button{margin-top:20px;padding:12px 18px;background:#1b2a44;color:#fff;border:0;border-radius:3px;font-weight:700;cursor:pointer}.msg{padding:12px 14px;border-radius:4px;margin:0 0 16px;font-size:13px;line-height:1.5}.ok{background:#edf7ef;color:#27633a}.err{background:#fff0ed;color:#9a3428}.warn{background:#fff7e6;color:#8a5a00}small{color:#69768a}.chk{display:flex;gap:8px;align-items:center;font-weight:400;margin-top:16px}ul{padding-left:18px;margin:6px 0}</style></head>
<body><h1>Principal login reset</h1>
<div class="card">
<?php if ($problem !== ''): ?><div class="msg warn"><?= rp_h($problem) ?></div>
<?php elseif ($dbError !== ''): ?><div class="msg err"><?= rp_h($dbError) ?></div>
<?php else: ?>
  <?php if ($msg !== ''): ?><div class="msg <?= $ok ? 'ok' : 'err' ?>"><?= rp_h($msg) ?></div><?php endif; ?>
  <?php if ($ok): ?><p><a href="index.php">Go to sign-in →</a></p>
  <?php else: ?>
    <?php if ($principals): ?><div class="msg warn"><b>Existing Principal accounts:</b><ul><?php foreach ($principals as $p): ?><li><?= rp_h($p['email']) ?> — <?= rp_h($p['full_name']) ?><?= (int)$p['active'] ? '' : ' (inactive)' ?></li><?php endforeach; ?></ul>Enter one of these emails to reset its password, or a new email to create a new Principal.</div><?php else: ?><div class="msg warn">No Principal account exists yet — this will create the first one.</div><?php endif; ?>
    <form method="post" autocomplete="off"><input type="hidden" name="csrf" value="<?= rp_h($_SESSION['reset_csrf']) ?>">
      <label>Setup key <small>(the secret you typed inside this file)</small></label><input type="password" name="key" required autocomplete="off">
      <label>Principal full name</label><input type="text" name="name" required maxlength="150" value="<?= rp_h($_POST['name'] ?? '') ?>">
      <label>Principal login email</label><input type="email" name="email" required maxlength="190" value="<?= rp_h($_POST['email'] ?? '') ?>">
      <label>New password <small>(minimum 10 characters)</small></label><input type="password" name="password" minlength="10" required autocomplete="new-password">
      <label>Confirm password</label><input type="password" name="password2" minlength="10" required autocomplete="new-password">
      <label>Department</label><input type="text" name="department" required maxlength="150" value="<?= rp_h($_POST['department'] ?? 'Computer Science Engineering') ?>">
      <label class="chk"><input type="checkbox" name="deactivate_others" value="1"> Deactivate all other Principal accounts (use this to replace an old Principal login)</label>
      <button type="submit">Save Principal login</button>
    </form>
  <?php endif; ?>
<?php endif; ?>
</div>
<p><small>Delete this file after use — anyone who can open it and knows the key can take over the Principal account.</small></p>
</body></html>