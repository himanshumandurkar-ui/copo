<?php
/*
 * Read-only JSON list of the students the signed-in user may see for the session chosen at login.
 * Scope: principal = college, HOD = own department, class incharge = assigned classes.
 * Writes are done only through students.php / classes.php (CSRF-protected, role-checked).
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json; charset=utf-8');

function api_out(array $data, int $status = 200): never { http_response_code($status); echo json_encode($data); exit; }

$user = current_user();
if (!$user) api_out(['ok' => false, 'message' => 'Authentication required'], 401);
if (!user_can_access_page('students.php', $user)) api_out(['ok' => false, 'message' => 'Your role cannot access student records'], 403);
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') api_out(['ok' => false, 'message' => 'Use the Students page to add or change students'], 405);

$sessionId = (int)($_SESSION['academic_session_id'] ?? 0);
if ($sessionId < 1) api_out(['ok' => false, 'message' => 'No academic session selected. Please sign in again.'], 400);

try {
    $conn = db();
    $stmt = $conn->prepare("SELECT st.id, st.enrollment_no, st.full_name, st.email, st.mobile, st.gender, d.name AS department, e.semester, e.section, a.session_name AS academic_session
        FROM student_enrollments e
        INNER JOIN students st ON st.id = e.student_id
        LEFT JOIN departments d ON d.id = st.department_id
        INNER JOIN academic_sessions a ON a.id = e.academic_session_id
        WHERE e.academic_session_id = ? AND e.status = 'active'" . scope_student_clause($conn, $sessionId, 'e', 'st') . ' ORDER BY st.full_name');
    $stmt->bind_param('i', $sessionId);
    $stmt->execute();
    $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    api_out(['ok' => true, 'data' => $students, 'count' => count($students), 'academic_session_id' => $sessionId]);
} catch (Throwable $e) {
    error_log('api/students: ' . $e->getMessage());
    api_out(['ok' => false, 'message' => 'Could not load students'], 500);
}
