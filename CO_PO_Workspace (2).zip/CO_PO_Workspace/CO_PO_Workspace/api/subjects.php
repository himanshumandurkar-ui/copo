<?php
/*
 * Read-only JSON list of the subjects the signed-in user may see (role-scoped).
 * Writes are done only through subjects.php (CSRF-protected, role-checked); this endpoint
 * no longer accepts POST because cookie-authenticated JSON writes are open to cross-site requests.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json; charset=utf-8');

function api_out(array $data, int $status = 200): never { http_response_code($status); echo json_encode($data); exit; }

if (!current_user()) api_out(['ok' => false, 'message' => 'Authentication required'], 401);
if (!user_can_access_page('subjects.php')) api_out(['ok' => false, 'message' => 'Your role cannot view subjects'], 403);
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') api_out(['ok' => false, 'message' => 'Use the Subjects page to add or change subjects'], 405);

try {
    $rows = db()->query('SELECT s.id, s.subject_code, s.subject_name, s.semester, s.credits, s.subject_type, a.session_name AS academic_session, d.name AS department
        FROM subjects s JOIN academic_sessions a ON a.id = s.academic_session_id LEFT JOIN departments d ON d.id = s.department_id
        WHERE 1=1' . scope_subject_clause('s') . ' ORDER BY s.semester, s.subject_code')->fetch_all(MYSQLI_ASSOC);
    api_out(['ok' => true, 'data' => $rows]);
} catch (Throwable $e) {
    error_log('api/subjects: ' . $e->getMessage());
    api_out(['ok' => false, 'message' => 'Could not load subjects'], 500);
}
