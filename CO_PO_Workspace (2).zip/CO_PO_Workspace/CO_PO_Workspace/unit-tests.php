<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('unit-tests.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$user = current_user() ?? [];
$userId = isset($user['id']) ? (int)$user['id'] : null;
$message = '';
$messageType = 'success';

function ut_h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function ut_redirect(array $params = []): never {
    $url = 'unit-tests.php';
    if ($params) $url .= '?' . http_build_query($params);
    header('Location: ' . $url);
    exit;
}

$sessions = $conn->query("SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC")->fetch_all(MYSQLI_ASSOC);
$activeSessionId = 0;
foreach ($sessions as $s) { if ((int)$s['is_active'] === 1) { $activeSessionId = (int)$s['id']; break; } }
$sessionId = max(0, (int)($_GET['session_id'] ?? $_POST['session_id'] ?? $activeSessionId));
if ($sessionId && !in_array($sessionId, array_map(static fn($s) => (int)$s['id'], $sessions), true)) $sessionId = $activeSessionId;
$semester = max(1, min(8, (int)($_GET['semester'] ?? $_POST['semester'] ?? 5)));
$subjectId = max(0, (int)($_GET['subject_id'] ?? $_POST['subject_id'] ?? 0));
$assessmentId = max(0, (int)($_GET['assessment_id'] ?? $_POST['assessment_id'] ?? 0));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    $sessionId = max(0, (int)($_POST['session_id'] ?? 0));
    $semester = max(1, min(8, (int)($_POST['semester'] ?? 1)));
    $subjectId = max(0, (int)($_POST['subject_id'] ?? 0));
    $assessmentId = max(0, (int)($_POST['assessment_id'] ?? 0));
    try {
        if (!in_array($sessionId, array_map(static fn($s) => (int)$s['id'], $sessions), true)) {
            throw new RuntimeException('Please select a valid academic session.');
        }
        $stmt = $conn->prepare('SELECT id FROM subjects WHERE id=? AND academic_session_id=? AND semester=?' . scope_subject_clause());
        $stmt->bind_param('iii', $subjectId, $sessionId, $semester);
        $stmt->execute();
        $validSubject = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$validSubject) throw new RuntimeException('Selected subject does not match the chosen session and semester.');

        if ($action === 'create_assessment') {
            $name = trim((string)($_POST['component_name'] ?? ''));
            $maxMarks = filter_var($_POST['max_marks'] ?? null, FILTER_VALIDATE_FLOAT);
            $number = max(1, min(255, (int)($_POST['assessment_no'] ?? 1)));
            if ($name === '' || mb_strlen($name) > 100) throw new RuntimeException('Enter an assessment name (maximum 100 characters).');
            if ($maxMarks === false || $maxMarks <= 0 || $maxMarks > 10000) throw new RuntimeException('Maximum marks must be greater than zero.');
            $stmt = $conn->prepare("INSERT INTO assessment_components (subject_id, component_name, max_marks, component_type, assessment_no) VALUES (?, ?, ?, 'unit_test', ?)");
            $stmt->bind_param('isdi', $subjectId, $name, $maxMarks, $number);
            $stmt->execute();
            $newAssessmentId = (int)$conn->insert_id;
            $stmt->close();
            ut_redirect(['session_id'=>$sessionId, 'semester'=>$semester, 'subject_id'=>$subjectId, 'assessment_id'=>$newAssessmentId, 'created'=>1]);
        }

        if ($action === 'save_marks') {
            $stmt = $conn->prepare("SELECT id, max_marks FROM assessment_components WHERE id=? AND subject_id=? AND component_type='unit_test'");
            $stmt->bind_param('ii', $assessmentId, $subjectId);
            $stmt->execute();
            $assessment = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$assessment) throw new RuntimeException('Select a valid unit-test assessment first.');
            $maxMarks = (float)$assessment['max_marks'];
            $marksInput = $_POST['marks'] ?? [];
            if (!is_array($marksInput)) $marksInput = [];

            $enrollStmt = $conn->prepare("SELECT e.id FROM student_enrollments e JOIN subjects s ON s.academic_session_id=e.academic_session_id AND s.semester=e.semester WHERE s.id=? AND e.academic_session_id=? AND e.semester=? AND e.status='active'" . scope_roster_joined_clause('e'));
            $enrollStmt->bind_param('iii', $subjectId, $sessionId, $semester);
            $enrollStmt->execute();
            $validEnrollmentIds = array_map('intval', array_column($enrollStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'id'));
            $enrollStmt->close();
            $coStmt = $conn->prepare('SELECT id FROM course_outcomes WHERE subject_id=?');
            $coStmt->bind_param('i', $subjectId); $coStmt->execute();
            $validCoIds = array_map('intval', array_column($coStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'id'));
            $coStmt->close();
            $conn->begin_transaction();
            try {
                $find = $conn->prepare('SELECT id FROM marks WHERE enrollment_id=? AND assessment_component_id=? AND course_outcome_id=? LIMIT 1');
                $update = $conn->prepare('UPDATE marks SET marks_obtained=?, updated_by=? WHERE id=?');
                $insert = $conn->prepare('INSERT INTO marks (enrollment_id, assessment_component_id, course_outcome_id, marks_obtained, updated_by) VALUES (?, ?, ?, ?, ?)');
                foreach ($marksInput as $enrollmentKey => $coMarks) {
                    $enrollmentId = (int)$enrollmentKey;
                    if (!in_array($enrollmentId, $validEnrollmentIds, true) || !is_array($coMarks)) continue;
                    foreach ($coMarks as $coKey => $rawValue) {
                        $coId = (int)$coKey;
                        if (!in_array($coId, $validCoIds, true) || $rawValue === '') continue;
                        if (!is_numeric($rawValue)) throw new RuntimeException('Marks must be numeric.');
                        $score = (float)$rawValue;
                        if ($score < 0 || $score > $maxMarks) throw new RuntimeException('Marks must be between 0 and ' . rtrim(rtrim(number_format($maxMarks, 2, '.', ''), '0'), '.') . '.');
                        $find->bind_param('iii', $enrollmentId, $assessmentId, $coId);
                        $find->execute(); $existing = $find->get_result()->fetch_assoc();
                        if ($existing) {
                            $markId = (int)$existing['id'];
                            if ($userId === null) {
                                $updateNoUser = $conn->prepare('UPDATE marks SET marks_obtained=? WHERE id=?');
                                $updateNoUser->bind_param('di', $score, $markId); $updateNoUser->execute(); $updateNoUser->close();
                            } else {
                                $update->bind_param('dii', $score, $userId, $markId);
                                $update->execute();
                            }
                        } else {
                            if ($userId === null) {
                                $insertNoUser = $conn->prepare('INSERT INTO marks (enrollment_id, assessment_component_id, course_outcome_id, marks_obtained) VALUES (?, ?, ?, ?)');
                                $insertNoUser->bind_param('iiid', $enrollmentId, $assessmentId, $coId, $score); $insertNoUser->execute(); $insertNoUser->close();
                            } else { $insert->bind_param('iiidi', $enrollmentId, $assessmentId, $coId, $score, $userId); $insert->execute(); }
                        }
                    }
                }
                $find->close(); $update->close(); $insert->close();
                $conn->commit();
            } catch (Throwable $e) { $conn->rollback(); throw $e; }
            ut_redirect(['session_id'=>$sessionId, 'semester'=>$semester, 'subject_id'=>$subjectId, 'assessment_id'=>$assessmentId, 'saved'=>1]);
        }
    } catch (Throwable $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }
}
if (isset($_GET['created'])) { $message = 'Unit-test assessment created successfully.'; $messageType = 'success'; }
if (isset($_GET['saved'])) { $message = 'Marks saved successfully.'; $messageType = 'success'; }

$subjects = [];
if ($sessionId > 0) {
    $stmt = $conn->prepare('SELECT id, subject_code, subject_name FROM subjects WHERE academic_session_id=? AND semester=?' . scope_subject_clause() . ' ORDER BY subject_code, subject_name');
    $stmt->bind_param('ii', $sessionId, $semester); $stmt->execute(); $subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
}
if ($subjects && !in_array($subjectId, array_map(static fn($s)=>(int)$s['id'], $subjects), true)) $subjectId = (int)$subjects[0]['id'];
$assessments = [];
$courseOutcomes = [];
$students = [];
$savedMarks = [];
$selectedAssessment = null;
if ($subjectId > 0) {
    $stmt = $conn->prepare("SELECT id, component_name, max_marks, assessment_no FROM assessment_components WHERE subject_id=? AND component_type='unit_test' ORDER BY assessment_no, id");
    $stmt->bind_param('i', $subjectId); $stmt->execute(); $assessments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    $stmt = $conn->prepare('SELECT id, co_code, description FROM course_outcomes WHERE subject_id=? ORDER BY id');
    $stmt->bind_param('i', $subjectId); $stmt->execute(); $courseOutcomes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    if ($assessments && !in_array($assessmentId, array_map(static fn($a)=>(int)$a['id'], $assessments), true)) $assessmentId = (int)$assessments[0]['id'];
    if ($assessmentId > 0) {
        $stmt = $conn->prepare("SELECT id, component_name, max_marks, assessment_no FROM assessment_components WHERE id=? AND subject_id=? AND component_type='unit_test'");
        $stmt->bind_param('ii', $assessmentId, $subjectId); $stmt->execute(); $selectedAssessment = $stmt->get_result()->fetch_assoc(); $stmt->close();
    }
    $stmt = $conn->prepare("SELECT e.id AS enrollment_id, st.enrollment_no, st.full_name FROM student_enrollments e JOIN students st ON st.id=e.student_id WHERE e.academic_session_id=? AND e.semester=? AND e.status='active'" . scope_roster_clause('e', (int)$subjectId) . " ORDER BY st.full_name");
    $stmt->bind_param('ii', $sessionId, $semester); $stmt->execute(); $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    if ($selectedAssessment && $courseOutcomes) {
        $stmt = $conn->prepare('SELECT enrollment_id, course_outcome_id, marks_obtained FROM marks WHERE assessment_component_id=? AND course_outcome_id IS NOT NULL');
        $stmt->bind_param('i', $assessmentId); $stmt->execute();
        foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $m) $savedMarks[(int)$m['enrollment_id']][(int)$m['course_outcome_id']] = $m['marks_obtained'];
        $stmt->close();
    }
}
$sessionName = '';
foreach ($sessions as $s) if ((int)$s['id'] === $sessionId) $sessionName = $s['session_name'];
?>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>CO–PO Workspace — Unit Tests</title><link rel="stylesheet" href="css/style.css">
<style>
.unit-filter{display:grid;grid-template-columns:repeat(4,minmax(130px,1fr)) auto;gap:14px;align-items:end;padding:18px 20px;border-bottom:1px solid var(--line)}
.unit-filter .field{min-width:0}.unit-filter .btn{height:36px;white-space:nowrap}.message{margin:16px 20px 0;padding:12px 14px;border-radius:4px;background:var(--greent);color:var(--green)}.message.error{background:var(--redt);color:var(--red)}
.assessment-create{padding:18px 20px;display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:14px;align-items:end;border-bottom:1px solid var(--line2)}
.table-actions{padding:14px 20px;display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;border-top:1px solid var(--line2)}
.marks-input{width:72px;max-width:100%;height:32px;border:1px solid var(--line);border-radius:4px;text-align:center;padding:4px}.empty{padding:28px;text-align:center;color:var(--muted)}.student-cell strong{display:block}.student-cell small{color:var(--muted)}
@media(max-width:1100px){.unit-filter{grid-template-columns:repeat(2,minmax(130px,1fr))}.assessment-create{grid-template-columns:1fr 1fr}.content{padding:22px}}
@media(max-width:650px){body{min-width:0}.shell{display:block}.sidebar{width:100%;min-width:0;min-height:auto}.unit-filter,.assessment-create{grid-template-columns:1fr}.topbar{height:auto;min-height:60px;flex-wrap:wrap;padding:12px}.content{padding:14px}.page-head{gap:12px;flex-wrap:wrap}}
</style></head>
<body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<header class="topbar"><div class="crumb">CO–PO Workspace / <b>Record marks / Unit tests</b></div><div class="topbar-spacer"></div><div class="term-pill"><span class="dot"></span><?=ut_h($sessionName ?: 'Select session')?> · Semester <?= (int)$semester ?></div><a class="term-pill" href="profile.php" style="text-decoration:none">Profile</a><a class="term-pill" href="logout.php" style="text-decoration:none">Logout</a></header>
<div class="content"><div class="page-head"><div><h1>Unit tests</h1><p>Choose a class and subject, create a unit-test assessment, then enter CO-wise marks.</p></div></div>
<div class="card">
<form method="get" class="unit-filter">
<div class="field"><label for="session_id">Academic session</label><select class="control" id="session_id" name="session_id" required><?php foreach($sessions as $s): ?><option value="<?= (int)$s['id']?>" <?=$sessionId===(int)$s['id']?'selected':''?>><?=ut_h($s['session_name'])?><?= (int)$s['is_active']===1?' (Active)':''?></option><?php endforeach;?></select></div>
<div class="field"><label for="semester">Semester</label><select class="control" id="semester" name="semester"><?php for($i=1;$i<=8;$i++):?><option value="<?=$i?>" <?=$semester===$i?'selected':''?>>Semester <?=$i?></option><?php endfor;?></select></div>
<div class="field"><label for="subject_id">Subject</label><select class="control" id="subject_id" name="subject_id" required><option value="">Select subject</option><?php foreach($subjects as $s):?><option value="<?=(int)$s['id']?>" <?=$subjectId===(int)$s['id']?'selected':''?>><?=ut_h($s['subject_code'].' — '.$s['subject_name'])?></option><?php endforeach;?></select></div>
<div class="field"><label for="assessment_id">Unit-test assessment</label><select class="control" id="assessment_id" name="assessment_id"><option value="0">Select assessment</option><?php foreach($assessments as $a):?><option value="<?=(int)$a['id']?>" <?=$assessmentId===(int)$a['id']?'selected':''?>><?=ut_h($a['component_name'])?> (<?=ut_h($a['max_marks'])?> marks)</option><?php endforeach;?></select></div>
<button class="btn btn-primary" type="submit">Load class list</button>
</form>
<?php if($message!==''):?><div class="message <?=$messageType==='error'?'error':''?>" role="status"><?=ut_h($message)?></div><?php endif;?>
<?php if(!$subjects):?><div class="empty">No subjects found for this academic session and semester. Add a subject in <a href="subjects.php">Subjects &amp; COs</a>, then select the matching session and semester.</div><?php elseif(!$courseOutcomes):?><div class="empty">This subject has no Course Outcomes yet. Add COs in <a href="subjects.php">Subjects &amp; COs</a> before entering CO-wise marks.</div><?php else:?>
<div class="card-head"><div><h2><?=ut_h('Unit-test assessment setup')?></h2><span>Create a separate record for each unit test.</span></div></div>
<form method="post" class="assessment-create"><input type="hidden" name="action" value="create_assessment"><input type="hidden" name="session_id" value="<?=$sessionId?>"><input type="hidden" name="semester" value="<?=$semester?>"><input type="hidden" name="subject_id" value="<?=$subjectId?>">
<div class="field"><label for="component_name">Assessment name</label><input class="control" id="component_name" name="component_name" maxlength="100" placeholder="e.g. Unit Test 1" required></div>
<div class="field"><label for="max_marks">Maximum marks</label><input class="control" id="max_marks" name="max_marks" type="number" min="0.01" max="10000" step="0.01" value="20" required></div>
<div class="field"><label for="assessment_no">Test number</label><select class="control" id="assessment_no" name="assessment_no"><?php for($i=1;$i<=10;$i++):?><option value="<?=$i?>">Unit Test <?=$i?></option><?php endfor;?></select></div>
<button class="btn btn-outline" type="submit">＋ Create assessment</button></form>
<?php if(!$selectedAssessment):?><div class="empty">Select an existing assessment or create one above to start entering marks.</div><?php elseif(!$students):?><div class="empty">No active students are enrolled in this session and semester. Check student enrollment records first.</div><?php else:?>
<form method="post"><input type="hidden" name="action" value="save_marks"><input type="hidden" name="session_id" value="<?=$sessionId?>"><input type="hidden" name="semester" value="<?=$semester?>"><input type="hidden" name="subject_id" value="<?=$subjectId?>"><input type="hidden" name="assessment_id" value="<?=$assessmentId?>">
<div class="section-note"><strong style="color:var(--text)"><?=ut_h($selectedAssessment['component_name'])?></strong> · <?=count($students)?> enrolled students · Maximum <?=ut_h($selectedAssessment['max_marks'])?> marks per CO</div>
<div class="table-wrap"><table class="data"><thead><tr><th>#</th><th>Student</th><?php foreach($courseOutcomes as $co):?><th><?=ut_h($co['co_code'])?><br><span class="muted">/ <?=ut_h($selectedAssessment['max_marks'])?></span></th><?php endforeach;?><th class="num">Total</th></tr></thead><tbody>
<?php foreach($students as $idx=>$st):?><tr><td class="row-index"><?=$idx+1?></td><td class="student-cell"><strong><?=ut_h($st['full_name'])?></strong><small><?=ut_h($st['enrollment_no'])?></small></td><?php foreach($courseOutcomes as $co):$value=$savedMarks[(int)$st['enrollment_id']][(int)$co['id']]??'';?><td><input class="marks-input" type="number" min="0" max="<?=ut_h($selectedAssessment['max_marks'])?>" step="0.01" name="marks[<?=(int)$st['enrollment_id']?>][<?=(int)$co['id']?>]" value="<?=ut_h($value)?>" aria-label="<?=ut_h($st['full_name'].' '.$co['co_code'])?>" data-row="<?=(int)$st['enrollment_id']?>"></td><?php endforeach;?><td class="num"><strong id="total-<?=(int)$st['enrollment_id']?>">—</strong></td></tr><?php endforeach;?>
</tbody></table></div><div class="table-actions"><span class="muted">Leave a field blank if marks have not been entered. Enter 0 for an actual zero score.</span><button class="btn btn-gold" type="submit">Save unit-test marks</button></div></form>
<?php endif;?><?php endif;?>
</div></div></main></div>
<script>
document.querySelectorAll('input.marks-input').forEach(function(input){input.addEventListener('input',function(){var row=input.dataset.row;var total=0,has=false;document.querySelectorAll('input.marks-input[data-row="'+row+'"]').forEach(function(el){if(el.value!==''){total+=Number(el.value)||0;has=true;}});var out=document.getElementById('total-'+row);if(out)out.textContent=has?total.toFixed(2).replace(/\.00$/,''):'—';});input.dispatchEvent(new Event('input'));});
</script></body></html>
