<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('accreditation.php');        // principal only
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/engine.php';
require_once __DIR__ . '/includes/export.php';

$conn = db();
$sessions = $conn->query('SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
[$loginSessionId] = session_selected($conn);
$sessionId = filter_input(INPUT_GET, 'session_id', FILTER_VALIDATE_INT) ?: $loginSessionId;
$sessionName = ''; foreach ($sessions as $s) if ((int)$s['id'] === $sessionId) $sessionName = $s['session_name'];
$departments = scope_departments($conn);

/* ---- PO attainment per department, compared with each department's PO target level ---- */
$matrix = []; $gaps = []; $subjectIssues = [];
foreach ($departments as $d) {
    $did = (int)$d['id'];
    $settings = engine_settings($conn, $did);
    $roll = engine_po_rollup($conn, $sessionId, $did);
    $titles = [];
    try {
        $stmt = $conn->prepare('SELECT po_number, title FROM program_outcomes WHERE department_id=?'); $stmt->bind_param('i', $did); $stmt->execute();
        foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $r) $titles[(int)$r['po_number']] = $r['title'];
        $stmt->close();
    } catch (Throwable $e) { /* table not created yet */ }
    $matrix[$did] = ['name' => $d['name'], 'target' => $settings['po_target_level'], 'roll' => $roll, 'titles' => $titles];
    for ($po = 1; $po <= 12; $po++) {
        if (isset($roll[$po]) && $roll[$po]['level'] < $settings['po_target_level']) {
            $gaps[] = [$d['name'], 'PO' . $po, $titles[$po] ?? '', $roll[$po]['level'], $settings['po_target_level']];
        }
    }
    foreach (engine_co_by_subject($conn, $sessionId, $did) as $r) {
        $stmt = $conn->prepare('SELECT COUNT(*) n FROM course_outcomes WHERE subject_id=?'); $sid = (int)$r['id']; $stmt->bind_param('i', $sid); $stmt->execute();
        $defined = (int)$stmt->get_result()->fetch_assoc()['n']; $stmt->close();
        $stmt = $conn->prepare('SELECT COUNT(DISTINCT m.course_outcome_id) n FROM co_po_mapping m JOIN course_outcomes co ON co.id=m.course_outcome_id WHERE co.subject_id=? AND m.mapping_level>0');
        $stmt->bind_param('i', $sid); $stmt->execute(); $mapped = (int)$stmt->get_result()->fetch_assoc()['n']; $stmt->close();
        $calculated = (int)$r['co_count'];
        $issue = [];
        if ($defined === 0) $issue[] = 'No course outcomes defined';
        elseif ($calculated < $defined) $issue[] = ($defined - $calculated) . ' CO(s) not calculated';
        if ($defined > 0 && $mapped < $defined) $issue[] = ($defined - $mapped) . ' CO(s) not mapped to POs';
        $subjectIssues[] = ['dept' => $d['name'], 'code' => $r['subject_code'], 'name' => $r['subject_name'], 'sem' => (int)$r['semester'],
            'defined' => $defined, 'calculated' => $calculated, 'mapped' => $mapped,
            'avg' => $r['avg_level'] === null ? null : (float)$r['avg_level'], 'target' => $settings['co_target_level'], 'issue' => implode('; ', $issue)];
    }
}

/* ---- export ---- */
$export = (string)($_GET['export'] ?? '');
if (in_array($export, ['csv', 'xls'], true)) {
    $hdr = ['Department', 'PO', 'Title', 'Attainment level (0-3)', 'Target level', 'Subjects contributing', 'Target met'];
    $rows = [];
    foreach ($matrix as $m) for ($po = 1; $po <= 12; $po++) {
        if (!isset($m['roll'][$po])) continue;
        $rows[] = [$m['name'], 'PO' . $po, $m['titles'][$po] ?? '', number_format($m['roll'][$po]['level'], 2), number_format($m['target'], 2), $m['roll'][$po]['subjects'], $m['roll'][$po]['level'] >= $m['target'] ? 'Yes' : 'No'];
    }
    audit_write($conn, 'export.accreditation', 'report', null, ['format' => $export, 'session_id' => $sessionId]);
    export_send($export, 'accreditation_po_attainment_' . $sessionName, $hdr, $rows);
}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Accreditation Support — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css">
<style>table.po-grid{border-collapse:collapse;width:100%}table.po-grid th,table.po-grid td{border:1px solid #e5e8e4;padding:9px 6px;text-align:center;font-size:11.5px}table.po-grid th{background:#f7f8f6;color:#53627a}table.po-grid td.dept{text-align:left;padding-left:12px;font-weight:600}.lv-ok{background:#e5f1eb;color:#2f8063;font-weight:700}.lv-near{background:#f7ecd7;color:#9b6b1c;font-weight:700}.lv-low{background:#fae7e2;color:#bb4b37;font-weight:700}.lv-none{color:#c5cbc8}</style>
</head><body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Accreditation Support'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow">NBA / NAAC SUPPORT · COLLEGE LEVEL</div><h1>Accreditation Support</h1><p>Programme-level PO attainment against target, outcome coverage, and gaps to close before an accreditation visit.</p></div>
<div class="export-bar no-print"><a class="btn btn-outline" href="accreditation.php?session_id=<?= (int)$sessionId ?>&export=csv">Export CSV</a><a class="btn btn-outline" href="accreditation.php?session_id=<?= (int)$sessionId ?>&export=xls">Export Excel</a><button class="btn btn-gold" onclick="window.print()">Print / Save PDF</button></div></div>

<form method="get" class="card no-print" style="margin-bottom:20px"><div class="panel-body"><div class="form-row tight"><div class="field"><label>Academic session</label><select class="control" name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $s): ?><option value="<?= (int)$s['id'] ?>" <?= $sessionId === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['session_name']) ?></option><?php endforeach; ?></select></div></div></div></form>

<div class="card"><div class="card-head"><div><h2>PO attainment by department — <?= h($sessionName) ?></h2><span>Average PO level (0–3) across subjects that map to the PO; green = target met</span></div></div>
<div class="table-wrap"><table class="po-grid"><thead><tr><th style="text-align:left;padding-left:12px">Department</th><th>Target</th><?php for ($po = 1; $po <= 12; $po++): ?><th>PO<?= $po ?></th><?php endfor; ?></tr></thead><tbody>
<?php if (!$matrix): ?><tr><td colspan="14"><div class="muted-empty">No departments found.</div></td></tr><?php endif; ?>
<?php foreach ($matrix as $m): ?><tr><td class="dept"><?= h($m['name']) ?></td><td><?= number_format($m['target'], 2) ?></td>
<?php for ($po = 1; $po <= 12; $po++): if (!isset($m['roll'][$po])) { echo '<td class="lv-none">–</td>'; continue; } $lv = $m['roll'][$po]['level']; $cls = $lv >= $m['target'] ? 'lv-ok' : ($lv >= $m['target'] - 0.5 ? 'lv-near' : 'lv-low'); ?><td class="<?= $cls ?>" title="<?= h($m['titles'][$po] ?? 'PO' . $po) ?> · <?= (int)$m['roll'][$po]['subjects'] ?> subject(s)"><?= number_format($lv, 2) ?></td><?php endfor; ?></tr><?php endforeach; ?>
</tbody></table></div>
<div class="help-text">Levels come from saved subject results. A dash means no subject has been calculated for that PO yet. Targets are set per department under CO/PO Attainment → Attainment rules.</div></div>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>POs below target</h2><span>Candidates for corrective action</span></div><span class="badge <?= $gaps ? 'rust' : 'green' ?>"><?= count($gaps) ?></span></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Department</th><th>PO</th><th>Title</th><th class="num">Level</th><th class="num">Target</th></tr></thead><tbody>
<?php if (!$gaps): ?><tr><td colspan="5"><div class="muted-empty">No calculated PO is below its target.</div></td></tr><?php endif; ?>
<?php foreach ($gaps as [$dn, $code, $title, $lv, $tg]): ?><tr><td><?= h($dn) ?></td><td><b><?= h($code) ?></b></td><td><?= h($title ?: '—') ?></td><td class="num"><?= ui_level_badge((float)$lv, (float)$tg) ?></td><td class="num"><?= number_format((float)$tg, 2) ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>

<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Subject outcome coverage</h2><span>Are course outcomes defined, mapped and calculated?</span></div></div>
<div class="table-wrap"><table class="data"><thead><tr><th>Department</th><th>Subject</th><th>Sem</th><th class="num">COs</th><th class="num">Mapped</th><th class="num">Calculated</th><th class="num">Avg CO level</th><th>Follow-up</th></tr></thead><tbody>
<?php if (!$subjectIssues): ?><tr><td colspan="8"><div class="muted-empty">No subjects in this session.</div></td></tr><?php endif; ?>
<?php foreach ($subjectIssues as $r): ?><tr><td><?= h($r['dept']) ?></td><td><b><?= h($r['code']) ?></b> — <?= h($r['name']) ?></td><td><?= (int)$r['sem'] ?></td><td class="num"><?= (int)$r['defined'] ?></td><td class="num"><?= (int)$r['mapped'] ?></td><td class="num"><?= (int)$r['calculated'] ?></td><td class="num"><?= ui_level_badge($r['avg'], (float)$r['target']) ?></td><td><?= $r['issue'] === '' ? '<span class="badge green">Complete</span>' : '<span class="badge gold">' . h($r['issue']) . '</span>' ?></td></tr><?php endforeach; ?>
</tbody></table></div>
<div class="help-text">This page summarises your own recorded data to help prepare evidence. It is not an official NBA/NAAC submission format; confirm the required templates with your accreditation cell.</div></div>
</section></div></main></div></body></html>
