<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('students.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$message = '';
$messageType = 'success';

if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

// Load department names using whichever supported label column exists in this database.
$departmentColumns = [];
$columnResult = $conn->query('SHOW COLUMNS FROM departments');
while ($columnRow = $columnResult->fetch_assoc()) {
    $departmentColumns[] = $columnRow['Field'];
}
$departmentNameColumn = null;
foreach (['department_name', 'name', 'department'] as $candidate) {
    if (in_array($candidate, $departmentColumns, true)) {
        $departmentNameColumn = $candidate;
        break;
    }
}
$departments = [];
if ($departmentNameColumn !== null && in_array('id', $departmentColumns, true)) {
    $safeColumn = '`' . str_replace('`', '``', $departmentNameColumn) . '`';
    $result = $conn->query("SELECT id, $safeColumn AS department_name FROM departments ORDER BY $safeColumn");
    while ($row = $result->fetch_assoc()) {
        $departments[] = $row;
    }
}

// Load all academic sessions. The login-selected session is the default selection.
$sessions = [];
$result = $conn->query('SELECT id, session_name FROM academic_sessions ORDER BY session_name DESC');
while ($row = $result->fetch_assoc()) {
    $sessions[] = $row;
}
$sessionIds = array_map(static fn($row) => (int)$row['id'], $sessions);
$selectedSessionId = (int)($_SESSION['academic_session_id'] ?? 0);
if (!in_array($selectedSessionId, $sessionIds, true)) {
    $selectedSessionId = $sessions ? (int)$sessions[0]['id'] : 0;
}

// ---- Workflow guards: CSRF, role scope and history protection ---------------------------------
$myDeptId = role_is('principal') ? 0 : user_department_id($conn);
if (!role_is('principal')) {
    $departments = array_values(array_filter($departments, static fn($d) => (int)$d['id'] === $myDeptId));
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array(($_POST['action'] ?? ''), ['delete', 'update', 'register'], true)) {
    $guardError = '';
    $guardAction = (string)$_POST['action'];
    if (!hash_equals(csrf_token(), (string)($_POST['csrf_token'] ?? ''))) {
        $guardError = 'Your session token expired. Refresh the page and try again.';
    } else {
        if (!role_is('principal')) $_POST['department_id'] = (string)$myDeptId;   // cannot register into another department
        if ($guardAction === 'delete' || $guardAction === 'update') {
            $gStmt = $conn->prepare('SELECT se.academic_session_id AS sid, se.semester, se.section, st.department_id, (SELECT COUNT(*) FROM marks m WHERE m.enrollment_id = se.id) AS mark_rows FROM student_enrollments se JOIN students st ON st.id = se.student_id WHERE se.id = ?');
            $gEnr = (int)($_POST['enrollment_id'] ?? 0);
            $gStmt->bind_param('i', $gEnr);
            $gStmt->execute();
            $gRow = $gStmt->get_result()->fetch_assoc();
            $gStmt->close();
            if (!$gRow || !scope_class_allows($conn, (int)$gRow['sid'], (int)($gRow['department_id'] ?? 0), (int)$gRow['semester'], (string)$gRow['section'])) {
                $guardError = 'You do not have access to this student record.';
            } elseif ($guardAction === 'delete' && (int)$gRow['mark_rows'] > 0) {
                $guardError = 'This enrollment has recorded marks, so it cannot be deleted. Academic history is kept for audit and accreditation.';
            }
        }
        if ($guardError === '' && ($guardAction === 'update' || $guardAction === 'register')) {
            if (!scope_class_allows($conn, (int)($_POST['session_id'] ?? 0), (int)($_POST['department_id'] ?? 0), (int)($_POST['semester'] ?? 0), trim((string)($_POST['section'] ?? '')))) {
                $guardError = role_is('class_incharge') ? 'You can only add or move students within a class assigned to you.' : 'You cannot manage students of this department.';
            }
        }
    }
    if ($guardError !== '') { $message = $guardError; $messageType = 'error'; $_POST['action'] = 'blocked'; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $enrollmentId = (int)($_POST['enrollment_id'] ?? 0);

    if ($enrollmentId < 1) {
        $message = 'Invalid student enrollment.';
        $messageType = 'error';
    } else {
        try {
            $stmt = $conn->prepare(
                'DELETE FROM student_enrollments WHERE id = ?'
            );
            $stmt->bind_param('i', $enrollmentId);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                $message = 'Student enrollment deleted successfully.';
                $messageType = 'success';
            } else {
                $message = 'Student enrollment not found.';
                $messageType = 'error';
            }

            $stmt->close();
        } catch (Throwable $e) {
            $message = 'Could not delete this enrollment. Related records may exist.';
            $messageType = 'error';
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update') {
    $studentId = (int)($_POST['student_id'] ?? 0);
    $enrollmentId = (int)($_POST['enrollment_id'] ?? 0);
    $enrollmentNo = trim($_POST['enrollment_no'] ?? '');
    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $departmentId = (int)($_POST['department_id'] ?? 0);
    $sessionId = (int)($_POST['session_id'] ?? 0);
    $semester = (int)($_POST['semester'] ?? 0);
    $section = trim($_POST['section'] ?? '');
    $validGenders = ['Male', 'Female', 'Other', 'Prefer not to say'];
if (
    $studentId < 1 ||
    $enrollmentId < 1 ||
    $enrollmentNo === '' ||
    $fullName === '' ||
    !in_array($sessionId, $sessionIds, true) ||
    $semester < 1 ||
    $semester > 8 ||
    $section === ''
) {
    $message = 'Please complete all required fields with valid values.';
    $messageType = 'error';
} elseif ($email === '') {
    $message = 'Please fill in the email field.';
    $messageType = 'error';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $message = 'Please enter a valid email address.';
    $messageType = 'error';
} elseif ($mobile === '') {
    $message = 'Please fill in the mobile number field.';
    $messageType = 'error';
} elseif (!preg_match('/^[6-9][0-9]{9}$/', $mobile)) {
    $message = 'Please enter a valid 10-digit Indian mobile number.';
    $messageType = 'error';
} elseif ($gender !== '' && !in_array($gender, $validGenders, true)) {
    $message = 'Please select a valid gender.';
    $messageType = 'error';
} elseif ($departmentId > 0 && !in_array($departmentId, array_map('intval', array_column($departments, 'id')), true)) {
    $message = 'Please select a valid department.';
    $messageType = 'error';

    } else {
        try {
            // Prevent duplicate email during student update.
$stmt = $conn->prepare(
    'SELECT id FROM students WHERE email = ? AND id <> ? LIMIT 1'
);
$stmt->bind_param('si', $email, $studentId);
$stmt->execute();
$duplicateEmail = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($duplicateEmail) {
    throw new RuntimeException(
        'This email address is already used by another student.'
    );
}
            $stmt = $conn->prepare('SELECT id FROM students WHERE enrollment_no = ? AND id <> ? LIMIT 1');
            $stmt->bind_param('si', $enrollmentNo, $studentId);
            $stmt->execute();
            $duplicate = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($duplicate) {
                throw new RuntimeException('That enrollment number is already used by another student.');
            }
            $stmt = $conn->prepare('SELECT id FROM student_enrollments WHERE id = ? AND student_id = ? LIMIT 1');
            $stmt->bind_param('ii', $enrollmentId, $studentId);
            $stmt->execute();
            $enrollmentExists = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$enrollmentExists) {
                throw new RuntimeException('The selected enrollment record could not be found.');
            }

            $conn->begin_transaction();
            if ($departmentId > 0) {
                $stmt = $conn->prepare("UPDATE students SET enrollment_no=?, full_name=?, email=NULLIF(?, ''), mobile=NULLIF(?, ''), gender=NULLIF(?, ''), department_id=? WHERE id=?");
                $stmt->bind_param('sssssii', $enrollmentNo, $fullName, $email, $mobile, $gender, $departmentId, $studentId);
            } else {
                $stmt = $conn->prepare("UPDATE students SET enrollment_no=?, full_name=?, email=NULLIF(?, ''), mobile=NULLIF(?, ''), gender=NULLIF(?, ''), department_id=NULL WHERE id=?");
                $stmt->bind_param('sssssi', $enrollmentNo, $fullName, $email, $mobile, $gender, $studentId);
            }
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE student_enrollments SET academic_session_id=?, semester=?, section=? WHERE id=? AND student_id=?");
            $stmt->bind_param('iisii', $sessionId, $semester, $section, $enrollmentId, $studentId);
            $stmt->execute();
            $stmt->close();
            $conn->commit();
            header('Location: students.php?updated=1', true, 303);
            exit;
        } catch (Throwable $e) {
            try { $conn->rollback(); } catch (Throwable $ignored) {}
            if ($e instanceof RuntimeException) {
                $message = $e->getMessage();
            } elseif ($e instanceof mysqli_sql_exception && (int)$e->getCode() === 1062) {
                $message = 'This change conflicts with an existing enrollment record.';
            } else {
                error_log('CO-PO student update error: ' . $e->getMessage());
                $message = 'Student update failed. Please check the database and try again.';
            }
            $messageType = 'error';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'register') {
    $enrollmentNo = trim($_POST['enrollment_no'] ?? '');
    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $departmentId = (int)($_POST['department_id'] ?? 0);
    $sessionId = (int)($_POST['session_id'] ?? 0);
    $semester = (int)($_POST['semester'] ?? 0);
    $section = trim($_POST['section'] ?? '');
    $validGenders = ['Male', 'Female', 'Other', 'Prefer not to say'];

   if (
    $enrollmentNo === '' ||
    $fullName === '' ||
    $email === '' ||
    $mobile === '' ||
    $sessionId < 1 ||
    $semester < 1 ||
    $semester > 8 ||
    $section === ''
) {
    $message = 'Please fill in all required fields.';
    $messageType = 'error';
} elseif (!in_array($sessionId, $sessionIds, true)) {
    $message = 'Please select a valid academic session.';
    $messageType = 'error';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $message = 'Please enter a valid email address.';
    $messageType = 'error';
} elseif (!preg_match('/^[6-9][0-9]{9}$/', $mobile)) {
    $message = 'Please enter a valid 10-digit Indian mobile number.';
    $messageType = 'error';
} elseif ($gender !== '' && !in_array($gender, $validGenders, true)) {
    $message = 'Please select a valid gender.';
    $messageType = 'error';
} elseif ($departmentId > 0 && !in_array($departmentId, array_map('intval', array_column($departments, 'id')), true)) {
    $message = 'Please select a valid department.';
    $messageType = 'error';
} else {
        $transactionStarted = false;
        try {
            $conn->begin_transaction();
            $transactionStarted = true;

            // Enrollment number belongs to one student: check before inserting the student.
            $stmt = $conn->prepare('SELECT id FROM students WHERE enrollment_no = ? LIMIT 1');
            $stmt->bind_param('s', $enrollmentNo);
            $stmt->execute();
            $existingStudent = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($existingStudent) {
                throw new RuntimeException('This enrollment number is already registered.');
            }
            // Prevent duplicate email addresses.
$stmt = $conn->prepare(
    'SELECT id FROM students WHERE email = ? LIMIT 1'
);
$stmt->bind_param('s', $email);
$stmt->execute();
$existingEmail = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($existingEmail) {
    throw new RuntimeException('This email address is already registered.');
}
            $stmt = $conn->prepare('SELECT id FROM academic_sessions WHERE id = ? LIMIT 1');
            $stmt->bind_param('i', $sessionId);
            $stmt->execute();
            $sessionExists = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$sessionExists) {
                throw new RuntimeException('Selected academic session was not found. Please refresh and try again.');
            }

            if ($departmentId > 0) {
                $stmt = $conn->prepare("INSERT INTO students (enrollment_no, full_name, email, mobile, gender, department_id) VALUES (?, ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), ?)");
                $stmt->bind_param('sssssi', $enrollmentNo, $fullName, $email, $mobile, $gender, $departmentId);
            } else {
                $stmt = $conn->prepare("INSERT INTO students (enrollment_no, full_name, email, mobile, gender, department_id) VALUES (?, ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), NULL)");
                $stmt->bind_param('sssss', $enrollmentNo, $fullName, $email, $mobile, $gender);
            }
            $stmt->execute();
            $studentId = (int)$conn->insert_id;
            $stmt->close();

            $stmt = $conn->prepare("INSERT INTO student_enrollments (student_id, academic_session_id, semester, section, status) VALUES (?, ?, ?, ?, 'active')");
            $stmt->bind_param('iiis', $studentId, $sessionId, $semester, $section);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            header('Location: students.php?registered=1', true, 303);
            exit;
        } catch (Throwable $e) {
            if ($transactionStarted) {
                try { $conn->rollback(); } catch (Throwable $ignored) {}
            }
            if ($e instanceof RuntimeException) {
                $message = $e->getMessage();
            } elseif ($e instanceof mysqli_sql_exception && (int)$e->getCode() === 1062) {
                $message = 'This enrollment number or enrollment record already exists.';
            } else {
                error_log('CO-PO student registration error: ' . $e->getMessage());
                $message = 'Registration failed. Please check the database schema and required fields, then try again.';
            }
            $messageType = 'error';
        }
    }
}

if (isset($_GET['registered'])) {
    $message = 'Student registered successfully.';
    $messageType = 'success';
} elseif (isset($_GET['updated'])) {
    $message = 'Student and enrollment details updated successfully.';
    $messageType = 'success';
}

// Each row represents an enrollment in a session/semester; preserve students' academic history.
$students = [];
$result = $conn->query("SELECT s.id, s.enrollment_no, s.full_name, s.email, s.mobile, s.gender, s.department_id,
                               e.id AS enrollment_id, e.academic_session_id, e.semester, e.section, e.status, a.session_name
                        FROM student_enrollments e
                        INNER JOIN students s ON s.id = e.student_id
                        INNER JOIN academic_sessions a ON a.id = e.academic_session_id
                        WHERE 1=1" . scope_student_clause($conn, 0, 'e', 's') . " ORDER BY e.id DESC LIMIT 200");
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}
$editStudent = null;
$editEnrollmentId = (int)($_GET['edit'] ?? 0);
if ($editEnrollmentId > 0) {
    $stmt = $conn->prepare("SELECT s.id, s.enrollment_no, s.full_name, s.email, s.mobile, s.gender, s.department_id,
                                   e.id AS enrollment_id, e.academic_session_id, e.semester, e.section, e.status
                            FROM student_enrollments e INNER JOIN students s ON s.id=e.student_id
                            WHERE e.id=? LIMIT 1");
    $stmt->bind_param('i', $editEnrollmentId);
    $stmt->execute();
    $editStudent = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if ($editStudent && !scope_class_allows($conn, (int)$editStudent['academic_session_id'], (int)($editStudent['department_id'] ?? 0), (int)$editStudent['semester'], (string)$editStudent['section'])) {
        $editStudent = null;   // outside this role's scope
    }
}
$conn->close();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CO–PO Workspace — Students</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Page-specific styling: keeps the shared workspace shell and sidebar intact. */
        .students-page { --stu-ink:#17233b; --stu-muted:#6b7890; --stu-line:#e5eaf2; --stu-gold:#c89b3c; }
        .students-page .page-head { display:flex; align-items:flex-start; justify-content:space-between; gap:18px; margin-bottom:22px; }
        .students-page .eyebrow { display:inline-flex; align-items:center; gap:8px; color:#9a7424; font-size:11px; font-weight:800; letter-spacing:.12em; text-transform:uppercase; margin-bottom:8px; }
        .students-page .eyebrow:before { content:""; width:22px; height:2px; background:var(--stu-gold); border-radius:3px; }
        .students-page .page-head h1 { margin:0 0 7px; font-size:clamp(25px,3vw,32px); line-height:1.2; letter-spacing:-.035em; color:var(--stu-ink); }
        .students-page .page-head p { margin:0; color:var(--stu-muted); font-size:14px; line-height:1.65; }
        .students-page .page-tag { display:flex; align-items:center; gap:8px; border:1px solid #e9dfc8; color:#87651d; background:#fffaf0; border-radius:999px; padding:9px 13px; font-size:12px; font-weight:700; white-space:nowrap; }
        .students-page .page-tag span { display:inline-block; width:7px; height:7px; border-radius:50%; background:#c99b35; }
        .students-page .student-stats { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:14px; margin-bottom:20px; }
        .students-page .stat-card { display:flex; align-items:center; gap:13px; min-width:0; padding:17px 18px; background:#fff; border:1px solid var(--stu-line); border-radius:14px; box-shadow:0 4px 16px rgba(27,42,71,.035); }
        .students-page .stat-icon { display:grid; place-items:center; width:43px; height:43px; flex:0 0 43px; border-radius:12px; background:#f5f0e4; color:#9c7627; font-size:20px; }
        .students-page .stat-card:nth-child(2) .stat-icon { background:#eaf3ff; color:#376bb2; }
        .students-page .stat-card:nth-child(3) .stat-icon { background:#e9f7f0; color:#27805b; }
        .students-page .stat-label { color:var(--stu-muted); font-size:12px; font-weight:600; margin-bottom:4px; }
        .students-page .stat-value { color:var(--stu-ink); font-size:23px; line-height:1.1; font-weight:800; letter-spacing:-.03em; }
        .students-page .student-card { background:#fff; border:1px solid var(--stu-line); border-radius:16px; overflow:hidden; box-shadow:0 5px 22px rgba(27,42,71,.04); margin-bottom:20px; }
        .students-page .section-heading { display:flex; align-items:center; gap:12px; padding:20px 22px; border-bottom:1px solid var(--stu-line); background:linear-gradient(110deg,#fff 0%,#fcfbf8 100%); }
        .students-page .section-symbol { display:grid; place-items:center; width:39px; height:39px; flex:0 0 39px; border-radius:11px; background:#f5f0e4; color:#977020; font-size:18px; }
        .students-page .section-heading h2 { margin:0 0 4px; color:var(--stu-ink); font-size:16px; font-weight:800; letter-spacing:-.01em; }
        .students-page .section-heading p { margin:0; color:var(--stu-muted); font-size:12px; line-height:1.5; }
        .students-page .section-meta { margin-left:auto; color:#78849a; font-size:12px; white-space:nowrap; }
        .students-page .student-form { padding:22px; }
        .students-page .form-section-title { margin:0 0 15px; color:#34425c; font-size:12px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; }
        .students-page .form-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:17px 20px; }
        .students-page .field { min-width:0; }
        .students-page .field label { display:block; margin:0 0 8px; color:#34425c; font-size:12px; font-weight:700; }
        .students-page .field label .req { color:#bd7d22; margin-right:4px; }
        .students-page .field .control { display:block; width:100%; min-height:45px; box-sizing:border-box; padding:11px 13px; border:1px solid #dce3ed; border-radius:9px; background:#fff; color:#1d2b44; font:inherit; font-size:13px; outline:none; transition:border-color .18s,box-shadow .18s,background .18s; }
        .students-page .field .control::placeholder { color:#a0aabd; }
        .students-page .field .control:focus { border-color:#c69a3a; box-shadow:0 0 0 3px rgba(198,154,58,.14); }
        .students-page .field .hint { display:block; margin-top:6px; color:#8a96a9; font-size:11px; line-height:1.45; }
        .students-page .form-divider { height:1px; background:#edf0f5; margin:23px 0 20px; }
        .students-page .form-actions { display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-top:23px; }
        .students-page .form-note { display:flex; align-items:center; gap:7px; color:#8490a2; font-size:11px; }
        .students-page .form-buttons { display:flex; gap:10px; flex-wrap:wrap; }
        .students-page .btn { min-height:42px; border-radius:9px; padding:10px 16px; font-size:12px; font-weight:800; cursor:pointer; transition:transform .15s,box-shadow .15s; }
        .students-page .btn:hover { transform:translateY(-1px); }
        .students-page .btn-primary { border:1px solid #b68b2f; background:linear-gradient(135deg,#d5ad55,#bd8e30); color:#fff; box-shadow:0 4px 10px rgba(178,132,39,.18); }
        .students-page .btn-secondary { border:1px solid #dce3ed; background:#fff; color:#526078; }
        .students-page .notice { display:flex; align-items:flex-start; gap:10px; margin:0 0 18px; padding:13px 15px; border:1px solid #cde9d5; border-radius:10px; background:#f1fbf4; color:#21643a; font-size:13px; line-height:1.5; }
        .students-page .notice:before { content:"✓"; display:grid; place-items:center; width:20px; height:20px; flex:0 0 20px; border-radius:50%; background:#d6f1df; font-weight:900; }
        .students-page .notice.error { border-color:#f2d0d0; background:#fff5f5; color:#9b3030; }
        .students-page .notice.error:before { content:"!"; background:#fbe0e0; }
        .students-page .table-toolbar { display:flex; align-items:center; justify-content:space-between; gap:14px; padding:16px 20px; border-bottom:1px solid var(--stu-line); }
        .students-page .table-count { color:#77839a; font-size:12px; }
        .students-page .search-wrap { position:relative; width:min(100%,310px); }
        .students-page .search-wrap span { position:absolute; left:12px; top:50%; transform:translateY(-50%); color:#8995a8; font-size:16px; pointer-events:none; }
        .students-page .search-input { width:100%; box-sizing:border-box; min-height:39px; padding:9px 12px 9px 35px; border:1px solid #dfe5ee; border-radius:9px; background:#fbfcfe; color:#24324b; font-size:12px; outline:none; }
        .students-page .search-input:focus { border-color:#c69a3a; box-shadow:0 0 0 3px rgba(198,154,58,.12); }
        .students-page .table-wrap { overflow-x:auto; }
        .students-page table.data { width:100%; border-collapse:separate; border-spacing:0; min-width:760px; }
        .students-page table.data thead th { padding:13px 16px; background:#f8f9fc; color:#7a869b; border-bottom:1px solid #e8edf4; text-align:left; font-size:10px; font-weight:800; text-transform:uppercase; letter-spacing:.075em; white-space:nowrap; }
        .students-page table.data tbody td { padding:15px 16px; border-bottom:1px solid #edf0f5; color:#526078; font-size:12px; vertical-align:middle; }
        .students-page table.data tbody tr:last-child td { border-bottom:0; }
        .students-page table.data tbody tr:hover td { background:#fcfbf7; }
        .students-page .student-name { color:#26344d; font-weight:800; }
        .students-page .student-enrollment { color:#8b6a27; font-weight:800; font-variant-numeric:tabular-nums; }
        .students-page .status-pill { display:inline-flex; align-items:center; gap:6px; padding:5px 9px; border-radius:999px; background:#eaf8ef; color:#27734a; font-size:10px; font-weight:800; text-transform:capitalize; white-space:nowrap; }
        .students-page .status-pill:before { content:""; width:5px; height:5px; border-radius:50%; background:#38a66b; }
        .students-page .empty-state { padding:38px 20px!important; text-align:center; color:#7f8ba0!important; }
        .students-page .empty-icon { display:block; margin-bottom:8px; color:#c1cad8; font-size:28px; }
        .students-page .no-results { display:none; padding:25px; text-align:center; color:#7b879b; font-size:13px; }
        @media(max-width:900px) { .students-page .student-stats { grid-template-columns:repeat(3,minmax(0,1fr)); gap:9px; } .students-page .stat-card { padding:13px; } .students-page .stat-icon { width:36px; height:36px; flex-basis:36px; } }
        @media(max-width:650px) { .students-page .page-head { flex-direction:column; } .students-page .page-tag { align-self:flex-start; } .students-page .student-stats { grid-template-columns:1fr; } .students-page .stat-card { padding:12px 14px; } .students-page .stat-value { font-size:20px; } .students-page .section-heading { padding:16px; } .students-page .student-form { padding:17px; } .students-page .form-grid { grid-template-columns:1fr; gap:15px; } .students-page .table-toolbar { align-items:stretch; flex-direction:column; padding:14px; } .students-page .search-wrap { width:100%; } .students-page .form-actions { align-items:stretch; flex-direction:column; } .students-page .form-buttons { width:100%; } .students-page .form-buttons .btn { flex:1; } .students-page .section-meta { display:none; } }
    </style>
</head>
<body>
<div class="shell">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>

    <main class="main students-page">
        <header class="topbar">
            <div class="crumb">CO–PO Workspace / <b>Students</b></div>
            <div class="topbar-spacer"></div>
            <a class="term-pill" href="profile.php" style="text-decoration:none">Profile</a>
            <a class="term-pill" href="logout.php" style="text-decoration:none">Logout</a>
        </header>

        <div class="content">
            <section class="page active">
                <div class="page-head">
                    <div>
                        <div class="eyebrow">Student administration</div>
                        <h1>Students</h1>
                        <p>Register students, manage semester enrollment, and keep academic records organized.</p>
                    </div>
                    <div class="page-tag"><span></span> Academic records</div>
                </div>

                <?php if ($message !== ''): ?>
                    <div class="notice <?= $messageType === 'error' ? 'error' : '' ?>" role="status" aria-live="polite"><?= h($message) ?></div>
                <?php endif; ?>

                <div class="student-stats">
                    <div class="stat-card"><div class="stat-icon">♙</div><div><div class="stat-label">Enrollment records</div><div class="stat-value"><?= count($students) ?></div></div></div>
                    <div class="stat-card"><div class="stat-icon">▤</div><div><div class="stat-label">Academic sessions</div><div class="stat-value"><?= count($sessions) ?></div></div></div>
                    <div class="stat-card"><div class="stat-icon">▦</div><div><div class="stat-label">Departments</div><div class="stat-value"><?= count($departments) ?></div></div></div>
                </div>

                <div class="student-card">
                    <div class="section-heading">
                        <div class="section-symbol">＋</div>
                        <div><h2><?= $editStudent ? 'Edit student enrollment' : 'Register a student' ?></h2><p><?= $editStudent ? 'Update student details and academic enrollment.' : 'Add personal details and assign the academic enrollment.' ?></p></div>
                        <div class="section-meta">Required fields marked *</div>
                    </div>
                    <form method="post" action="students.php" class="student-form" autocomplete="on">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="<?= $editStudent ? 'update' : 'register' ?>">
                        <?php if ($editStudent): ?><input type="hidden" name="student_id" value="<?= (int)$editStudent['id'] ?>"><input type="hidden" name="enrollment_id" value="<?= (int)$editStudent['enrollment_id'] ?>"><?php endif; ?>
                        <h3 class="form-section-title">Personal information</h3>
                        <div class="form-grid">
                            <div class="field">
                                <label for="enrollment_no"><span class="req">*</span> Enrollment number</label>
                                <input id="enrollment_no" name="enrollment_no" class="control" required maxlength="80" placeholder="e.g. CSE2026001" autocomplete="off" value="<?= h($editStudent['enrollment_no'] ?? '') ?>">
                                <small class="hint">Use the unique enrollment number assigned by the institute.</small>
                            </div>
                            <div class="field">
                                <label for="full_name"><span class="req">*</span> Full name</label>
                                <input id="full_name" name="full_name" class="control" required maxlength="150" placeholder="Enter student's full name" autocomplete="name" value="<?= h($editStudent['full_name'] ?? '') ?>">
                            </div>
                            <div class="field">
                        <label for="email">Email address <span class="required">*</span></label>
                        <input id="email" name="email" type="email" class="control" maxlength="190" placeholder="student@example.com" autocomplete="email" value="<?= h($_POST['email'] ?? ($editStudent['email'] ?? '')) ?>" required>
                            </div>
                            <div class="field">
    <label for="mobile">Mobile Number <span class="required">*</span></label>
    <input
        id="mobile"
        name="mobile"
        type="tel"
        class="control"
        maxlength="10"
        placeholder="10-digit mobile number"
        autocomplete="tel"
        value="<?= h($_POST['mobile'] ?? ($editStudent['mobile'] ?? '')) ?>"
        pattern="[6-9][0-9]{9}"
        title="Enter a valid 10-digit Indian mobile number"
        required
    >
</div>
                            <div class="field">
                                <label for="gender">Gender</label>
                                <select id="gender" name="gender" class="control">
                                    <option value="" <?= empty($editStudent['gender']) ? 'selected' : '' ?>>Prefer not to say</option><option value="Female" <?= ($editStudent['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option><option value="Male" <?= ($editStudent['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option><option value="Other" <?= ($editStudent['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
                                </select>
                            </div>
                            <div class="field">
                                <label for="department_id">Department</label>
                                <select id="department_id" name="department_id" class="control">
                                    <option value="0">Not assigned</option>
                                    <?php foreach ($departments as $department): ?>
                                        <option value="<?= (int)$department['id'] ?>" <?= (int)($editStudent['department_id'] ?? 0) === (int)$department['id'] ? 'selected' : '' ?>><?= h($department['department_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (!$departments): ?><small class="hint">No department names were found. Check the departments table configuration.</small><?php endif; ?>
                            </div>
                        </div>
                        <div class="form-divider"></div>
                        <h3 class="form-section-title">Academic enrollment</h3>
                        <div class="form-grid">
                            <div class="field">
                                <label for="session_id"><span class="req">*</span> Academic session</label>
                                <select id="session_id" name="session_id" class="control" required>
                                    <option value="">Select academic session</option>
                                    <?php foreach ($sessions as $session): ?>
                                        <option value="<?= (int)$session['id'] ?>" <?= (int)($editStudent['academic_session_id'] ?? $selectedSessionId) === (int)$session['id'] ? 'selected' : '' ?>><?= h($session['session_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (!$sessions): ?><small class="hint">No academic sessions found. Add a session before registering students.</small><?php endif; ?>
                            </div>
                            <div class="field">
                                <label for="semester"><span class="req">*</span> Semester</label>
                                <select id="semester" name="semester" class="control" required>
                                    <option value="">Select semester</option>
                                    <?php for ($i = 1; $i <= 8; $i++): ?><option value="<?= $i ?>" <?= (int)($editStudent['semester'] ?? 0) === $i ? 'selected' : '' ?>>Semester <?= $i ?></option><?php endfor; ?>
                                </select>
                            </div>
                            <div class="field">
                                <label for="section"><span class="req">*</span> Section</label>
                                <input id="section" name="section" class="control" required maxlength="30" value="<?= h($editStudent['section'] ?? 'A') ?>" placeholder="e.g. A">
                            </div>
                        </div>
                        <div class="form-actions">
                            <div class="form-note"><span>ⓘ</span> Check the enrollment number and session before saving.</div>
                            <div class="form-buttons">
                                <button class="btn btn-secondary" type="reset">Clear form</button>
                                <?php if ($editStudent): ?><a class="btn btn-secondary" href="students.php">Cancel edit</a><?php endif; ?>
                                <button class="btn btn-primary" type="submit" <?= !$sessions ? 'disabled' : '' ?>><?= $editStudent ? 'Save changes' : '＋ &nbsp; Register student' ?></button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="student-card">
                    <div class="section-heading">
                        <div class="section-symbol">☷</div>
                        <div><h2>Registered students</h2><p>Recently added student enrollment records.</p></div>
                        <div class="section-meta">Latest 200 records</div>
                    </div>
                    <div class="table-toolbar">
                        <div class="table-count"><strong><?= count($students) ?></strong> record<?= count($students) === 1 ? '' : 's' ?> loaded</div>
                        <label class="search-wrap"><span>⌕</span><input type="search" id="studentSearch" class="search-input" placeholder="Search name, enrollment, session…" aria-label="Search students"></label>
                    </div>
                    <div class="table-wrap">
                        <table class="data" id="studentsTable">
                            <thead><tr><th>Enrollment no.</th><th>Student name</th><th>Email</th><th>Session</th><th>Semester</th><th>Section</th><th>Status</th><th>Action</th></tr></thead>
                            <tbody>
                            <?php if (!$students): ?>
                                <tr><td colspan="8" class="empty-state"><span class="empty-icon">♙</span><strong>No students registered yet</strong><br>Use the form above to add the first student record.</td></tr>
                            <?php else: foreach ($students as $student): ?>
                                <tr>
                                    <td><span class="student-enrollment"><?= h($student['enrollment_no']) ?></span></td>
                                    <td><span class="student-name"><?= h($student['full_name']) ?></span></td>
                                    <td><?= h($student['email'] ?: '—') ?></td>
                                    <td><?= h($student['session_name'] ?: '—') ?></td>
                                    <td><?= $student['semester'] !== null ? (int)$student['semester'] : '—' ?></td>
                                    <td><?= h($student['section'] ?: '—') ?></td>
                                    <td><span class="status-pill"><?= h($student['status'] ?: 'Not enrolled') ?></span></td>
                                   

<td>
    <div style="display: flex; flex-wrap: wrap; gap: 6px; align-items: center;">
        <a class="btn btn-secondary"
           href="students.php?edit=<?= (int)$student['enrollment_id'] ?>"
           aria-label="Edit <?= h($student['full_name']) ?>">
            Edit
        </a>

        <form method="POST" action="students.php" style="margin: 0;"
              onsubmit="return confirm('Delete this student enrollment?');">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="enrollment_id"
                   value="<?= (int)$student['enrollment_id'] ?>">
            <button type="submit" class="btn btn-secondary">Delete</button>
        </form>
    </div>
</td>

</tr>

                            <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                        <div id="noStudentResults" class="no-results">No matching student records found.</div>
                    </div>
                </div>
            </section>
        </div>
    </main>
</div>
<script>
(function () {
    const search = document.getElementById('studentSearch');
    const table = document.getElementById('studentsTable');
    const empty = document.getElementById('noStudentResults');
    if (!search || !table || !empty) return;
    search.addEventListener('input', function () {
        const query = this.value.trim().toLowerCase();
        const rows = Array.from(table.querySelectorAll('tbody tr'));
        let visible = 0;
        rows.forEach(function (row) {
            const isEmptyMessage = row.querySelector('.empty-state');
            if (isEmptyMessage) return;
            const match = row.textContent.toLowerCase().includes(query);
            row.style.display = match ? '' : 'none';
            if (match) visible++;
        });
        empty.style.display = query && visible === 0 && rows.some(row => !row.querySelector('.empty-state')) ? 'block' : 'none';
    });
})();
</script>
</body>
</html>
