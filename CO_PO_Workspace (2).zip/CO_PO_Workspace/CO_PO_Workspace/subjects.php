<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('subjects.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$user = current_user() ?? [];
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf_token'];
$message = '';
$messageType = 'success';
$editSubject = null;

function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function redirect_subjects(): never { header('Location: subjects.php'); exit; }

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        if (!hash_equals($_SESSION['csrf_token'] ?? '', (string)($_POST['csrf_token'] ?? ''))) {
            throw new RuntimeException('Your session token expired. Refresh the page and try again.');
        }
        if (!role_is('principal', 'hod')) throw new RuntimeException('Only the HOD or Principal can add or change subjects. Subject incharges manage course outcomes on the Course Outcomes page.');
        $action = (string)($_POST['action'] ?? 'save');
        $id = filter_input(INPUT_POST, 'subject_id', FILTER_VALIDATE_INT) ?: 0;

        if ($action === 'delete') {
            if ($id < 1) throw new RuntimeException('Invalid subject selected.');
            if (!scope_can_use_subject($conn, $id)) throw new RuntimeException('Subject not found.');
            $check = $conn->prepare('SELECT COUNT(*) AS total FROM assessment_components WHERE subject_id = ?');
            $check->bind_param('i', $id); $check->execute();
            $components = (int)$check->get_result()->fetch_assoc()['total'];
            $check = $conn->prepare('SELECT COUNT(*) AS total FROM course_outcomes co JOIN marks m ON m.course_outcome_id = co.id WHERE co.subject_id = ?');
            $check->bind_param('i', $id); $check->execute();
            $marks = (int)$check->get_result()->fetch_assoc()['total'];
            if ($components > 0 || $marks > 0) throw new RuntimeException('This subject already has assessment or marks data. It cannot be deleted; keep the records for audit safety.');
            $stmt = $conn->prepare('DELETE FROM subjects WHERE id = ?');
            $stmt->bind_param('i', $id); $stmt->execute();
            redirect_subjects();
        }

        $code = strtoupper(trim((string)($_POST['subject_code'] ?? '')));
        $name = trim((string)($_POST['subject_name'] ?? ''));
        $sessionId = filter_input(INPUT_POST, 'academic_session_id', FILTER_VALIDATE_INT) ?: 0;
        $departmentId = filter_input(INPUT_POST, 'department_id', FILTER_VALIDATE_INT) ?: 0;
        if (role_is('hod')) $departmentId = user_department_id($conn);   // an HOD only manages their own department
        $semester = filter_input(INPUT_POST, 'semester', FILTER_VALIDATE_INT) ?: 0;
        $creditsRaw = trim((string)($_POST['credits'] ?? '0'));
        $credits = filter_var($creditsRaw, FILTER_VALIDATE_FLOAT);
        $type = (string)($_POST['subject_type'] ?? 'Core');
        $coCount = filter_input(INPUT_POST, 'co_count', FILTER_VALIDATE_INT) ?: 5;
        $validTypes = ['Core','Elective','Theory','Practical','Other'];
        if ($code === '' || $name === '' || $sessionId < 1 || $departmentId < 1 || $semester < 1 || $semester > 8) throw new RuntimeException('Please complete all required fields. Semester must be between 1 and 8.');
        if (mb_strlen($code) > 40 || mb_strlen($name) > 180) throw new RuntimeException('Subject code or name is too long.');
        if ($credits === false || $credits < 0 || $credits > 99.9) throw new RuntimeException('Credits must be a number between 0 and 99.9.');
        if (!in_array($type, $validTypes, true)) throw new RuntimeException('Select a valid subject type.');
        if ($coCount < 1 || $coCount > 12) throw new RuntimeException('Course outcomes must be between 1 and 12.');

        $stmt = $conn->prepare('SELECT id FROM academic_sessions WHERE id = ?');
        $stmt->bind_param('i', $sessionId); $stmt->execute();
        if (!$stmt->get_result()->fetch_assoc()) throw new RuntimeException('Selected academic session was not found.');
        $stmt = $conn->prepare('SELECT id FROM departments WHERE id = ?');
        $stmt->bind_param('i', $departmentId); $stmt->execute();
        if (!$stmt->get_result()->fetch_assoc()) throw new RuntimeException('Selected department was not found.');

        if ($id > 0) {
            $stmt = $conn->prepare('SELECT id FROM subjects WHERE id = ?' . scope_subject_clause());
            $stmt->bind_param('i', $id); $stmt->execute();
            if (!$stmt->get_result()->fetch_assoc()) throw new RuntimeException('Subject not found.');
            $stmt = $conn->prepare('SELECT COUNT(*) total FROM marks m JOIN assessment_components ac ON ac.id=m.assessment_component_id WHERE ac.subject_id=?');
            $stmt->bind_param('i', $id); $stmt->execute();
            if ((int)$stmt->get_result()->fetch_assoc()['total'] > 0) throw new RuntimeException('This subject has saved marks. Its core details cannot be edited after marks entry starts.');
            $stmt = $conn->prepare('UPDATE subjects SET subject_code=?, subject_name=?, department_id=?, academic_session_id=?, semester=?, credits=?, subject_type=? WHERE id=?');
            $stmt->bind_param('ssiiidsi', $code, $name, $departmentId, $sessionId, $semester, $credits, $type, $id);
            $stmt->execute();
            $stmt = $conn->prepare('SELECT COUNT(*) total FROM course_outcomes WHERE subject_id=?');
            $stmt->bind_param('i', $id); $stmt->execute(); $existingCOs=(int)$stmt->get_result()->fetch_assoc()['total'];
            if ($existingCOs === 0) {
                for ($i=1; $i <= $coCount; $i++) {
                    $coCode='CO'.$i; $description='Course outcome '.$i.' for '.$name;
                    $stmt=$conn->prepare('INSERT INTO course_outcomes(subject_id,co_code,description) VALUES(?,?,?)');
                    $stmt->bind_param('iss',$id,$coCode,$description); $stmt->execute();
                }
            }
        } else {
            $inchargeId = 0;   // the HOD assigns the subject incharge afterwards under Faculty & Access
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare('INSERT INTO subjects(subject_code,subject_name,department_id,academic_session_id,semester,credits,subject_type,subject_incharge_id) VALUES(?,?,?,?,?,?,?,NULLIF(?,0))');
                $stmt->bind_param('ssiiidsi', $code, $name, $departmentId, $sessionId, $semester, $credits, $type, $inchargeId);
                $stmt->execute(); $newId=(int)$conn->insert_id;
                for ($i=1; $i <= $coCount; $i++) {
                    $coCode='CO'.$i; $description='Course outcome '.$i.' for '.$name;
                    $coStmt=$conn->prepare('INSERT INTO course_outcomes(subject_id,co_code,description) VALUES(?,?,?)');
                    $coStmt->bind_param('iss',$newId,$coCode,$description); $coStmt->execute();
                }
                $conn->commit();
            } catch (Throwable $e) { $conn->rollback(); throw $e; }
        }
        redirect_subjects();
    }
} catch (Throwable $e) {
    $message = $e instanceof mysqli_sql_exception && (int)$e->getCode() === 1062
        ? 'That subject code already exists for the selected session and semester.'
        : $e->getMessage();
    $messageType = 'error';
}

$sessions = $conn->query('SELECT id, session_name, is_active FROM academic_sessions ORDER BY is_active DESC, session_name DESC')->fetch_all(MYSQLI_ASSOC);
$departments = scope_departments($conn);
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT) ?: 0;
if ($editId > 0) {
    $stmt=$conn->prepare('SELECT * FROM subjects WHERE id=?' . scope_subject_clause()); $stmt->bind_param('i',$editId); $stmt->execute(); $editSubject=$stmt->get_result()->fetch_assoc();
    if ($editSubject) { $stmt=$conn->prepare('SELECT COUNT(*) total FROM course_outcomes WHERE subject_id=?'); $stmt->bind_param('i',$editId); $stmt->execute(); $editSubject['co_count']=(int)$stmt->get_result()->fetch_assoc()['total']; }
}
$filterSession = filter_input(INPUT_GET, 'session', FILTER_VALIDATE_INT) ?: 0;
$filterSemester = filter_input(INPUT_GET, 'semester', FILTER_VALIDATE_INT) ?: 0;
$search = trim((string)($_GET['q'] ?? ''));
$sql = 'SELECT s.id,s.subject_code,s.subject_name,s.semester,s.credits,s.subject_type,s.academic_session_id,s.department_id,a.session_name,d.name department,COUNT(DISTINCT co.id) co_count FROM subjects s JOIN academic_sessions a ON a.id=s.academic_session_id LEFT JOIN departments d ON d.id=s.department_id LEFT JOIN course_outcomes co ON co.subject_id=s.id WHERE 1=1';
$params=[]; $types='';
if ($filterSession > 0) { $sql .= ' AND s.academic_session_id=?'; $types.='i'; $params[]=$filterSession; }
if ($filterSemester > 0) { $sql .= ' AND s.semester=?'; $types.='i'; $params[]=$filterSemester; }
if ($search !== '') { $sql .= ' AND (s.subject_code LIKE ? OR s.subject_name LIKE ? OR d.name LIKE ?)'; $types.='sss'; $like='%'.$search.'%'; array_push($params,$like,$like,$like); }
$sql .= scope_subject_clause('s');
$sql .= ' GROUP BY s.id ORDER BY a.session_name DESC,s.semester,s.subject_code';
$stmt=$conn->prepare($sql); if ($params) $stmt->bind_param($types,...$params); $stmt->execute(); $subjects=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$activeSession = 0; foreach($sessions as $ss) if((int)$ss['is_active']===1){$activeSession=(int)$ss['id'];break;}
$selectedSession = $editSubject ? (int)$editSubject['academic_session_id'] : ($filterSession ?: $activeSession ?: (int)($sessions[0]['id'] ?? 0));
$selectedDepartment = $editSubject ? (int)$editSubject['department_id'] : (int)($departments[0]['id'] ?? 0);
$coCountValue = $editSubject ? max(1,(int)$editSubject['co_count']) : 5;
$subjectCount = count($subjects);
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>CO–PO Workspace — Subjects</title><link rel="stylesheet" href="css/style.css">
<style>
/* Small structural refinements only; existing palette and components are retained. */
.subject-form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.subject-form-grid.two{grid-template-columns:repeat(2,minmax(0,1fr));margin-top:16px}.subject-toolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:14px 20px;border-bottom:1px solid var(--line2)}.subject-toolbar .control{min-width:150px}.subject-toolbar .search-control{flex:1;min-width:190px}.subject-actions{display:flex;gap:7px;justify-content:flex-end;white-space:nowrap}.subject-actions form{margin:0}.subject-note{padding:18px 20px;color:#53627a;line-height:1.65}.notice{padding:12px 15px;border:1px solid var(--line);border-radius:5px;margin:0 0 18px;background:#fff}.notice.success{border-color:#c5dfd2;background:#f0f8f3;color:#246548}.notice.error{border-color:#f0cbc3;background:#fff4f1;color:#9b392a}.empty-state{text-align:center;padding:28px 16px;color:var(--muted)}.muted-small{font-size:11px;color:var(--muted)}@media(max-width:1050px){.subject-form-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.content{padding:22px 20px}}@media(max-width:700px){body{min-width:0}.sidebar{width:210px;min-width:210px}.subject-form-grid,.subject-form-grid.two{grid-template-columns:1fr}.topbar{padding:0 14px;gap:8px}.content{padding:16px 12px}.subject-toolbar{padding:12px}.subject-toolbar>*{width:100%}.subject-actions{justify-content:flex-start}}
</style></head><body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main"><header class="topbar"><div class="crumb">CO–PO Workspace / <b>Subjects</b></div><div class="topbar-spacer"></div><div class="term-pill"><span class="dot"></span><?=h(($sessions[0]['session_name'] ?? 'No session').' · Academic session')?></div><a class="term-pill" href="profile.php" style="text-decoration:none">Profile</a><a class="term-pill" href="logout.php" style="text-decoration:none">Logout</a></header>
<div class="content"><section class="page active"><div class="page-head"><div><div class="eyebrow">ACADEMIC SETUP</div><h1><?= $editSubject ? 'Edit subject' : 'Subjects' ?></h1><p>Manage subject offerings by academic session, department and semester. CO rows are created with each new subject.</p></div></div>
<?php if($message!==''): ?><div class="notice <?=h($messageType)?>" role="alert"><?=h($message)?></div><?php endif; ?>
<?php if (role_is('principal', 'hod')): ?><div class="two-col"><div class="card"><div class="card-head"><div><h2><?= $editSubject ? 'Update subject details' : 'Subject details' ?></h2><span>Required fields are marked with *</span></div></div><div class="panel-body"><form method="post" action="subjects.php<?= $editSubject ? '?edit='.(int)$editSubject['id'] : '' ?>"><input type="hidden" name="csrf_token" value="<?=h($csrf)?>"><input type="hidden" name="action" value="save"><input type="hidden" name="subject_id" value="<?= (int)($editSubject['id'] ?? 0) ?>">
<div class="subject-form-grid"><div class="field"><label><span class="req">*</span> Academic session</label><select class="control" name="academic_session_id" required><?php foreach($sessions as $ss): ?><option value="<?=(int)$ss['id']?>" <?=((int)$ss['id']===$selectedSession?'selected':'')?>><?=h($ss['session_name'])?><?=((int)$ss['is_active']===1?' · Active':'')?></option><?php endforeach; ?></select></div><div class="field"><label><span class="req">*</span> Department</label><select class="control" name="department_id" required><?php foreach($departments as $dep): ?><option value="<?=(int)$dep['id']?>" <?=((int)$dep['id']===$selectedDepartment?'selected':'')?>><?=h($dep['name'])?></option><?php endforeach; ?></select></div><div class="field"><label><span class="req">*</span> Semester</label><select class="control" name="semester" required><?php for($i=1;$i<=8;$i++): ?><option value="<?=$i?>" <?=((int)($editSubject['semester'] ?? 5)===$i?'selected':'')?>>Semester <?=$i?></option><?php endfor; ?></select></div></div>
<div class="subject-form-grid two"><div class="field"><label><span class="req">*</span> Subject name</label><input class="control" name="subject_name" maxlength="180" value="<?=h($editSubject['subject_name'] ?? '')?>" placeholder="e.g. Database Management Systems" required></div><div class="field"><label><span class="req">*</span> Subject code</label><input class="control" name="subject_code" maxlength="40" value="<?=h($editSubject['subject_code'] ?? '')?>" placeholder="e.g. CS501" required></div></div>
<div class="subject-form-grid two"><div class="field"><label><span class="req">*</span> Number of course outcomes</label><select class="control" name="co_count" <?= $editSubject && (int)$editSubject['co_count']>0 ? 'disabled' : '' ?>><?php for($i=1;$i<=12;$i++): ?><option value="<?=$i?>" <?=($coCountValue===$i?'selected':'')?>><?=$i?> (CO1–CO<?=$i?>)</option><?php endfor; ?></select><?php if($editSubject && (int)$editSubject['co_count']>0): ?><input type="hidden" name="co_count" value="<?=$coCountValue?>"><?php endif; ?><div class="hint">New subjects automatically get CO codes; edit existing CO descriptions later in the CO setup workflow.</div></div><div class="field"><label>Credits</label><input class="control" type="number" min="0" max="99.9" step="0.5" name="credits" value="<?=h($editSubject['credits'] ?? '0')?>" placeholder="e.g. 4"></div><div class="field"><label>Subject type</label><select class="control" name="subject_type"><?php foreach(['Core','Elective','Theory','Practical','Other'] as $t): ?><option value="<?=h($t)?>" <?=((($editSubject['subject_type'] ?? 'Core')===$t)?'selected':'')?>><?=h($t)?></option><?php endforeach; ?></select></div></div>
<div class="form-actions"><button type="submit" class="btn btn-gold">＋ <?= $editSubject ? 'Update subject' : 'Save subject' ?></button><?php if($editSubject): ?> <a class="btn btn-outline" href="subjects.php">Cancel edit</a><?php endif; ?></div></form></div></div>
<div class="card"><div class="card-head"><div><h2>Subject setup guide</h2><span>Keep academic records consistent</span></div></div><div class="subject-note"><p>Each subject belongs to one session, department and semester.</p><p>When a subject is created, the system generates the selected number of CO records. You can later update each CO's actual description before entering marks and mapping POs.</p><p><b>Record safety:</b> a subject with saved assessment/marks data is protected from deletion or core-detail changes.</p></div></div></div><?php endif; ?>
<div class="card" style="margin-top:20px"><div class="card-head"><div><h2>Subject list</h2><span>Search and filter the current subject offerings</span></div><span class="badge grey"><?=$subjectCount?> subject<?=$subjectCount===1?'':'s'?></span></div>
<form class="subject-toolbar" method="get" action="subjects.php"><input class="control search-control" type="search" name="q" value="<?=h($search)?>" placeholder="Search subject code, name or department"><select class="control" name="session"><option value="0">All sessions</option><?php foreach($sessions as $ss): ?><option value="<?=(int)$ss['id']?>" <?=($filterSession===(int)$ss['id']?'selected':'')?>><?=h($ss['session_name'])?></option><?php endforeach; ?></select><select class="control" name="semester"><option value="0">All semesters</option><?php for($i=1;$i<=8;$i++): ?><option value="<?=$i?>" <?=($filterSemester===$i?'selected':'')?>>Semester <?=$i?></option><?php endfor; ?></select><button class="btn btn-outline" type="submit">Filter</button><a class="btn btn-outline" href="subjects.php">Reset</a></form>
<div class="table-wrap"><table class="data"><thead><tr><th>#</th><th>Session</th><th>Department</th><th>Semester</th><th>Subject</th><th>COs</th><th>Credits</th><th>Type</th><th style="text-align:right">Actions</th></tr></thead><tbody>
<?php if(!$subjects): ?><tr><td colspan="9"><div class="empty-state">No subjects found. Add a subject using the form above.</div></td></tr><?php else: foreach($subjects as $i=>$s): ?><tr><td class="row-index"><?=str_pad((string)($i+1),2,'0',STR_PAD_LEFT)?></td><td><?=h($s['session_name'])?></td><td><?=h($s['department'] ?? '—')?></td><td>Semester <?= (int)$s['semester'] ?></td><td><b><?=h($s['subject_name'])?></b><div class="muted-small"><?=h($s['subject_code'])?></div></td><td class="num"><?=(int)$s['co_count']?></td><td><?=h(number_format((float)$s['credits'],1))?></td><td><span class="badge gold"><?=h($s['subject_type'])?></span></td><td><div class="subject-actions"><?php if (role_is('principal', 'hod')): ?><a class="btn btn-outline" href="subjects.php?edit=<?=(int)$s['id']?>" style="padding:6px 10px">Edit</a><form method="post" onsubmit="return confirm('Delete this subject? This is only allowed when it has no assessment or marks records.');"><input type="hidden" name="csrf_token" value="<?=h($csrf)?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="subject_id" value="<?=(int)$s['id']?>"><button class="btn btn-outline" type="submit" style="padding:6px 10px">Delete</button></form><?php endif; ?><a class="btn btn-outline" href="course-outcomes.php?session_id=<?=(int)$s['academic_session_id']?>&semester=<?=(int)$s['semester']?>&subject_id=<?=(int)$s['id']?>" style="padding:6px 10px">COs</a></div></td></tr><?php endforeach; endif; ?>
</tbody></table></div></div></section></div></main></div></body></html>
