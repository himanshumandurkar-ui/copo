<?php
// Update these values to match your local XAMPP MySQL setup.
define('DB_HOST', 'localhost');
define('DB_NAME', 'sspace_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_NAME', 'CO–PO Workspace');
