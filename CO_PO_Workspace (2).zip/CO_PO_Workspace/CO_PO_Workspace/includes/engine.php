<?php
/*
 * CO / PO attainment engine — follows the workflow's processing pipeline:
 *   1. Marks validation        (0 <= marks <= component maximum; bad rows are excluded and reported)
 *   2. Total / percentage      (per student, per CO, across all assessment components)
 *   3. CO attainment           (share of assessed students reaching the target %, converted to level 0-3)
 *   4. CO-PO mapping           (0/1/2/3 mapping strength from the mapping matrix)
 *   5. PO attainment           (mapping-weighted average of the CO levels)
 *   6. Analytics               (stored in attainment_results; charts/reports read from there)
 *
 * The thresholds live in attainment_settings (college default + optional per-department override) and
 * are editable on the CO/PO Attainment page. The defaults (target 60%, level 3 >= 70%, level 2 >= 60%,
 * level 1 >= 50% of students) are a COMMON NBA-style scheme, not an official rule: confirm them with
 * your college's accreditation cell before relying on the numbers.
 */

function engine_default_settings(): array {
    return ['target_percent' => 60.0, 'level3_min' => 70.0, 'level2_min' => 60.0, 'level1_min' => 50.0,
            'co_target_level' => 2.0, 'po_target_level' => 2.0];
}

/** Department-specific rule row if present, else the college default row, else built-in defaults. */
function engine_settings(mysqli $conn, ?int $departmentId): array {
    $out = engine_default_settings();
    try {
        $row = null;
        if ($departmentId) {
            $stmt = $conn->prepare('SELECT * FROM attainment_settings WHERE department_id=? LIMIT 1');
            $stmt->bind_param('i', $departmentId); $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
        }
        if (!$row) $row = $conn->query('SELECT * FROM attainment_settings WHERE department_id IS NULL ORDER BY id LIMIT 1')->fetch_assoc();
        if ($row) foreach (array_keys($out) as $k) if (isset($row[$k])) $out[$k] = (float)$row[$k];
    } catch (Throwable $e) { /* table missing before migration: use defaults */ }
    return $out;
}

function engine_level_for_percent(float $percentOfStudents, array $s): int {
    if ($percentOfStudents >= $s['level3_min']) return 3;
    if ($percentOfStudents >= $s['level2_min']) return 2;
    if ($percentOfStudents >= $s['level1_min']) return 1;
    return 0;
}

/**
 * Run the full pipeline for one subject and persist CO + PO results.
 * Returns ['ok'=>bool, 'error'=>string, 'stages'=>[...], 'co'=>[...], 'po'=>[...], 'warnings'=>[...]].
 */
function engine_calculate_subject(mysqli $conn, int $subjectId, int $sessionId, int $semester): array {
    $res = ['ok' => false, 'error' => '', 'stages' => [], 'co' => [], 'po' => [], 'warnings' => []];

    $stmt = $conn->prepare('SELECT id, department_id FROM subjects WHERE id=? AND academic_session_id=? AND semester=?');
    $stmt->bind_param('iii', $subjectId, $sessionId, $semester); $stmt->execute();
    $subject = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$subject) { $res['error'] = 'Selected subject does not match the session and semester.'; return $res; }
    $settings = engine_settings($conn, $subject['department_id'] !== null ? (int)$subject['department_id'] : null);
    $res['settings'] = $settings;

    // course outcomes
    $stmt = $conn->prepare('SELECT id, co_code FROM course_outcomes WHERE subject_id=? ORDER BY id');
    $stmt->bind_param('i', $subjectId); $stmt->execute();
    $cos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    if (!$cos) { $res['error'] = 'No Course Outcomes found for this subject. Add COs first.'; return $res; }

    // assessment components
    $stmt = $conn->prepare('SELECT COUNT(*) n FROM assessment_components WHERE subject_id=?');
    $stmt->bind_param('i', $subjectId); $stmt->execute();
    $componentCount = (int)$stmt->get_result()->fetch_assoc()['n']; $stmt->close();
    if ($componentCount === 0) { $res['error'] = 'No assessments found for this subject. Add assessments and enter marks first.'; return $res; }

    // ---------------------------------------------------------------- 1. validation
    $stmt = $conn->prepare("SELECT m.enrollment_id, m.course_outcome_id, m.marks_obtained, ac.max_marks, ac.component_name
        FROM marks m
        JOIN assessment_components ac ON ac.id=m.assessment_component_id
        JOIN student_enrollments se ON se.id=m.enrollment_id
        WHERE ac.subject_id=? AND se.academic_session_id=? AND se.semester=? AND se.status='active' AND m.course_outcome_id IS NOT NULL");
    $stmt->bind_param('iii', $subjectId, $sessionId, $semester); $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();

    $invalid = 0; $valid = [];
    foreach ($rows as $r) {
        $got = (float)$r['marks_obtained']; $max = (float)$r['max_marks'];
        if ($got < 0 || $got > $max || $max <= 0) { $invalid++; continue; }   // rule: 0 <= marks <= max
        $valid[] = $r;
    }
    $res['stages'][] = ['Marks validation', count($valid) . ' valid mark entries' . ($invalid ? ", {$invalid} excluded (out of range)" : ''), $invalid ? 'warn' : 'ok'];
    if ($invalid) $res['warnings'][] = "{$invalid} mark entries were outside 0–maximum and were excluded from the calculation.";
    if (!$valid) { $res['error'] = 'No valid marks recorded for this subject yet.'; return $res; }

    // ---------------------------------------------------------------- 2. totals / percentage
    $perStudentCo = [];   // [co_id][enrollment_id] => [obtained, max]
    foreach ($valid as $r) {
        $c = (int)$r['course_outcome_id']; $e = (int)$r['enrollment_id'];
        if (!isset($perStudentCo[$c][$e])) $perStudentCo[$c][$e] = [0.0, 0.0];
        $perStudentCo[$c][$e][0] += (float)$r['marks_obtained'];
        $perStudentCo[$c][$e][1] += (float)$r['max_marks'];
    }
    $studentsAssessed = [];
    foreach ($perStudentCo as $byStudent) foreach ($byStudent as $e => $_) $studentsAssessed[$e] = true;
    $res['stages'][] = ['Total / percentage', count($studentsAssessed) . ' students with recorded marks', 'ok'];

    // ---------------------------------------------------------------- 3. CO attainment
    $coLevels = []; $coResults = [];
    foreach ($cos as $co) {
        $cid = (int)$co['id'];
        $assessed = 0; $attained = 0;
        foreach (($perStudentCo[$cid] ?? []) as [$got, $max]) {
            if ($max <= 0) continue;
            $assessed++;
            if (($got / $max) * 100 >= $settings['target_percent']) $attained++;
        }
        if ($assessed === 0) {
            $res['warnings'][] = $co['co_code'] . ' has no marks recorded, so it was not calculated.';
            continue;
        }
        $pct = round($attained / $assessed * 100, 2);
        $level = engine_level_for_percent($pct, $settings);
        $coLevels[$cid] = $level;
        $coResults[] = ['id' => $cid, 'code' => $co['co_code'], 'percent' => $pct, 'level' => $level, 'assessed' => $assessed, 'attained' => $attained];
    }
    $res['co'] = $coResults;
    $res['stages'][] = ['CO attainment', count($coResults) . ' of ' . count($cos) . ' outcomes calculated (target ' . rtrim(rtrim(number_format($settings['target_percent'], 2), '0'), '.') . '% per student)', $coResults ? 'ok' : 'warn'];

    // ---------------------------------------------------------------- 4. CO-PO mapping
    $stmt = $conn->prepare('SELECT m.po_number, m.mapping_level, m.course_outcome_id FROM co_po_mapping m JOIN course_outcomes co ON co.id=m.course_outcome_id WHERE co.subject_id=? AND m.mapping_level>0');
    $stmt->bind_param('i', $subjectId); $stmt->execute();
    $mappings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    $res['stages'][] = ['CO–PO mapping', count($mappings) . ' mapped links (levels 1–3)', $mappings ? 'ok' : 'warn'];
    if (!$mappings) $res['warnings'][] = 'No CO–PO mapping saved for this subject, so PO attainment could not be derived.';

    // ---------------------------------------------------------------- 5. PO attainment
    $poAcc = [];   // po => [sum(weight*level), sum(weight)]
    foreach ($mappings as $m) {
        $cid = (int)$m['course_outcome_id'];
        if (!isset($coLevels[$cid])) continue;
        $po = (int)$m['po_number']; $w = (int)$m['mapping_level'];
        if (!isset($poAcc[$po])) $poAcc[$po] = [0.0, 0.0];
        $poAcc[$po][0] += $w * $coLevels[$cid];
        $poAcc[$po][1] += $w;
    }
    ksort($poAcc);
    $poResults = [];
    foreach ($poAcc as $po => [$weighted, $weight]) {
        if ($weight <= 0) continue;
        $lvl = round($weighted / $weight, 2);
        $poResults[] = ['po' => $po, 'code' => 'PO' . $po, 'level' => $lvl, 'percent' => round($lvl / 3 * 100, 2)];
    }
    $res['po'] = $poResults;
    $res['stages'][] = ['PO attainment', count($poResults) . ' program outcomes derived', $poResults ? 'ok' : 'warn'];

    // ---------------------------------------------------------------- 6. persist (history is kept: only this subject/session/semester rows are upserted)
    try {
        $conn->begin_transaction();
        $save = $conn->prepare("INSERT INTO attainment_results (subject_id, academic_session_id, semester, outcome_type, outcome_code, attainment_percent, level_value, students_total, students_attained)
            VALUES (?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE attainment_percent=VALUES(attainment_percent), level_value=VALUES(level_value), students_total=VALUES(students_total), students_attained=VALUES(students_attained), calculated_at=CURRENT_TIMESTAMP");
        foreach ($coResults as $c) {
            $type = 'CO'; $code = $c['code']; $pct = $c['percent']; $lvl = (float)$c['level']; $tot = $c['assessed']; $att = $c['attained'];
            $save->bind_param('iiissddii', $subjectId, $sessionId, $semester, $type, $code, $pct, $lvl, $tot, $att);
            $save->execute();
        }
        foreach ($poResults as $p) {
            $type = 'PO'; $code = $p['code']; $pct = $p['percent']; $lvl = $p['level']; $tot = null; $att = null;
            $save->bind_param('iiissddii', $subjectId, $sessionId, $semester, $type, $code, $pct, $lvl, $tot, $att);
            $save->execute();
        }
        $save->close();
        // remove stale PO rows (e.g. a mapping was removed since the last run) for THIS subject only
        $keep = array_map(fn($p) => $p['code'], $poResults);
        $del = $conn->prepare("SELECT id, outcome_code FROM attainment_results WHERE subject_id=? AND academic_session_id=? AND semester=? AND outcome_type='PO'");
        $del->bind_param('iii', $subjectId, $sessionId, $semester); $del->execute();
        $existing = $del->get_result()->fetch_all(MYSQLI_ASSOC); $del->close();
        foreach ($existing as $ex) {
            if (!in_array($ex['outcome_code'], $keep, true)) {
                $rm = $conn->prepare('DELETE FROM attainment_results WHERE id=?'); $rid = (int)$ex['id'];
                $rm->bind_param('i', $rid); $rm->execute(); $rm->close();
            }
        }
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        $res['error'] = 'Calculation could not be saved. Run the database upgrade (migrate.php) and try again.';
        error_log('engine_calculate_subject: ' . $e->getMessage());
        return $res;
    }
    $res['stages'][] = ['Analytics & reports', 'Results saved; charts and reports are now up to date', 'ok'];
    $res['ok'] = true;
    return $res;
}

/**
 * Department / college aggregation of saved PO results.
 * Each PO = average of that PO's level across subjects that map to it (session-wide).
 * $departmentId null = whole college. Returns [po_number => ['level'=>float, 'subjects'=>int]].
 */
function engine_po_rollup(mysqli $conn, int $sessionId, ?int $departmentId, ?int $semester = null): array {
    $sql = "SELECT CAST(SUBSTRING(ar.outcome_code,3) AS UNSIGNED) AS po, AVG(ar.level_value) AS lvl, COUNT(DISTINCT ar.subject_id) AS subs
            FROM attainment_results ar JOIN subjects s ON s.id=ar.subject_id
            WHERE ar.outcome_type='PO' AND ar.academic_session_id=? AND ar.level_value IS NOT NULL";
    $types = 'i'; $params = [$sessionId];
    if ($departmentId) { $sql .= ' AND s.department_id=?'; $types .= 'i'; $params[] = $departmentId; }
    if ($semester) { $sql .= ' AND ar.semester=?'; $types .= 'i'; $params[] = $semester; }
    $sql .= ' GROUP BY po ORDER BY po';
    $stmt = $conn->prepare($sql); $stmt->bind_param($types, ...$params); $stmt->execute();
    $out = [];
    foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $r) $out[(int)$r['po']] = ['level' => round((float)$r['lvl'], 2), 'subjects' => (int)$r['subs']];
    $stmt->close();
    return $out;
}

/** Average CO level per subject (for department / college tables). */
function engine_co_by_subject(mysqli $conn, int $sessionId, ?int $departmentId, ?int $semester = null): array {
    $sql = "SELECT s.id, s.subject_code, s.subject_name, s.semester, d.name AS department,
                   COUNT(ar.id) AS co_count, AVG(ar.level_value) AS avg_level, AVG(ar.attainment_percent) AS avg_percent,
                   MAX(ar.calculated_at) AS last_calc
            FROM subjects s
            LEFT JOIN departments d ON d.id=s.department_id
            LEFT JOIN attainment_results ar ON ar.subject_id=s.id AND ar.outcome_type='CO' AND ar.academic_session_id=s.academic_session_id
            WHERE s.academic_session_id=?";
    $types = 'i'; $params = [$sessionId];
    if ($departmentId) { $sql .= ' AND s.department_id=?'; $types .= 'i'; $params[] = $departmentId; }
    if ($semester) { $sql .= ' AND s.semester=?'; $types .= 'i'; $params[] = $semester; }
    $sql .= ' GROUP BY s.id ORDER BY s.semester, s.subject_code';
    $stmt = $conn->prepare($sql); $stmt->bind_param($types, ...$params); $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    return $rows;
}
