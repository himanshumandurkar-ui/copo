<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('COPOSESSID');
    // On XAMPP localhost, HTTPS may be the literal string 'off'.
    // !empty('off') is true and incorrectly marks the cookie HTTPS-only,
    // causing the login CSRF token to fail on ordinary HTTP localhost.
    $isHttps = isset($_SERVER['HTTPS'])
        && $_SERVER['HTTPS'] !== ''
        && strtolower((string) $_SERVER['HTTPS']) !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => $isHttps,
    ]);
    session_start();
}
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void {
    if (!current_user()) { header('Location: index.php'); exit; }
}
function valid_user_role(string $role): bool {
    return in_array($role, ['principal', 'hod', 'subject_incharge', 'class_incharge'], true);
}
function user_can_access_page(string $page, ?array $user = null): bool {
    $user = $user ?? current_user();
    if (!$user || !valid_user_role($user['role'] ?? '')) {
        return false;
    }

    $rolePages = [
        // Principal — college level: full data access and overall control.
        'principal' => [
            'dashboard.php', 'profile.php', 'departments.php', 'faculty.php', 'program-outcomes.php',
            'students.php', 'classes.php', 'subjects.php', 'course-outcomes.php',
            'marks.php', 'internal-marks.php', 'unit-tests.php', 'assignments.php', 'practical-marks.php',
            'co-po-mapping.php', 'attainment.php', 'performance.php', 'analytics.php', 'report.php',
            'accreditation.php', 'migrate.php',
        ],
        // HOD — department level: POs, student/subject lists, CO-PO + CO attainment reports, department reports.
        'hod' => [
            'dashboard.php', 'profile.php', 'program-outcomes.php', 'faculty.php',
            'students.php', 'classes.php', 'subjects.php', 'course-outcomes.php',
            'co-po-mapping.php', 'attainment.php', 'performance.php', 'analytics.php', 'report.php',
        ],
        // Class incharge — class level: student records, CSV upload, class/section, class performance.
        'class_incharge' => [
            'dashboard.php', 'profile.php', 'students.php', 'classes.php', 'performance.php', 'report.php',
        ],
        // Subject incharge — subject level: own subjects, COs, assessment marks, mapping, attainment.
        'subject_incharge' => [
            'dashboard.php', 'profile.php', 'subjects.php', 'course-outcomes.php',
            'marks.php', 'internal-marks.php', 'unit-tests.php', 'assignments.php', 'practical-marks.php',
            'co-po-mapping.php', 'attainment.php', 'performance.php', 'report.php',
        ],
    ];

    return in_array($page, $rolePages[$user['role']], true);
}
function require_page_access(string $page): void {
    require_login();
    if (!user_can_access_page($page)) {
        http_response_code(403);
        echo '<!doctype html><html><head><title>Access denied</title><link rel="stylesheet" href="css/style.css"></head><body style="padding:50px"><h1>Access denied</h1><p>Your account role does not have permission to open this page.</p><a href="dashboard.php">Return to dashboard</a></body></html>';
        exit;
    }
}
