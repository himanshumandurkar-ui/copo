<?php
/*
 * Export helpers for the "Reports & Output" stage: CSV and Excel (.xls via HTML table).
 * PDF / Print is handled by the browser's print dialog using the @media print styles in css/style.css.
 */

/** Neutralise spreadsheet formula injection: a cell starting with = + - @ would be executed by Excel. */
function export_safe_cell($v): string {
    $s = (string)$v;
    if ($s !== '' && in_array($s[0], ['=', '+', '-', '@', "\t", "\r"], true) && !is_numeric($s)) return "'" . $s;
    return $s;
}

/**
 * Stream a download and exit.
 * @param string   $format  'csv' or 'xls'
 * @param string   $title   file name stem (letters, digits, dash, underscore only)
 * @param string[] $header  column headings
 * @param array[]  $rows    rows of scalar values (same length as $header)
 */
function export_send(string $format, string $title, array $header, array $rows): never {
    $stem = preg_replace('/[^A-Za-z0-9_-]+/', '_', $title) ?: 'report';
    $stem .= '_' . date('Ymd_His');
    if ($format === 'xls') {
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $stem . '.xls"');
        echo "\xEF\xBB\xBF<html><head><meta charset=\"utf-8\"></head><body><table border=\"1\"><tr>";
        foreach ($header as $c) echo '<th>' . htmlspecialchars(export_safe_cell($c), ENT_QUOTES, 'UTF-8') . '</th>';
        echo '</tr>';
        foreach ($rows as $r) {
            echo '<tr>';
            foreach ($r as $c) echo '<td>' . htmlspecialchars(export_safe_cell($c), ENT_QUOTES, 'UTF-8') . '</td>';
            echo '</tr>';
        }
        echo '</table></body></html>';
        exit;
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $stem . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");                       // BOM so Excel reads UTF-8 correctly
    fputcsv($out, array_map('export_safe_cell', $header));
    foreach ($rows as $r) fputcsv($out, array_map('export_safe_cell', $r));
    fclose($out);
    exit;
}
