<?php
/*
 * Shared helpers for the role-based workflow.
 * Function names are deliberately unique (or guarded) so they never clash with the
 * small page-level helpers some older pages still declare (h, e, out, pct, query_rows ...).
 */
require_once __DIR__ . '/auth.php';

if (!function_exists('h')) {
    function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
}

/* ------------------------------------------------------------------ CSRF */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['csrf_token'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}
function csrf_require(): void {
    $sent = (string)($_POST['csrf_token'] ?? '');
    if ($sent === '' || !hash_equals(csrf_token(), $sent)) {
        http_response_code(400);
        exit('Your session token expired. Go back, refresh the page and try again.');
    }
}

/* -------------------------------------------------------- current context */
function user_role(): string { return (string)(current_user()['role'] ?? ''); }
function user_id_int(): int { return (int)(current_user()['id'] ?? 0); }
function role_is(string ...$roles): bool { return in_array(user_role(), $roles, true); }

/** Department id of the signed-in user (resolved from the name if the id is not stored yet). */
function user_department_id(?mysqli $conn = null): int {
    $u = current_user();
    if (!$u) return 0;
    if (!empty($u['department_id'])) return (int)$u['department_id'];
    if ($conn === null) { require_once __DIR__ . '/db.php'; $conn = db(); }
    $stmt = $conn->prepare('SELECT id FROM departments WHERE name = ? LIMIT 1');
    $name = (string)($u['department'] ?? '');
    $stmt->bind_param('s', $name); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
    $id = $row ? (int)$row['id'] : 0;
    $_SESSION['user']['department_id'] = $id;
    return $id;
}

/** Academic session chosen at login (falls back to the active one). Returns [id, name]. */
function session_selected(mysqli $conn): array {
    $id = (int)($_SESSION['academic_session_id'] ?? 0);
    if ($id > 0) {
        $stmt = $conn->prepare('SELECT id, session_name FROM academic_sessions WHERE id=? LIMIT 1');
        $stmt->bind_param('i', $id); $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($row) return [(int)$row['id'], (string)$row['session_name']];
    }
    $row = $conn->query('SELECT id, session_name FROM academic_sessions ORDER BY is_active DESC, id DESC LIMIT 1')->fetch_assoc();
    return $row ? [(int)$row['id'], (string)$row['session_name']] : [0, 'No session'];
}

/* ------------------------------------------------------ role-based scoping
 * principal        → whole college
 * hod              → only their own department
 * class_incharge   → only classes (department + semester + section) assigned to them
 * subject_incharge → only subjects assigned to them
 * The clauses returned below are built only from integers read from our own tables / session,
 * never from request input, so concatenating them into SQL is safe.
 */

/** SQL fragment restricting a subjects query. $a = table alias (e.g. 's'), '' for none. */
function scope_subject_clause(string $a = ''): string {
    $p = $a === '' ? '' : $a . '.';
    switch (user_role()) {
        case 'principal': return '';
        case 'hod':
            $d = user_department_id();
            return $d > 0 ? " AND {$p}department_id = {$d}" : ' AND 1=0';
        case 'subject_incharge':
            return ' AND ' . $p . 'subject_incharge_id = ' . user_id_int();
        case 'class_incharge':
            $d = user_department_id();
            return $d > 0 ? " AND {$p}department_id = {$d}" : ' AND 1=0';   // may view subjects of their department's class
        default: return ' AND 1=0';
    }
}

/** Can the signed-in user work with this subject id? */
function scope_can_use_subject(mysqli $conn, int $subjectId): bool {
    if ($subjectId < 1) return false;
    $sql = 'SELECT id FROM subjects WHERE id=?' . scope_subject_clause();
    $stmt = $conn->prepare($sql); $stmt->bind_param('i', $subjectId); $stmt->execute();
    $ok = (bool)$stmt->get_result()->fetch_assoc(); $stmt->close();
    return $ok;
}

/** Departments this user may see: principal → all, others → their own. */
function scope_departments(mysqli $conn): array {
    if (role_is('principal')) return $conn->query('SELECT id, name FROM departments ORDER BY name')->fetch_all(MYSQLI_ASSOC);
    $d = user_department_id($conn);
    if ($d < 1) return [];
    $stmt = $conn->prepare('SELECT id, name FROM departments WHERE id=?'); $stmt->bind_param('i', $d); $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    return $rows;
}

/** [[department_id, semester, section], ...] assigned to a class incharge for a session. */
function scope_class_rows(mysqli $conn, int $sessionId): array {
    $uid = user_id_int();
    $stmt = $conn->prepare('SELECT department_id, semester, section FROM class_assignments WHERE user_id=? AND academic_session_id=?');
    $stmt->bind_param('ii', $uid, $sessionId); $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    return $rows;
}

/**
 * SQL fragment restricting student enrolment rows. Expects aliases: $se = student_enrollments, $st = students.
 * Builds from integers / escaped literals only.
 */
function scope_student_clause(mysqli $conn, int $sessionId, string $se = 'se', string $st = 'st'): string {
    switch (user_role()) {
        case 'principal': return '';
        case 'hod':
            $d = user_department_id($conn);
            return $d > 0 ? " AND {$st}.department_id = {$d}" : ' AND 1=0';
        case 'class_incharge':
            $pairs = $sessionId > 0 ? scope_class_rows($conn, $sessionId) : scope_class_rows_any($conn);
            if (!$pairs) return ' AND 1=0';
            $parts = [];
            foreach ($pairs as $r) {
                $sessionPart = $sessionId > 0 ? '' : sprintf(" AND {$se}.academic_session_id = %d", (int)$r['academic_session_id']);
                $parts[] = sprintf("({$st}.department_id = %d AND {$se}.semester = %d AND {$se}.section = '%s'%s)",
                    (int)$r['department_id'], (int)$r['semester'], $conn->real_escape_string((string)$r['section']), $sessionPart);
            }
            return ' AND (' . implode(' OR ', $parts) . ')';
        case 'subject_incharge':
            // students of the departments of the subjects this person teaches
            $uid = user_id_int();
            return " AND {$st}.department_id IN (SELECT DISTINCT department_id FROM subjects WHERE subject_incharge_id = {$uid} AND department_id IS NOT NULL)";
        default: return ' AND 1=0';
    }
}

/** Every class assigned to the signed-in class incharge, across all sessions (for history lists). */
function scope_class_rows_any(mysqli $conn): array {
    $uid = user_id_int();
    $stmt = $conn->prepare('SELECT academic_session_id, department_id, semester, section FROM class_assignments WHERE user_id=?');
    $stmt->bind_param('i', $uid); $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    return $rows;
}

/** May the signed-in user manage students of this exact class (session + department + semester + section)? */
function scope_class_allows(mysqli $conn, int $sessionId, int $deptId, int $semester, string $section): bool {
    if (role_is('principal')) return true;
    if (role_is('hod')) return $deptId > 0 && $deptId === user_department_id($conn);
    if (role_is('class_incharge')) {
        foreach (scope_class_rows($conn, $sessionId) as $r) {
            if ((int)$r['department_id'] === $deptId && (int)$r['semester'] === $semester && (string)$r['section'] === $section) return true;
        }
    }
    return false;
}

/**
 * Marks-entry rosters: only students of the subject's department (a subject with no department, or a student with
 * no department, is not filtered). $enrollAlias is the student_enrollments alias in the query.
 */
function scope_roster_clause(string $enrollAlias, int $subjectId): string {
    $sid = max(0, $subjectId);
    $dep = "(SELECT department_id FROM subjects WHERE id = {$sid})";
    return " AND {$enrollAlias}.student_id IN (SELECT x.id FROM students x WHERE {$dep} IS NULL OR x.department_id IS NULL OR x.department_id = {$dep})";
}
/** Same, for queries that already join the subject as alias `s`. */
function scope_roster_joined_clause(string $enrollAlias): string {
    return " AND {$enrollAlias}.student_id IN (SELECT x.id FROM students x WHERE s.department_id IS NULL OR x.department_id IS NULL OR x.department_id = s.department_id)";
}

/* ------------------------------------------------------------ audit trail */
function audit_write(mysqli $conn, string $action, string $entity, ?int $entityId = null, array $details = []): void {
    try {
        $uid = user_id_int() ?: null;
        $json = $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null;
        $stmt = $conn->prepare('INSERT INTO audit_log(user_id, action, entity_type, entity_id, details) VALUES (?,?,?,?,?)');
        $stmt->bind_param('issis', $uid, $action, $entity, $entityId, $json);
        $stmt->execute(); $stmt->close();
    } catch (Throwable $e) { error_log('audit_write failed: ' . $e->getMessage()); }
}

/* --------------------------------------------------------------- layout */
function page_topbar(string $crumb): void {
    $conn = null; $sessionName = '';
    try { require_once __DIR__ . '/db.php'; $conn = db(); [, $sessionName] = session_selected($conn); } catch (Throwable $e) { $sessionName = ''; }
    echo '<header class="topbar"><div class="crumb">CO–PO Workspace / <b>' . h($crumb) . '</b></div><div class="topbar-spacer"></div>'
       . ($sessionName !== '' ? '<span class="term-pill"><span class="dot"></span>' . h($sessionName) . ' · Academic session</span>' : '')
       . '<a class="term-pill" href="dashboard.php">Dashboard</a><a class="term-pill" href="profile.php">Profile</a><a class="term-pill" href="logout.php">Logout</a></header>';
}

/** Compact notice banner used by the new pages. */
function ui_notice(string $message, string $type = 'ok'): void {
    if ($message === '') return;
    echo '<div class="notice ' . ($type === 'err' ? 'err' : 'ok') . '" role="alert">' . h($message) . '</div>';
}

function ui_level_badge(?float $level, float $target = 2.0): string {
    if ($level === null) return '<span class="badge grey">—</span>';
    $cls = $level >= $target ? 'green' : ($level >= $target - 0.5 ? 'gold' : 'rust');
    return '<span class="badge ' . $cls . '">' . number_format($level, 2) . '</span>';
}
