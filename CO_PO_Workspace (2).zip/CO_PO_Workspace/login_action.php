<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

function login_redirect(string $message): never {
    header('Location: index.php?error=' . rawurlencode($message));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$submittedToken = (string)($_POST['csrf_token'] ?? '');
$sessionToken = (string)($_SESSION['login_csrf_token'] ?? '');
if ($submittedToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $submittedToken)) {
    login_redirect('Your sign-in form expired. Please try again.');
}

$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    login_redirect('Please enter a valid email address.');
}
if ($password === '') {
    login_redirect('Please enter your password.');
}
if (strlen($email) > 190 || strlen($password) > 4096) {
    login_redirect('Invalid email or password.');
}

try {
    $conn = db();
    // The academic session is not chosen at sign-in any more: the active session is used
    // (pages that work on another session have their own session selector).
    $selectedSession = $conn->query('SELECT id, session_name FROM academic_sessions ORDER BY is_active DESC, id DESC LIMIT 1')->fetch_assoc();
    if (!$selectedSession) {
        login_redirect('No academic session exists in the database yet. Import sspace_db.sql (it adds the default sessions) and try again.');
    }

    $stmt = $conn->prepare('SELECT id, full_name, email, password_hash, role, department, employee_id, active FROM users WHERE email = ? LIMIT 1');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $validUser = $user
        && (int)$user['active'] === 1
        && is_string($user['password_hash'])
        && password_verify($password, $user['password_hash'])
        && valid_user_role((string)$user['role']);

    if (!$validUser) {
        // Same message for unknown, inactive, and incorrect-password accounts.
        login_redirect('Invalid email or password, or the account is inactive.');
    }

    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $rehashStmt = $conn->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
        $userId = (int)$user['id'];
        $rehashStmt->bind_param('si', $newHash, $userId);
        $rehashStmt->execute();
        $rehashStmt->close();
    }

    // Department link (column added by the upgrade; fall back to the department name before it is run).
    $departmentId = 0;
    try {
        $depStmt = $conn->prepare('SELECT department_id FROM users WHERE id = ?');
        $depUserId = (int)$user['id'];
        $depStmt->bind_param('i', $depUserId);
        $depStmt->execute();
        $depRow = $depStmt->get_result()->fetch_assoc();
        $depStmt->close();
        $departmentId = (int)($depRow['department_id'] ?? 0);
    } catch (Throwable $e) { $departmentId = 0; }
    if ($departmentId < 1) {
        $depStmt = $conn->prepare('SELECT id FROM departments WHERE name = ? LIMIT 1');
        $depName = (string)$user['department'];
        $depStmt->bind_param('s', $depName);
        $depStmt->execute();
        $depRow = $depStmt->get_result()->fetch_assoc();
        $depStmt->close();
        $departmentId = (int)($depRow['id'] ?? 0);
    }

    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id' => (int)$user['id'],
        'name' => (string)$user['full_name'],
        'full_name' => (string)$user['full_name'],
        'email' => (string)$user['email'],
        'role' => (string)$user['role'],
        'department' => (string)$user['department'],
        'department_id' => $departmentId,
        'employee_id' => $user['employee_id'] === null ? null : (string)$user['employee_id'],
    ];
    $_SESSION['academic_session'] = (string)$selectedSession['session_name'];
    $_SESSION['academic_session_id'] = (int)$selectedSession['id'];
    unset($_SESSION['login_csrf_token']);

    header('Location: dashboard.php');
    exit;
} catch (Throwable $e) {
    error_log('CO-PO login error: ' . $e->getMessage());
    login_redirect('Unable to sign in right now. Check the database connection and try again.');
}
