<?php
/*
 * SELF-TEST — open this page from the computer that runs XAMPP (http://localhost/<folder>/selftest.php).
 * It checks the setup, the login page, who can open which page, and that one department's data is never
 * returned to another department. It only READS the database (nothing is changed).
 * Delete this file when you are finished.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/engine.php';

$ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
if (!in_array($ip, ['127.0.0.1', '::1'], true)) { http_response_code(403); exit('The self-test runs only on the computer hosting the site (localhost).'); }

$results = [];   // [status, group, message]
function t(string $status, string $group, string $msg): void { global $results; $results[] = [$status, $group, $msg]; }
function ok(bool $cond, string $group, string $pass, string $fail, string $failStatus = 'FAIL'): void { t($cond ? 'PASS' : $failStatus, $group, $cond ? $pass : $fail); }
function one(mysqli $c, string $sql, string $types = '', array $p = []) {
    $s = $c->prepare($sql); if ($types !== '') $s->bind_param($types, ...$p); $s->execute();
    $r = $s->get_result()->fetch_row(); $s->close(); return $r ? $r[0] : null;
}

/* ------------------------------------------------------------------ A. environment */
ok(PHP_VERSION_ID >= 80100, 'Environment', 'PHP ' . PHP_VERSION . ' (8.1 or newer)', 'PHP ' . PHP_VERSION . ' is too old; the project needs PHP 8.1+');
foreach (['mysqli', 'mbstring'] as $ext) ok(extension_loaded($ext), 'Environment', "PHP extension {$ext} is loaded", "PHP extension {$ext} is missing (enable it in php.ini)");
$conn = null;
try { $conn = db(); t('PASS', 'Environment', 'Connected to database "' . DB_NAME . '"'); }
catch (Throwable $e) { t('FAIL', 'Environment', 'Cannot connect to the database "' . DB_NAME . '": check config.php (DB_NAME / DB_USER / DB_PASS) and that MySQL is running'); }

$original = ['user' => $_SESSION['user'] ?? null, 'dept' => $_SESSION['dept_filter'] ?? null, 'had_dept' => array_key_exists('dept_filter', $_SESSION)];

if ($conn) {
    /* -------------------------------------------------------------- B. schema */
    $needed = [
        'academic_sessions' => ['id', 'session_name', 'is_active'], 'departments' => ['id', 'name'],
        'users' => ['id', 'email', 'role', 'department', 'department_id', 'active'],
        'students' => ['id', 'enrollment_no', 'department_id'], 'student_enrollments' => ['id', 'student_id', 'academic_session_id', 'semester', 'section'],
        'subjects' => ['id', 'department_id', 'subject_incharge_id', 'academic_session_id'], 'course_outcomes' => ['id', 'subject_id'],
        'assessment_components' => ['id', 'subject_id', 'max_marks'], 'marks' => ['id', 'enrollment_id', 'assessment_component_id', 'course_outcome_id'],
        'co_po_mapping' => ['id', 'course_outcome_id', 'po_number', 'mapping_level'],
        'attainment_results' => ['id', 'subject_id', 'level_value', 'students_total', 'students_attained'],
        'program_outcomes' => ['id', 'department_id', 'po_number'], 'class_assignments' => ['id', 'user_id', 'department_id', 'semester', 'section'],
        'attainment_settings' => ['id', 'department_id', 'target_percent'], 'audit_log' => ['id'],
    ];
    $schemaOk = true;
    foreach ($needed as $table => $cols) {
        $have = [];
        try { foreach ($conn->query("SHOW COLUMNS FROM `{$table}`")->fetch_all(MYSQLI_ASSOC) as $c) $have[] = $c['Field']; }
        catch (Throwable $e) { t('FAIL', 'Database', "Table {$table} is missing: import sspace_db.sql or run migrate.php"); $schemaOk = false; continue; }
        $missing = array_diff($cols, $have);
        if ($missing) { t('FAIL', 'Database', "Table {$table} lacks column(s): " . implode(', ', $missing)); $schemaOk = false; }
    }
    if ($schemaOk) t('PASS', 'Database', 'All ' . count($needed) . ' tables and the columns the app needs are present');

    /* -------------------------------------------------------------- C. data */
    ok((int)one($conn, 'SELECT COUNT(*) FROM academic_sessions') > 0, 'Data', 'An academic session exists (login uses the active one)', 'No academic session: import sspace_db.sql (login will refuse to start)');
    ok((int)one($conn, 'SELECT COUNT(*) FROM academic_sessions WHERE is_active=1') >= 1, 'Data', 'An ACTIVE academic session is set', 'No active academic session: the newest one will be used at login', 'WARN');
    ok((int)one($conn, "SELECT COUNT(*) FROM users WHERE role='principal' AND active=1") >= 1, 'Data', 'At least one active Principal account', 'No active Principal: use reset-principal.php');
    foreach (['hod' => 'HOD', 'class_incharge' => 'Class Incharge', 'subject_incharge' => 'Subject Incharge'] as $role => $label) {
        $n = (int)one($conn, 'SELECT COUNT(*) FROM users WHERE role=? AND active=1', 's', [$role]);
        t($n > 0 ? 'PASS' : 'WARN', 'Data', "{$n} active {$label} account(s)" . ($n > 0 ? '' : ' (create one under Faculty & Access to test this role)'));
    }
    $noDept = (int)one($conn, "SELECT COUNT(*) FROM users WHERE role<>'principal' AND (department_id IS NULL)");
    ok($noDept === 0, 'Data', 'Every non-Principal account is linked to a department', "{$noDept} account(s) have no department link; they cannot see any department data (fix under Faculty & Access / migrate.php)", 'WARN');
    $noDeptStudents = (int)one($conn, 'SELECT COUNT(*) FROM students WHERE department_id IS NULL');
    ok($noDeptStudents === 0, 'Data', 'Every student belongs to a department', "{$noDeptStudents} student(s) have no department and are hidden from every department's lists", 'WARN');
    $noDeptSubjects = (int)one($conn, 'SELECT COUNT(*) FROM subjects WHERE department_id IS NULL');
    ok($noDeptSubjects === 0, 'Data', 'Every subject belongs to a department', "{$noDeptSubjects} subject(s) have no department and show no students", 'WARN');
    $dupStaff = (int)one($conn, 'SELECT COUNT(*) FROM (SELECT email FROM users GROUP BY email HAVING COUNT(*)>1) x');
    ok($dupStaff === 0, 'Data', 'No duplicate e-mail accounts', "{$dupStaff} duplicated e-mail(s)");
}

/* ------------------------------------------------------------------ D. login page */
$indexSrc = (string)@file_get_contents(__DIR__ . '/index.php');
$actionSrc = (string)@file_get_contents(__DIR__ . '/login_action.php');
ok($indexSrc !== '' && stripos($indexSrc, 'academic_session') === false, 'Login page', 'index.php has no academic session field', 'index.php still contains an academic session field');
ok($actionSrc !== '' && strpos($actionSrc, "\$_POST['academic_session']") === false, 'Login page', 'login_action.php no longer asks for an academic session', 'login_action.php still reads an academic session from the form');
ok(strpos($actionSrc, 'ORDER BY is_active DESC') !== false, 'Login page', 'Login uses the active academic session automatically', 'login_action.php does not pick the active session');
ok(strpos($actionSrc, 'password_verify') !== false && strpos($actionSrc, 'login_csrf_token') !== false, 'Login page', 'Login checks the password hash and a CSRF token', 'Login is missing password_verify or the CSRF token check');

/* ------------------------------------------------------------------ E. who can open which page */
$expect = [   // role => [page => should the role be able to open it?]
    'principal'        => ['dashboard.php' => 1, 'departments.php' => 1, 'faculty.php' => 1, 'co-po-mapping.php' => 1, 'attainment.php' => 1, 'report.php' => 1, 'analytics.php' => 1, 'accreditation.php' => 1,
                           'classes.php' => 1, 'subjects.php' => 1, 'course-outcomes.php' => 1, 'performance.php' => 1,
                           'students.php' => 0, 'program-outcomes.php' => 0, 'marks.php' => 0, 'internal-marks.php' => 0, 'unit-tests.php' => 0, 'assignments.php' => 0, 'practical-marks.php' => 0],
    'hod'              => ['dashboard.php' => 1, 'program-outcomes.php' => 1, 'students.php' => 1, 'subjects.php' => 1, 'co-po-mapping.php' => 1, 'attainment.php' => 1, 'report.php' => 1,
                           'departments.php' => 0, 'accreditation.php' => 0, 'marks.php' => 0, 'migrate.php' => 0],
    'class_incharge'   => ['dashboard.php' => 1, 'students.php' => 1, 'classes.php' => 1, 'performance.php' => 1, 'report.php' => 1,
                           'marks.php' => 1, 'internal-marks.php' => 1, 'unit-tests.php' => 1, 'assignments.php' => 1, 'practical-marks.php' => 1, 'subjects.php' => 0, 'faculty.php' => 0, 'departments.php' => 0],
    'subject_incharge' => ['dashboard.php' => 1, 'subjects.php' => 1, 'course-outcomes.php' => 1, 'marks.php' => 1, 'internal-marks.php' => 1, 'unit-tests.php' => 1, 'assignments.php' => 1, 'practical-marks.php' => 1, 'co-po-mapping.php' => 1, 'attainment.php' => 1,
                           'students.php' => 0, 'faculty.php' => 0, 'departments.php' => 0],
];
foreach ($expect as $role => $pages) {
    $bad = [];
    foreach ($pages as $page => $want) {
        $got = user_can_access_page($page, ['role' => $role]);
        if ($got !== (bool)$want) $bad[] = $page . ($want ? ' (should be allowed)' : ' (should be blocked)');
    }
    ok(!$bad, 'Page access', ucwords(str_replace('_', ' ', $role)) . ': ' . count($pages) . ' page rules match the flowchart', ucwords(str_replace('_', ' ', $role)) . ': ' . implode('; ', $bad));
}
$students = []; foreach (['principal', 'hod', 'class_incharge', 'subject_incharge'] as $r) $students[$r] = user_can_access_page('students.php', ['role' => $r]);
ok($students === ['principal' => false, 'hod' => true, 'class_incharge' => true, 'subject_incharge' => false], 'Page access', 'Student page: Class Incharge adds; HOD views (read-only); Principal and Subject Incharge cannot open it', 'Student page access is wrong: ' . json_encode($students));
$src = (string)@file_get_contents(__DIR__ . '/students.php');
ok(strpos($src, "role_is('class_incharge')") !== false && strpos($src, '$canEdit') !== false, 'Page access', 'students.php only lets the Class Incharge add / edit / delete', 'students.php does not restrict add/edit to the Class Incharge');
ok(strpos((string)@file_get_contents(__DIR__ . '/includes/helpers.php'), "if (!role_is('class_incharge')) return false;") !== false, 'Page access', 'Server-side check: only the assigned Class Incharge may change a class\'s students', 'scope_class_allows() is not restricted to the Class Incharge');

/* ------------------------------------------------------------------ F. department isolation (simulated users) */
function as_user(array $u, ?int $deptFilter = null): void { $_SESSION['user'] = $u; if ($deptFilter !== null) $_SESSION['dept_filter'] = $deptFilter; }
if ($conn && $schemaOk) {
    [$sessId] = session_selected($conn);
    $depts = $conn->query('SELECT id, name FROM departments ORDER BY id')->fetch_all(MYSQLI_ASSOC);
    t('PASS', 'Departments', count($depts) . ' department(s): ' . implode(', ', array_column($depts, 'name')));
    if (count($depts) < 2) t('WARN', 'Departments', 'Only one department exists, so cross-department leakage cannot be demonstrated. Add a second department and some data, then run this test again.');

    foreach ($depts as $d) {
        $did = (int)$d['id'];
        // HOD of this department
        as_user(['id' => 0, 'role' => 'hod', 'department_id' => $did, 'department' => $d['name']]);
        $own = (int)one($conn, 'SELECT COUNT(*) FROM subjects s WHERE s.department_id = ?', 'i', [$did]);
        $viaScope = (int)one($conn, 'SELECT COUNT(*) FROM subjects s WHERE 1=1' . scope_subject_clause('s'));
        $foreign = (int)one($conn, 'SELECT COUNT(*) FROM subjects s WHERE 1=1' . scope_subject_clause('s') . ' AND (s.department_id IS NULL OR s.department_id <> ' . $did . ')');
        ok($viaScope === $own && $foreign === 0, 'Departments', "HOD of {$d['name']}: sees {$viaScope} of its own {$own} subject(s), 0 from other departments", "HOD of {$d['name']}: subject scope is wrong (sees {$viaScope}, expected {$own}; {$foreign} foreign)");
        $ownSt = (int)one($conn, 'SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE st.department_id = ?', 'i', [$did]);
        $scSt = (int)one($conn, 'SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE 1=1' . scope_student_clause($conn, 0));
        $foreignSt = (int)one($conn, 'SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE 1=1' . scope_student_clause($conn, 0) . ' AND (st.department_id IS NULL OR st.department_id <> ' . $did . ')');
        ok($scSt === $ownSt && $foreignSt === 0, 'Departments', "HOD of {$d['name']}: sees {$scSt} of its own {$ownSt} student enrolment(s), 0 from other departments", "HOD of {$d['name']}: student scope is wrong (sees {$scSt}, expected {$ownSt}; {$foreignSt} foreign)");
        // Principal viewing only this department
        as_user(['id' => 0, 'role' => 'principal', 'department_id' => 0, 'department' => ''], $did);
        $pv = (int)one($conn, 'SELECT COUNT(*) FROM subjects s WHERE 1=1' . scope_subject_clause('s'));
        ok($pv === $own, 'Departments', "Principal with department view = {$d['name']}: sees {$pv} subject(s), only that department", "Principal department view is wrong for {$d['name']} (sees {$pv}, expected {$own})");
    }
    // Principal, all departments
    as_user(['id' => 0, 'role' => 'principal', 'department_id' => 0, 'department' => ''], 0);
    $allSub = (int)one($conn, 'SELECT COUNT(*) FROM subjects'); $allScope = (int)one($conn, 'SELECT COUNT(*) FROM subjects s WHERE 1=1' . scope_subject_clause('s'));
    ok($allSub === $allScope, 'Departments', 'Principal with "All departments" sees all ' . $allSub . ' subject(s)', "Principal 'All departments' sees {$allScope} of {$allSub} subjects");

    // Class incharges: only their own class
    foreach ($conn->query("SELECT ca.user_id, ca.academic_session_id, ca.department_id, ca.semester, ca.section, u.full_name FROM class_assignments ca JOIN users u ON u.id=ca.user_id")->fetch_all(MYSQLI_ASSOC) as $ca) {
        as_user(['id' => (int)$ca['user_id'], 'role' => 'class_incharge', 'department_id' => (int)$ca['department_id'], 'department' => '']);
        $sid = (int)$ca['academic_session_id'];
        $cnt = (int)one($conn, 'SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE se.academic_session_id=?' . scope_student_clause($conn, $sid), 'i', [$sid]);
        $outside = (int)one($conn, 'SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE se.academic_session_id=?' . scope_student_clause($conn, $sid)
            . ' AND NOT (st.department_id = ' . (int)$ca['department_id'] . ' AND se.semester = ' . (int)$ca['semester'] . " AND se.section = '" . $conn->real_escape_string($ca['section']) . "')", 'i', [$sid]);
        ok($outside === 0, 'Class incharge', "{$ca['full_name']} (Sem {$ca['semester']} / {$ca['section']}): sees {$cnt} student(s), none outside the assigned class", "{$ca['full_name']}: {$outside} student(s) outside the assigned class are visible");
        ok(scope_class_allows($conn, $sid, (int)$ca['department_id'], (int)$ca['semester'], (string)$ca['section']) === true
           && scope_class_allows($conn, $sid, (int)$ca['department_id'], (int)$ca['semester'], (string)$ca['section'] . '-other') === false,
           'Class incharge', "{$ca['full_name']} may change students only in the assigned class", "{$ca['full_name']}: class write-permission check is wrong");
        // marks sheets of a class incharge: only subjects of their class, only students of their own section
        $subjOfClass = $conn->query('SELECT id, subject_code FROM subjects s WHERE 1=1' . scope_subject_clause('s'))->fetch_all(MYSQLI_ASSOC);
        $leak = 0;
        foreach ($subjOfClass as $sj) {
            $leak += (int)one($conn, 'SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE 1=1' . scope_roster_clause('se', (int)$sj['id'])
                . ' AND NOT (st.department_id = ' . (int)$ca['department_id'] . ' AND se.semester = ' . (int)$ca['semester'] . " AND se.section = '" . $conn->real_escape_string($ca['section']) . "')");
        }
        ok($leak === 0, 'Class incharge', "{$ca['full_name']}: marks sheets list " . count($subjOfClass) . ' subject(s) of the class and only its own section\'s students', "{$ca['full_name']}: {$leak} student(s) outside the assigned section would appear on a marks sheet");
    }
    // Subject incharges: only their subjects, rosters only from the subject's department
    foreach ($conn->query("SELECT u.id, u.full_name, u.department_id FROM users u WHERE u.role='subject_incharge' AND u.active=1")->fetch_all(MYSQLI_ASSOC) as $su) {
        as_user(['id' => (int)$su['id'], 'role' => 'subject_incharge', 'department_id' => (int)$su['department_id'], 'department' => '']);
        $mine = (int)one($conn, 'SELECT COUNT(*) FROM subjects WHERE subject_incharge_id=?', 'i', [(int)$su['id']]);
        $seen = (int)one($conn, 'SELECT COUNT(*) FROM subjects s WHERE 1=1' . scope_subject_clause('s'));
        $other = (int)one($conn, 'SELECT COUNT(*) FROM subjects s WHERE 1=1' . scope_subject_clause('s') . ' AND (s.subject_incharge_id IS NULL OR s.subject_incharge_id <> ' . (int)$su['id'] . ')');
        ok($seen === $mine && $other === 0, 'Subject incharge', "{$su['full_name']}: sees exactly their {$mine} assigned subject(s)", "{$su['full_name']}: subject scope is wrong (sees {$seen}, assigned {$mine}, {$other} not theirs)");
    }
    foreach ($conn->query('SELECT id, subject_code, department_id FROM subjects WHERE department_id IS NOT NULL')->fetch_all(MYSQLI_ASSOC) as $sj) {
        $leak = (int)one($conn, 'SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id=se.student_id WHERE 1=1' . scope_roster_clause('se', (int)$sj['id']) . ' AND (st.department_id IS NULL OR st.department_id <> ' . (int)$sj['department_id'] . ')');
        if ($leak > 0) t('FAIL', 'Marks roster', "Subject {$sj['subject_code']}: {$leak} student(s) from another department would appear on its marks sheet");
    }
    t('PASS', 'Marks roster', 'Marks-entry rosters were checked for every subject: only students of the subject\'s own department are returned (no failures listed above)');
}

/* ------------------------------------------------------------------ G. calculation rules */
$s = engine_default_settings();
$cases = [[100, 3], [70, 3], [69.99, 2], [60, 2], [59.99, 1], [50, 1], [49.99, 0], [0, 0]];
$bad = []; foreach ($cases as [$pct, $lv]) if (engine_level_for_percent((float)$pct, $s) !== $lv) $bad[] = "{$pct}% should be level {$lv}";
ok(!$bad, 'Calculation', 'CO level thresholds behave as documented (70 / 60 / 50)', implode('; ', $bad));
$po = (3 * 3 + 2 * 2 + 1 * 0) / (3 + 2 + 1);
ok(abs($po - 2.1667) < 0.001, 'Calculation', 'PO formula example gives 2.17', 'PO formula example is wrong');

// put the session back exactly as it was
if ($original['user'] === null) unset($_SESSION['user']); else $_SESSION['user'] = $original['user'];
if ($original['had_dept']) $_SESSION['dept_filter'] = $original['dept']; else unset($_SESSION['dept_filter']);

$count = ['PASS' => 0, 'FAIL' => 0, 'WARN' => 0];
foreach ($results as $r) $count[$r[0]]++;
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Self-test — CO–PO Workspace</title>
<style>body{font:14px Arial,sans-serif;max-width:980px;margin:30px auto;padding:0 16px;color:#1b2a44;background:#f3f4f0}h1{font-size:22px}table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #dee1e2}td,th{padding:8px 10px;border-bottom:1px solid #eceee9;text-align:left;vertical-align:top;font-size:13px}th{background:#f7f8f6}.PASS{color:#27633a;font-weight:700}.FAIL{color:#b24632;font-weight:700}.WARN{color:#8a5a00;font-weight:700}.sum{display:flex;gap:14px;margin:14px 0}.sum div{background:#fff;border:1px solid #dee1e2;padding:12px 18px;border-radius:6px}small{color:#69768a}</style></head><body>
<h1>CO–PO Workspace — self-test</h1>
<p><small>Read-only checks. Delete selftest.php when you are done.</small></p>
<div class="sum"><div><span class="PASS"><?= $count['PASS'] ?></span> passed</div><div><span class="FAIL"><?= $count['FAIL'] ?></span> failed</div><div><span class="WARN"><?= $count['WARN'] ?></span> warnings</div></div>
<table><tr><th style="width:70px">Result</th><th style="width:150px">Area</th><th>Detail</th></tr>
<?php foreach ($results as [$st, $grp, $msg]): ?><tr><td class="<?= h($st) ?>"><?= h($st) ?></td><td><?= h($grp) ?></td><td><?= h($msg) ?></td></tr><?php endforeach; ?>
</table>
<p><small>PASS = fine · WARN = data or setup to review · FAIL = needs fixing. Login itself (typing a password) cannot be automated here: sign in once as each role and follow the checklist in README_BACKEND.txt.</small></p>
</body></html>
