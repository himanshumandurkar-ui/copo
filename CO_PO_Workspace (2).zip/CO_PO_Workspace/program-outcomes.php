<?php
require_once __DIR__ . '/includes/auth.php';
require_page_access('program-outcomes.php');
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$conn = db();
$msg = ''; $error = '';
$poEdit = role_is('hod');   // only the HOD adds / manages Program Outcomes   // flowchart: the HOD adds / manages POs; the Principal only reviews them
$departments = scope_departments($conn);
$deptId = role_is('principal') ? (filter_input(INPUT_GET, 'dept', FILTER_VALIDATE_INT) ?: (int)($departments[0]['id'] ?? 0)) : user_department_id($conn);
if ($deptId && !array_filter($departments, fn($d) => (int)$d['id'] === $deptId)) $deptId = (int)($departments[0]['id'] ?? 0);
$deptName = '';
foreach ($departments as $d) if ((int)$d['id'] === $deptId) $deptName = $d['name'];

// Standard 12 graduate-attribute titles used by NBA/AICTE engineering programmes.
$standard = [
    1 => 'Engineering knowledge', 2 => 'Problem analysis', 3 => 'Design/development of solutions',
    4 => 'Conduct investigations of complex problems', 5 => 'Modern tool usage', 6 => 'The engineer and society',
    7 => 'Environment and sustainability', 8 => 'Ethics', 9 => 'Individual and team work',
    10 => 'Communication', 11 => 'Project management and finance', 12 => 'Life-long learning',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    try {
        if (!$poEdit) throw new RuntimeException('Program outcomes are managed by the HOD of each department. This page is a read-only overview for you.');
        $postDept = role_is('principal') ? (int)($_POST['dept_id'] ?? 0) : user_department_id($conn);
        if ($postDept < 1 || !array_filter($departments, fn($d) => (int)$d['id'] === $postDept)) throw new RuntimeException('Select a valid department.');
        $deptId = $postDept;
        $uid = user_id_int();
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'load_standard') {
            $ins = $conn->prepare('INSERT IGNORE INTO program_outcomes(department_id, po_number, title, updated_by) VALUES (?,?,?,?)');
            foreach ($standard as $no => $title) { $ins->bind_param('iisi', $postDept, $no, $title, $uid); $ins->execute(); }
            $ins->close();
            audit_write($conn, 'po.load_standard', 'department', $postDept);
            $msg = 'Standard PO1–PO12 titles added where missing. Edit the wording to match your department.';
        } elseif ($action === 'save') {
            $titles = $_POST['title'] ?? []; $descs = $_POST['description'] ?? [];
            $conn->begin_transaction();
            $up = $conn->prepare('INSERT INTO program_outcomes(department_id, po_number, title, description, updated_by) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE title=VALUES(title), description=VALUES(description), updated_by=VALUES(updated_by)');
            $del = $conn->prepare('DELETE FROM program_outcomes WHERE department_id=? AND po_number=?');
            $saved = 0;
            for ($no = 1; $no <= 12; $no++) {
                $t = trim((string)($titles[$no] ?? '')); $ds = trim((string)($descs[$no] ?? ''));
                if (mb_strlen($t) > 150) throw new RuntimeException("PO{$no} title is too long (150 characters max).");
                if ($t === '') { $del->bind_param('ii', $postDept, $no); $del->execute(); continue; }
                $up->bind_param('iissi', $postDept, $no, $t, $ds, $uid); $up->execute(); $saved++;
            }
            $conn->commit();
            audit_write($conn, 'po.save', 'department', $postDept, ['saved' => $saved]);
            $msg = "Program outcomes saved ({$saved} defined).";
        }
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $e2) {}
        $error = $e instanceof RuntimeException ? $e->getMessage() : 'Could not save program outcomes. Run the database upgrade (migrate.php) first.';
    }
}

$pos = [];
try {
    if ($deptId) {
        $stmt = $conn->prepare('SELECT po_number, title, description FROM program_outcomes WHERE department_id=?');
        $stmt->bind_param('i', $deptId); $stmt->execute();
        foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $r) $pos[(int)$r['po_number']] = $r;
        $stmt->close();
    }
} catch (Throwable $e) { $error = $error ?: 'Program outcomes table is missing. Run the database upgrade (migrate.php).'; }
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Program Outcomes — CO–PO Workspace</title><link rel="stylesheet" href="css/style.css"></head>
<body><div class="shell">
<?php require __DIR__ . '/includes/sidebar.php'; ?>
<main class="main">
<?php page_topbar('Program Outcomes'); ?>
<div class="content"><section class="page active">
<div class="page-head"><div><div class="eyebrow"><?= role_is('principal') ? 'COLLEGE-WIDE VIEW' : 'DEPARTMENT LEVEL' ?></div><h1>Program Outcomes (POs)</h1><p>Define the PO1–PO12 statements for <?= h($deptName ?: 'your department') ?>. These appear in CO–PO mapping, PO attainment and accreditation reports.</p></div></div>
<?php ui_notice($msg, 'ok'); ui_notice($error, 'err'); ?>

<?php if (role_is('principal') && count($departments) > 1): ?>
<form method="get" class="card" style="margin-bottom:20px"><div class="panel-body"><div class="form-row"><div class="field"><label>Department</label><select class="control" name="dept" onchange="this.form.submit()"><?php foreach ($departments as $d): ?><option value="<?= (int)$d['id'] ?>" <?= (int)$d['id'] === $deptId ? 'selected' : '' ?>><?= h($d['name']) ?></option><?php endforeach; ?></select></div></div></div></form>
<?php endif; ?>

<?php if (!$deptId): ?>
<div class="card"><div class="muted-empty">No department is linked to your account yet. Ask the Principal to assign one in Faculty &amp; Access.</div></div>
<?php else: ?>
<form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="dept_id" value="<?= (int)$deptId ?>">
<div class="card-head"><div><h2>PO1 – PO12</h2><span>Leave a title blank to remove that outcome.</span></div>
<?php if ($poEdit): ?><div class="export-bar"><button class="btn btn-outline btn-sm" type="submit" name="action" value="load_standard" formnovalidate>Load standard titles</button><button class="btn btn-gold btn-sm" type="submit" name="action" value="save">Save program outcomes</button></div><?php endif; ?></div>
<div class="table-wrap"><table class="data"><thead><tr><th style="width:70px">PO</th><th style="width:34%">Title</th><th>Description</th></tr></thead><tbody>
<?php for ($no = 1; $no <= 12; $no++): $row = $pos[$no] ?? null; ?>
<tr><td><b>PO<?= $no ?></b></td>
<td><input class="control" <?= $poEdit ? '' : 'readonly' ?> name="title[<?= $no ?>]" maxlength="150" value="<?= h($row['title'] ?? '') ?>" placeholder="<?= h($standard[$no]) ?>"></td>
<td><textarea class="control" <?= $poEdit ? '' : 'readonly' ?> name="description[<?= $no ?>]" rows="2" placeholder="Statement of this program outcome"><?= h($row['description'] ?? '') ?></textarea></td></tr>
<?php endfor; ?></tbody></table></div>
<div class="help-text">Titles for PO1–PO12 follow the standard graduate attributes used by NBA/AICTE engineering programmes; adjust them if your programme uses a different set.</div>
</form>
<?php endif; ?>
</section></div></main></div></body></html>
